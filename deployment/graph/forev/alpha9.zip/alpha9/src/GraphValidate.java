import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Map.Entry;

import net.sf.json.*;

public class GraphValidate {
	
	public JSONObject validateGraphData(JSONObject fbData, JSONObject stuInput){
		return validateGraphData(fbData, stuInput, null);
	}
	public JSONObject validateGraphData(JSONObject fbData, JSONObject stuInput, PrintWriter out){

		// The JSONObject response being sent back
		JSONObject response = new JSONObject();
		
		//create correct variable
		Boolean correct = false;
		
		JSONObject graph = stuInput.getJSONObject("graph");
		String answer = graph.getString("tgcorrect");

		//check student input, whether correct or not.
		if((answer.equals("correct")))
		{
			correct = true;
		} else
		{
		    correct = false;
		}	
			
		response.element("result", correct);
		response.element("fbData", "Feedback has not been incorporated into this version of new graphing module");

		return response;
	}

}
