
var gmloc = 1;
var graphSe;

var valuet = 1;
var currquestion;

var paramcheck;

var questionNumber = 1;


var questiontext;

var returndata;

function getquestion(text)
{
	graphSe.fquestion = text;
}

function checkBoxes()
{
	graphMe[gmloc-1].checkBoxes();
}

function addLabel()
{
	graphMe[gmloc-1].addLabel();
}


function CheckGraph()
{
		//$('#feedback').removeClass("hide");

		var html = '';
		for(var i=0; i<graphMe.length; i++)
		{
			
			if(graphMe[i].mode!="correct") html+="<div class='resultsrow'>"+graphMe[i].label+": "+graphMe[i].iscorrect+"</div>";
		}	
		
		TotalGraph()
		
		if(graphSe.tgcorrect=="correct")
		{
			html += "<div><Strong>Total Graph: <span style='color:green'>Correct</span></div>"
		} else {
			html += "<div><Strong>Total Graph: <span style='color:red'>Incorrect</span></div>"
		}			

		//html += TotalGraph();

		document.getElementById('feedbacktext').innerHTML = html;
		
}

function TotalGraph()
{

		for(var i = 0, ncorr = 0, numuc = 0; i < graphMe.length; i++)
		{
		    var gi = graphMe[i];
		    var acceptedArea = gi.acceptedArea != undefined ? gi.acceptedArea : false;
			if(gi.iscorrect!=null) 
			{
			    if(gi.mode=="student") ncorr--;
				if(gi.iscorrect == "<span style='color:red'>Not Correct</span>") 
				{
					graphSe.tgcorrect="incorrect";
					return "<div><Strong>Total Graph: <span style='color:red'>Incorrect</span></div>";
				}	
			}
			else if( gi.mode == "correct" && !acceptedArea ) 
			{
				ncorr++;
				numuc++;
			}	
			else numuc++;
		}		

    	return (ncorr == 0 && numuc != graphMe.length) ? graphSe.tgcorrect="correct" :
    	                    graphSe.tgcorrect="incorrect";
}   

	
function update()
{
    console.log("Update: ", gmloc);
    
	if($('#gridtoggle').is(":checked")) {gridt=1;graphSe.grid=true;} else {gridt=0;graphSe.grid=false;};
	if($('#valuetoggle').is(":checked")) {valuet=1; graphSe.value=true;} else {valuet=0; graphSe.value=false;};
	if($('#xytoggle').is(":checked")) {$('#yaxistext').removeClass("hide");$('#xaxistext').removeClass("hide");graphSe.axisshow=true;} else {$('#yaxistext').addClass("hide");$('#xaxistext').addClass("hide");graphSe.axisshow=false;};
	if($('#titletoggle').is(":checked")) {$('#titletext').removeClass("hide");graphSe.titleshow=true;} else {$('#titletext').addClass("hide");graphSe.titleshow=false;};
	if($('#snaptoggle').is(":checked")) graphSe.SnapOnOff(true); else graphSe.SnapOnOff(false);
	
	if( graphMe.length > 0 )
	{
	    if($('#plumbtoggle').is(":checked")) graphMe[gmloc-1].PlumbMe(true); else graphMe[gmloc-1].PlumbMe(false);
	    if($('#labeltoggle').is(":checked")) {graphMe[gmloc-1].LabelMe(true);} else {graphMe[gmloc-1].LabelMe(false);}
	    if($('#rltoggle').is(":checked")) graphMe[gmloc-1].RequiredLabelMe(true); else graphMe[gmloc-1].RequiredLabelMe(false);
	}
}

function Interactive( tf )
{		

	if(tf==true)
	{
		$('#ilabels').removeClass("hide");
		$('#iinputs').removeClass("hide");
	} else {
		$('#ilabels').addClass("hide");
		$('#iinputs').addClass("hide");
	}	
	
    graphMe[gmloc-1].InteractiveMe( tf );
}

function Precise( tf )
{		
    graphMe[gmloc-1].PreciseMe( tf );
    graphMe[gmloc-1].SetSettings();
}

function ShiftLeft(  )
{		
    graphMe[gmloc-1].EvalShift( "left" );
}

function ShiftRight(  )
{		
    graphMe[gmloc-1].EvalShift( "right" );
}

function testGet()
{
	var xhr = new XMLHttpRequest();
	xhr.open('GET', "http://54.173.144.67:3000/graphelements/1", true);
}

// Create the XHR object.
function CreateCORSRequest(method, url) 
{
    var xhr = new XMLHttpRequest();
    if ("withCredentials" in xhr) 
    {
        // XHR for Chrome/Firefox/Opera/Safari.
        xhr.open(method, url, true);
    } 
    else if (typeof XDomainRequest != "undefined") 
    {
        // XDomainRequest for IE.
        xhr = new XDomainRequest();
        xhr.open(method, url);
    } 
    else 
    {
        // CORS not supported.
        xhr = null;
    }
  
    return xhr;
}

function getGTitle(text)
{
	graphSe.title = text;
}	

// Helper method to parse the title tag from the response.
function GetTitle(text) 
{
    return text.match('<title>(.*)?</title>')[1];
}

function saveQ1()
{
	graphSe.SetMode("designer");
	designerMode();
	simpleObject(graphMe, graphSe, 1)
}

function loadQ1()
{
	LoadElements(1);
}

function LoadElements()
{
	console.log("Retrieving question data...");

    var urlparams = getURLParams();
    
	var data;

	if(window.opener && window.opener.questionPageManager && window.opener.questionPageManager.getGraphData);
		data = window.opener.questionPageManager.getGraphData(urlparams.widgetID);

	//console.log(data);

	if(typeof data.designerData === 'string')
		data.designerData = JSON.parse(data.designerData);

	if(typeof data.fbData === 'string')
		data.fbData = JSON.parse(data.fbData);

	if(typeof data.stuDisplay === 'string')
		data.stuDisplay = JSON.parse(data.stuDisplay);


	// If there was no data saved, add a default and solution tab
	if($.isEmptyObject(data.stuDisplay)){
		
	}else{
		createNewObject(data);
	}

}


// Make the actual CORS request.
function MakeCorsDelete(element) 
{
    var url = "http://54.173.144.67:3000/graphelements/"+element;

    var xhr = CreateCORSRequest('DELETE', url);
    if (!xhr) 
    {
        alert('CORS not supported');
        return;
    }

    // Response handlers.
    xhr.onload = function() 
    {
        var text = xhr.responseText;
        var title = GetTitle(text);
        console.log('Response from CORS request to ' + url + ': ' + text);
    };

    xhr.onerror = function() 
    {
        alert('Woops, there was an error making the request.');
    };

    xhr.send();
}


function getURLParams(){



	var queryParams = window.location.search;

	queryParams = queryParams.replace("?","");

	queryParams = queryParams.split("&");



	var urlVars = {};



	for(var i in queryParams){

		if(!queryParams[i])

			continue;

		var param = queryParams[i].split("=");

		urlVars[param[0]] = param[1];

	}



	var path = window.location.pathname;



	// Fix for IE versions lower than 11.

	if (!window.location.origin) {

	  window.location.origin = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port: '');

	}



	urlVars.origin = window.location.origin + "/";



	var splitPath = path.split("/");

	urlVars.contentPath = urlVars.origin + splitPath[1] + "/";

	urlVars.path = splitPath[splitPath.length - 1];



	// TEMPORARY

	//urlVars.saveAsStaticMode = false;



	return urlVars;

}

function SaveElements (graphjson, elementsjson)
{
	
    var urlparams = getURLParams();

	var url = urlparams.contentPath + 'rest/managewidget/saveGraphData?JSESSIONID=' + urlparams.sessionID;

	var questionData = {

		designerData: {graph: graphSe, elements: graphMe},

		fbData: {test:"fbtest"},

		sessionID: urlparams.sessionID,

		stuDisplay: {graph: graphSe, elements: graphMe},

		userID: urlparams.userID,

		widgetID: urlparams.widgetID

	};
	
	//console.log("Graphdata JSON: " + JSON.stringify(questionData));
	
	var data;
								
	if(window.opener && window.opener.questionPageManager && window.opener.questionPageManager.saveGraphData);
			data = window.opener.questionPageManager.saveGraphData(urlparams.widgetID, JSON.stringify(questionData)); 

	//console.log("Return Data: " + data);

}

/*
// Make the actual CORS request.
function SaveElements(graphjson, elementsjson) 
{
    var urlparams = getURLParams();
    
    console.log(urlparams);
    
    //var url = "http://54.173.144.67:3000/graphelements/";
	
	var url = urlparams.contentPath + 'rest/managewidget/saveChemData?JSESSIONID=' + urlparams.sessionID;

	var questionData = {

		designerData: {test: "designertest"},

		fbData: {test:"fbtest"},

		sessionID: urlparams.sessionID,

		stuDisplay: {test:"stutest"},

		userID: urlparams.userID,

		widgetID: urlparams.widgetID

	};

    var xhr = CreateCORSRequest('POST', url);
    if (!xhr) 
    {
        alert('CORS not supported');
        return;
    }

    // Response handlers.
    xhr.onload = function() 
    {
        var text = xhr.responseText;
        var title = GetTitle(text);
        //console.log('Response from CORS request to ' + url + ': ' + text);
        console.log(this.responseText);
    };

    xhr.onerror = function() 
    {
        alert('Woops, there was an error making the request.');
    };
  
    //xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    //var params = JSON.stringify({ graphelement: { title: graphjson, text: elementsjson } });
    var params = JSON.stringify(questionData);
    xhr.send(params);
}
*/
// Make the actual CORS request.
function UpdateElements(question, graphjson, elementsjson) 
{
    var url = "http://54.173.144.67:3000/graphelements/"+question;

    var xhr = CreateCORSRequest('PUT', url);
    if (!xhr) 
    {
        alert('CORS not supported');
        return;
    }

    // Response handlers.
    xhr.onload = function() 
    {
        var text = xhr.responseText;
        var title = GetTitle(text);
        //console.log('Response from CORS request to ' + url + ': ' + text);
        //console.log(this.responseText);
    };

    xhr.onerror = function() 
    {
        alert('Woops, there was an error making the request.');
    };

	var graphjsons = JSON.stringify(graphjson);
	var elementjsons = JSON.stringify(elementsjson);  
  	
  	//paramcheck = { graphelement: { title: graphjsons, text: elementsjsons } }
  
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    var params = JSON.stringify({graphelement:{title:graphjson,text:elementsjson}});
    //console.log("these are:"+params)
    xhr.send(params);
}


function simpleObject(object, graph, question)
{
	var x, y;
	var text;
	var tempstring = '';
	var tempstring2 = '';
	
	for(var i=0; i<object.length; i++)
	{		
		for (x in object[i]) {
			text = object[i][x];
			if(!isFunction(text)) 
			{
				tempstring += "?"+x+":"+object[i][x];
				//console.log(x);
			}
			if(x=="ghost")
			{
				//console.log(object[i].ghost);
				for (y in object[i].ghost) {
					text = object[i].ghost[y];
					if(!isFunction(text)) 
					{
						tempstring += "?ghost"+y+":"+object[i].ghost[y];
					}
				}
			}	
			if(x=="dragDxDy")
			{
				//console.log(object[i].ghost);
				for (y in object[i].dragDxDy) {
					text = object[i].dragDxDy[y];
					if(!isFunction(text)) 
					{
						tempstring += "?drag"+y+":"+object[i].dragDxDy[y];
					}
				}
			}	
			if(x=="dragstart")
			{
				//console.log(object[i].ghost);
				for (y in object[i].dragstart) {
					text = object[i].dragstart[y];
					if(!isFunction(text)) 
					{
						tempstring += "?dragstart"+y+":"+object[i].dragstart[y];
					}
				}
			}	
			if(x=="correct")
			{
				//console.log(object[i].ghost);
				for (y in object[i].correct[0]) {
					text = object[i].correct[0][y];
					if(!isFunction(text)) 
					{
						tempstring += "?correctarray"+y+":"+object[i].correct[0][y];
					}
				}
			}										
		}
		tempstring += "!!";
	}		

	for (y in graph) {
		text = graph[y];
		if(!isFunction(text)) 
		{
			tempstring2 += "?"+y+":"+graph[y];
		}
	}
	tempstring2 += "!!";

	
	SaveElements(tempstring, tempstring2);
}

var stringarray = [];

function createNewObject(data, data2)
{
	console.log("data:"+data);
	//returndata = data;
	//var grapharray = currquestion.split("!!");
	//console.log(grapharray);
	//var ln = grapharray.length;
	//console.log(ln);
	if(data.designerData.graph.what=="graph") 
	{

		var graph = data.designerData.elements[i];
	
		for (y in graph) {
			graphSe[i][y] = graph[y];
		}	
		
		graphSe.title=data.designerData.graph.title;
		graphSe.xaxis=data.designerData.graph.xaxis;
		graphSe.yaxis=data.designerData.graph.yaxis;

		graphSe.fquestion=data.designerData.graph.fquestion;
		document.getElementById('questiontext').innerHTML=data.designerData.graph.fquestion;
		//document.getElementById('tempquestiontext').value = data.designerData.graph.fquestion;

		document.getElementById('titletext').value=data.designerData.graph.title;
		document.getElementById('yaxistext').value=data.designerData.graph.yaxis;
		document.getElementById('xaxistext').value=data.designerData.graph.xaxis;

		document.getElementById('titletextstatic').value=data.designerData.graph.title;
		document.getElementById('yaxistextstatic').value=data.designerData.graph.yaxis;
		document.getElementById('xaxistextstatic').value=data.designerData.graph.xaxis;
		
		document.getElementById('xinc').value = data.designerData.graph.xinc;
		xincChange(document.getElementById('xinc').value);

		document.getElementById('yinc').value = data.designerData.graph.yinc;
		yincChange(document.getElementById('yinc').value);

		document.getElementById('xmin').value = data.designerData.graph.xmin;
		xminChange(document.getElementById('xmin').value);

		document.getElementById('ymin').value = data.designerData.graph.ymin;
		yminChange(document.getElementById('ymin').value);	
		

		//console.log("grid:"+data.designerData.graph.grid);

		if(data.designerData.graph.grid){graphSe.grid==true; gridt=1; document.getElementById("gridtoggle").checked = true;	} else {graphSe.grid==false; gridt=0; document.getElementById("gridtoggle").checked = false;};
		if(data.designerData.graph.value){valuet=1; graphSe.value=true; document.getElementById("valuetoggle").checked = true;} else {valuet=0; graphSe.value=false;document.getElementById("valuetoggle").checked = false;};
		if(data.designerData.graph.titleshow){document.getElementById("titletoggle").checked = true;} else {document.getElementById("titletoggle").checked = false;};
		if(data.designerData.graph.axisshow){document.getElementById("xytoggle").checked = true;} else {document.getElementById("xytoggle").checked = false;};
		if(data.designerData.graph.snapIt){document.getElementById("snaptoggle").checked = true;} else {document.getElementById("snaptoggle").checked = false;};
		//graphSe.snapIt=(data.designerData.graph.snapIt=="true");
		
		graphSe.SetMaxes();	    

		update();	
	}		

	for(var i=0; i<data.designerData.elements.length; i++)
	{
		//var newobjectarray = new Object();
		
		//console.log("loop"+i);
		//stringarray = grapharray[i].split("?");
		//console.log(stringarray);
		for(var j=0; j<stringarray.length; j++)
		{
			//var splitstring = stringarray[j].split(":");
			//console.log(splitstring[0], splitstring[1]);
			//newobjectarray[splitstring[0]] = splitstring[1]
		}
		//console.log("HERE:"+newobjectarray.what);
		if(data.designerData.elements[i].what=="point") {

			graphMe[i] = new Point( data.designerData.elements[i].cc, data.designerData.elements[i].x, data.designerData.elements[i].y, data.designerData.elements[i].radius);
			
			var graph = data.designerData.elements[i];
		
			for (y in graph) {
				graphMe[i][y] = graph[y];
			}	
			
			graphMe[i].SetSettings();
	
		
		}
		if(data.designerData.elements[i].what=="line") 
		{
			graphMe[i] = new Line( data.designerData.elements[i].cc, graphSe.ConvertXgToXpx(data.designerData.elements[i].xsg), graphSe.ConvertYgToYpx(data.designerData.elements[i].ysg), graphSe.ConvertXgToXpx(data.designerData.elements[i].xeg), graphSe.ConvertYgToYpx(data.designerData.elements[i].yeg), data.designerData.elements[i].width );
			
			var graph = data.designerData.elements[i];
		
			for (y in graph) {
				graphMe[i][y] = graph[y];
			}	

			graphMe[i].SetSettings();
								
		}
		if(data.designerData.elements[i].what=="curve") 
		{
		
			graphMe[i] = new Curve(data.designerData.elements[i].cc, data.designerData.elements[i].width) 

			var graph = data.designerData.elements[i];
		
			for (y in graph) {
				graphMe[i][y] = graph[y];
			}	
			
		 	graphMe[i].SetSettings();
		
	
		}
		if(data.designerData.elements[i].what=="poly") 
		{
			//var ptsarray = [];
		
			graphMe[i] = new Polyline( data.designerData.elements[i].cc, 1, data.designerData.elements[i].width )
			graphMe[i].doFill = true;

			var graph = data.designerData.elements[i];
		
			for (y in graph) {
				graphMe[i][y] = graph[y];
			}	
			
			graphMe[i].PathMe();
		 	graphMe[i].SetSettings();

			/*var temppts = data.designerData.elements[i].pts.split(",");
			for(var l=0; l<temppts.length; l+=2)
			{
				ptsarray[l]=temppts[l];
				var newtemppts = new Object();
				newtemppts.x = graphSe.ConvertXgToXpx(temppts[l]);
				newtemppts.y = graphSe.ConvertYgToYpx(temppts[l+1]);
				console.log(newtemppts);
				graphMe[i].AddPoint(newtemppts);
			
				//console.log(areapoints);
			}*/
		
			//graphMe[0].pts = ptsarray;
			//console.log(ptsarray);
		
		}
	}	

	
}	

var studentddd;
var studentidd;
	
function createNewObjectSW(data, data2)
{
	console.log("data:"+data);
	
	//parent.graphsrendered>3
	
	if(data!=undefined)
	{
		if(data.length>10)
		{
			data = JSON.parse(data);
			studentidd = data2;
		}
	}
	
	//var teststring = typeof data;
	//console.log("typeof:"+teststring);
	//if(data!='')
	//{
	//	data = JSON.parse(data);
	//}
	//var grapharray = currquestion.split("!!");
	//console.log(grapharray);
	//var ln = grapharray.length;
	//console.log(ln);
	if(data!="")
	{
		if(data.graph.what=="graph") 
		{

			var graph = data.elements[i];
	
			for (y in graph) {
				graphSe[i][y] = graph[y];
			}	
		
			graphSe.title=data.graph.title;
			graphSe.xaxis=data.graph.xaxis;
			graphSe.yaxis=data.graph.yaxis;

			graphSe.fquestion=data.graph.fquestion;
			document.getElementById('questiontext').innerHTML=data.graph.fquestion;
			if(document.getElementById('tempquestiontext')) document.getElementById('tempquestiontext').value = data.graph.fquestion;

			if(document.getElementById('titletext')) document.getElementById('titletext').value=data.graph.title;
			if(document.getElementById('yaxistext')) document.getElementById('yaxistext').value=data.graph.yaxis;
			if(document.getElementById('xaxistext')) document.getElementById('xaxistext').value=data.graph.xaxis;

			if(document.getElementById('titletextstatic')) document.getElementById('titletextstatic').innerHTML=data.graph.title;
			if(document.getElementById('yaxistextstatic')) document.getElementById('yaxistextstatic').innerHTML=graphSe.yaxis;
			if(document.getElementById('xaxistextstatic')) document.getElementById('xaxistextstatic').innerHTML=data.graph.xaxis;
		
			if(document.getElementById('xinc')) document.getElementById('xinc').value = data.graph.xinc;
			xincChange(document.getElementById('xinc').value);

			if(document.getElementById('yinc')) document.getElementById('yinc').value = data.graph.yinc;
			yincChange(document.getElementById('yinc').value);

			if(document.getElementById('xmin')) document.getElementById('xmin').value = data.graph.xmin;
			xminChange(document.getElementById('xmin').value);

			if(document.getElementById('ymin')) document.getElementById('ymin').value = data.graph.ymin;
			yminChange(document.getElementById('ymin').value);	
		

			//console.log("grid:"+data.graph.grid);

			if(data.graph.grid){graphSe.grid==true; gridt=1; document.getElementById("gridtoggle").checked = true;	} else {graphSe.grid==false; gridt=0; document.getElementById("gridtoggle").checked = false;};
			if(data.graph.value){valuet=1; graphSe.value=true; document.getElementById("valuetoggle").checked = true;} else {valuet=0; graphSe.value=false;document.getElementById("valuetoggle").checked = false;};
			if(data.graph.titleshow){document.getElementById("titletoggle").checked = true;} else {document.getElementById("titletoggle").checked = false;};
			if(data.graph.axisshow){document.getElementById("xytoggle").checked = true;} else {document.getElementById("xytoggle").checked = false;};
			if(data.graph.snapIt){document.getElementById("snaptoggle").checked = true;} else {document.getElementById("snaptoggle").checked = false;};
			//graphSe.snapIt=(data.graph.snapIt=="true");
		
			graphSe.SetMaxes();	    

			update();	
		}		
		for(var i=0; i<data.elements.length; i++)
		{
			//var newobjectarray = new Object();

			//console.log("!!!!!!!!!!!!!!!!!!!!!!!!!!loop"+i);
			//stringarray = grapharray[i].split("?");
			//console.log(stringarray);
			for(var j=0; j<stringarray.length; j++)
			{
				//var splitstring = stringarray[j].split(":");
				//console.log(splitstring[0], splitstring[1]);
				//newobjectarray[splitstring[0]] = splitstring[1]
			}
			//console.log("HERE:"+newobjectarray.what);
			if(data.elements[i].what=="point") {

				graphMe[i] = new Point( data.elements[i].cc, data.elements[i].x, data.elements[i].y, data.elements[i].radius);
			
				var graph = data.elements[i];
		
				for (y in graph) {
					graphMe[i][y] = graph[y];
				}	
			
				graphMe[i].SetSettings();
	
		
			}
			if(data.elements[i].what=="line") 
			{
				graphMe[i] = new Line( data.elements[i].cc, graphSe.ConvertXgToXpx(data.elements[i].xsg), graphSe.ConvertYgToYpx(data.elements[i].ysg), graphSe.ConvertXgToXpx(data.elements[i].xeg), graphSe.ConvertYgToYpx(data.elements[i].yeg), data.elements[i].width );
			
				var graph = data.elements[i];
		
				for (y in graph) {
					graphMe[i][y] = graph[y];
				}	

				graphMe[i].SetSettings();
								
			}
			if(data.elements[i].what=="curve") 
			{
		
				graphMe[i] = new Curve(data.elements[i].cc, data.elements[i].width) 

				var graph = data.elements[i];
		
				for (y in graph) {
					graphMe[i][y] = graph[y];
				}	
			
				graphMe[i].SetSettings();
		
	
			}
			if(data.elements[i].what=="poly") 
			{
				//var ptsarray = [];
		
				graphMe[i] = new Polyline( data.elements[i].cc, 1, data.elements[i].width )
				graphMe[i].doFill = true;

				var graph = data.elements[i];
		
				for (y in graph) {
					graphMe[i][y] = graph[y];
				}	

				graphMe[i].PathMe();			

				graphMe[i].SetSettings();

				/*var temppts = data.elements[i].pts.split(",");
				for(var l=0; l<temppts.length; l+=2)
				{
					ptsarray[l]=temppts[l];
					var newtemppts = new Object();
					newtemppts.x = graphSe.ConvertXgToXpx(temppts[l]);
					newtemppts.y = graphSe.ConvertYgToYpx(temppts[l+1]);
					console.log(newtemppts);
					graphMe[i].AddPoint(newtemppts);
			
					//console.log(areapoints);
				}*/
		
				//graphMe[0].pts = ptsarray;
				//console.log(ptsarray);
		
			}
		}	

	}
	
}		

function isFunction(functionToCheck) {
 	var getType = {};
 	return functionToCheck && getType.toString.call(functionToCheck) === '[object Function]';
}

function resize()
{
	var offset = $("#container").offset().left;
	var offsettop = $("#container").offset().top;
	console.log(graphSe.mode);

	var leftos = offset+57+30
	var topos = offsettop+179+90;
	var topos2 = offsettop+163+90;

	document.getElementById("CanvasAnimate").style.left = leftos+"px";
	document.getElementById("CanvasGraph").style.left = leftos+"px";
	document.getElementById("CanvasAnimate2").style.left = leftos-40+"px";

	if(graphSe.mode=="student")
	{
		document.getElementById("CanvasAnimate").style.top = topos-90+"px";
		document.getElementById("CanvasGraph").style.top = topos-90+"px";
		document.getElementById("CanvasAnimate2").style.top = topos2-90+"px";
	} else 
	{
		document.getElementById("CanvasAnimate").style.top = topos+"px";
		document.getElementById("CanvasGraph").style.top = topos+"px";
		document.getElementById("CanvasAnimate2").style.top = topos2+"px";	
	}		
	
}	

function resize2()
{
	var offset = $("#container").offset().left;
	var offsettop = $("#container").offset().top;
	console.log(offsettop);

	var leftos = offset+57+30
	var topos = offsettop+179+90;
	var topos2 = offsettop+163+90;

	document.getElementById("CanvasAnimate").style.left = leftos+"px";
	document.getElementById("CanvasGraph").style.left = leftos+"px";
	document.getElementById("CanvasAnimate2").style.left = leftos-40+"px";

	document.getElementById("CanvasAnimate").style.top = topos-90+"px";
	document.getElementById("CanvasGraph").style.top = topos-90+"px";
	document.getElementById("CanvasAnimate2").style.top = topos2-90+"px";
	
}		

function correctMode()
{
	document.getElementById('titletextstatic').innerHTML = graphSe.title;
	if(graphSe.titleshow) $('#titletextstatic').removeClass("hide");

	document.getElementById('xaxistextstatic').innerHTML = graphSe.xaxis;
	if(graphSe.axisshow) $('#xaxistextstatic').removeClass("hide");

	document.getElementById('yaxistextstatic').innerHTML = graphSe.yaxis;
	if(graphSe.axisshow) $('#yaxistextstatic').removeClass("hide");	

	$('#student').addClass("btn-main-off");
	$('#designer').addClass("btn-main-off");
	$('#correct').addClass("btn-main-on");

	$('#correct').removeClass("btn-main-off");
	$('#designer').removeClass("btn-main-on");
	$('#student').removeClass("btn-main-on");

	document.getElementById("correct").disabled = true; 
	document.getElementById("designer").disabled = false; 
	document.getElementById("student").disabled = false; 

	document.getElementById("label").disabled = true; 

	$('#toptools').addClass("hide");
	$('#bottomtools').addClass("hide");
	$('#drawingtools').addClass("hide");
	$('#studentdetails').addClass("hide");

	$('#tempquestiontext').addClass("hide");

	
	graphSe.SetMode("correct");

	if(graphMe.length==0)
	{
		$('#emptydesigner').removeClass("hide");		
	}

	if(graphMe.length!=0) graphMe[gmloc-1].SetSettings();

}

function deleteAll()
{
	 undoMe = []; 
	 graphMe = []; 
	 graphSe.ops = []; 
	 graphSe.opsRedo = [];
	 //if( graphSe.mode == "designer" ) {graphSe.opsDesigner = []; graphSe.opsRedoDesigner = []; }
	 //else if( graphSe.mode == "correct" ) { graphSe.opsCorrect = []; graphSe.opsRedoCorrect = []; }
	 //else if( graphSe.mode == "student" ) { graphSe.opsStudent = []; graphSe.opsRedoStudent = []; }
	 graphSe.opsDesigner = []; 
	 graphSe.opsRedoDesigner = [];
	 graphSe.opsCorrect = []; 
	 graphSe.opsRedoCorrect = [];
	 graphSe.opsStudent = []; 
	 graphSe.opsRedoStudent = [];

	 resetSetSettings();

}

function resetSetSettings()
{

	$('#bottomtools').addClass("hide");
	$('#interactive').addClass("hide");
	$('#interactivetools').addClass("hide");
	$('#drawingtools').addClass("hide");
	$('#labeldetails').addClass("hide");

	npoints = 0;
	lpoints = 0;
	cpoints = 0;
	apoints = 0;
}	

function designerMode()
{
	$('#titletextstatic').addClass("hide");
	$('#xaxistextstatic').addClass("hide");
	$('#yaxistextstatic').addClass("hide");

	$('#student').addClass("btn-main-off");
	$('#correct').addClass("btn-main-off");
	$('#designer').addClass("btn-main-on");

	$('#designer').removeClass("btn-main-off");
	$('#correct').removeClass("btn-main-on");
	$('#student').removeClass("btn-main-on");

	document.getElementById("designer").disabled = true; 
	document.getElementById("correct").disabled = false; 
	document.getElementById("student").disabled = false; 

	document.getElementById("label").disabled = true; 

	$('#toptools').removeClass("hide");
	$('#bottomtools').removeClass("hide");
	$('#drawingtools').addClass("hide");
	$('#studentdetails').addClass("hide");
	
	graphSe.SetMode("designer");

	$('#emptydesigner').addClass("hide");		

	if(graphMe.length!=0) graphMe[gmloc-1].SetSettings();

	$('#tempquestiontext').removeClass("hide");


}

function studentMode()
{
	$('#student').addClass("btn-main-on");
	$('#designer').addClass("btn-main-off");
	$('#correct').addClass("btn-main-off");

	$('#designer').removeClass("btn-main-on");
	$('#correct').removeClass("btn-main-on");
	$('#student').removeClass("btn-main-off");

	document.getElementById("designer").disabled = false; 
	document.getElementById("correct").disabled = false; 
	document.getElementById("student").disabled = true; 

	$('#toptools').addClass("hide");
	$('#bottomtools').addClass("hide");
	$('#drawingtools').addClass("hide");
	$('#interactive').addClass("hide");
	$('#studentdetails').removeClass("hide");
		
			 $('#interactivetools').addClass("hide");		
			 $('#labeldetails').addClass("hide");		

	document.getElementById("label").disabled = false; 
	
	graphSe.SetMode("student");

	$('#emptydesigner').addClass("hide");		

	document.getElementById('questiontext').innerHTML = graphSe.fquestion

	//if(graphMe.length!=0) graphMe[gmloc-1].SetSettings();
	$('#tempquestiontext').addClass("hide");

	$('#titletext').addClass("hide");
	$('#yaxistext').addClass("hide");
	$('#xaxistext').addClass("hide");

	$('#titletextstatic').removeClass("hide");
	$('#yaxistextstatic').removeClass("hide");
	$('#xaxistextstatic').removeClass("hide");
	
	$('#deletebutton1').addClass("hide");

}

function leftArrow()
{
	if(gmloc>=2)
	{
		gmloc--;
		graphMe[gmloc-1].SetSettings();
	} 
}

function rightArrow()
{
	if(gmloc<=graphMe.length-1)
	{
		gmloc++;
		graphMe[gmloc-1].SetSettings();
	} 
}

function GetElement(text)
{
	graphMe[gmloc-1].SetElementLabel(text);
}

function GetCorrectStudentLabel(text)
{
	graphMe[gmloc-1].SetCorrectStudentLabel(text);
	document.getElementById('elabel').style.background = "none";
	graphMe[gmloc-1].setStudentColor();
}

function GetCorrectLabel(text)
{
	graphMe[gmloc-1].SetCorrectLabel(text);
}


function setQuestion(number)
{
	questionNumber = number;
	//document.getElementById('qdrop').value = this.relementlabel;

}

function GetRelativeElement(text)
{
	graphMe[gmloc-1].SetRelativeElementLabel(text);
}

function bookColor()
{
	var curr = graphMe[gmloc-1];

	if(curr.GetBookColor()=="No")
	{
		curr.SetBookColor("Yes");
		document.getElementById('bcbutton').innerHTML = 'Use Book Color <span class="glyphicon glyphicon-checkedmm"></span>';

	} else 
	{
		curr.SetBookColor("No");
		document.getElementById('bcbutton').innerHTML = 'Use Book Color <span class="glyphicon glyphicon-uncheckedmm"></span>';
					
	}
}

function labelUpdate(text)
{
	graphMe[gmloc-1].label = text;
	graphMe[gmloc-1].UpdateLabelText();

}

function labelAMUpdate(text)
{
	graphMe[gmloc-1].labelam = text;

}

function TAElement(text)
{
	graphMe[gmloc-1].taelement = text;
	graphMe[gmloc-1].TrackAlong( text );
}

function xUpdate(newXg)
{	
	//graphMe[gmloc-1].x = graphSe.reverseXC(n);
	graphMe[gmloc-1].xg = newXg;
	graphMe[gmloc-1].SnapMe( );
	//document.getElementById('xpoint').value=convertXC(n);
}

function xsUpdate(text)
{
	var ng = Number(text)
	
	graphMe[gmloc-1].xsg = ng;
	graphMe[gmloc-1].SnapMe( );
	graphMe[gmloc-1].CalculateSlope();
	graphMe[gmloc-1].UpdateSlope();
}

function cxsUpdate(text)
{
	var ng = Number(text)
	
	graphMe[gmloc-1].pts[0] = ng;
	graphMe[gmloc-1].SnapMe( );

}

function cysUpdate(text)
{
	var ng = Number(text)
	
	graphMe[gmloc-1].pts[1] = ng;
	graphMe[gmloc-1].SnapMe( );
}

function cxmUpdate(text)
{
	var ng = Number(text)
	
	graphMe[gmloc-1].pts[2] = ng;
	graphMe[gmloc-1].SnapMe( );

}

function cymUpdate(text)
{
	var ng = Number(text)
	
	graphMe[gmloc-1].pts[3] = ng;
	graphMe[gmloc-1].SnapMe( );
}

function cxeUpdate(text)
{
	var ng = Number(text)
	
	graphMe[gmloc-1].pts[4] = ng;
	graphMe[gmloc-1].SnapMe( );

}

function cyeUpdate(text)
{
	var ng = Number(text)
	
	graphMe[gmloc-1].pts[5] = ng;
}

function apUpdateNoFix(text, number)
{
	var ng = Number(text)
	
	graphMe[gmloc-1].pts[number] = ng;
	graphMe[gmloc-1].SnapMe( );
}

function apUpdate(text, number)
{
	var ng = Number(text)
	
	graphMe[gmloc-1].pts[number+2] = ng;
	graphMe[gmloc-1].SnapMe( );
}

function xeUpdate(text)
{
	var ng = Number(text)
	
	graphMe[gmloc-1].xeg = ng;
	graphMe[gmloc-1].SnapMe( );
	graphMe[gmloc-1].CalculateSlope();
	graphMe[gmloc-1].UpdateSlope();
}

function yUpdate(newYg)
{
	graphMe[gmloc-1].yg = newYg;
	graphMe[gmloc-1].SnapMe( );
	//graphMe[gmloc-1].y = graphSe.reverseYC(n);
	//graphMe[gmloc-1].UpdateLabelText();
}

function ysUpdate(text)
{
	var ng = Number(text)
	
	graphMe[gmloc-1].ysg = ng;
	graphMe[gmloc-1].SnapMe( );
	graphMe[gmloc-1].CalculateSlope();
	graphMe[gmloc-1].UpdateSlope();
}

function yeUpdate(text)
{
	var ng = Number(text)
	
	graphMe[gmloc-1].yeg = ng;
	graphMe[gmloc-1].SnapMe( );
	graphMe[gmloc-1].CalculateSlope();
	graphMe[gmloc-1].UpdateSlope();
}

function slopeUpdate(num)
{
	graphMe[gmloc-1].m = num;
	graphMe[gmloc-1].LineUpdate();
}	

function GetTitle(text)
{
	graphSe.title = text;
}	

function SayFeedback( txt )
{
    document.getElementById("feedbacktext").innerHTML = txt
}

function getYA(text)
{
	graphSe.yaxis = text;
}	

function getXA(text)
{
	graphSe.xaxis = text;
}	

function interactiveb()
{
	$('#binteractivero').removeClass("hide")
	$('#bstaticro').addClass("hide")
}

function staticb()
{
	$('#binteractivero').addClass("hide")
	$('#bstaticro').removeClass("hide")
}

function xincChange(x)
{
	var n = Number(x)
	
	graphSe.xinc = n;
	graphSe.SetMaxes();
	
	graphSe.CalcConverters();
	
	if(graphMe.length>0) graphMe[gmloc-1].SetSettings();
}	

function yincChange(y)
{
	var n = Number(y)

	graphSe.yinc = n;
	graphSe.SetMaxes();
	
	graphSe.CalcConverters();

	if(graphMe.length>0) graphMe[gmloc-1].SetSettings();
}	

function xminChange(x)
{
	var n = Number(x)

	graphSe.xmin = n;
	graphSe.SetMaxes();

	if(graphMe.length>0) graphMe[gmloc-1].SetSettings();
}	

function yminChange(y)
{
	var n = Number(y)

	graphSe.ymin = n;
	graphSe.SetMaxes();

	if(graphMe.length>0) graphMe[gmloc-1].SetSettings();
}	

function StartMM( )
{

document.getElementById("gridtoggle").checked = true;	
document.getElementById("xytoggle").checked = true;	
document.getElementById("titletoggle").checked = true;	
document.getElementById("snaptoggle").checked = false;	
document.getElementById("valuetoggle").checked = true;	

	
$(document).ready(function() {

	
});


}

//window.onload=StartMM;