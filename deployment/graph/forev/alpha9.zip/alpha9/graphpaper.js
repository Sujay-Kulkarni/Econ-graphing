var FPS = 10;
var FDMS = 1/FPS*1000.0;
var D2R = Math.PI/180.0;
var R2D = 180.0/Math.PI;
var r90 = Math.PI/2;
var E = Math.E;

var wwr = 1.0;
var whr = 1.0;

var can, ctx, can2, ctx2;
var mouseIsDown = false;
var cancursor;

var graphMe = [ ];
var animMe = [ ];
//var undoMe = [ ];

var doLabelMode = false;
var doPointerMode = false;
var drawPointMode = false;
var drawLineMode = false;
var drawCurveMode = false;
var drawFillPolylineMode = false;
var theCurve = null;
var thePoly = null;
var anchorPt = null;
var oldPt;
var newPt   = null;
var newLine = null;

var npoints = 0;
var lpoints = 0;
var cpoints = 0;
var apoints = 0;

var dragObj = null;

graphSe = new Graph();

function Graph()
{
     this.what = 'graph';
     this.grid = true;
     this.value = true;

	 this.fquestion = "Write your question here"

     this.showpos = false;
     
     this.xinc = 1;
     this.xmin = 0;
     this.xmax = 16;
     
     this.yinc = 1;
     this.ymin = 0;
     this.ymax = 16;

	 this.xaxis='';
	 this.yaxis='';
	 this.title;
	 
	 this.nlines = 16;
	 this.wdPx = 384;
	 this.htPx = 384;
	 
	 this.handleColor = "rosybrown";
	 this.handleRadius = 6;
	 
	 this.snapIt = false;
	 this.mode = "designer";
	 this.boo = false;
	 
	 this.ops;
	 this.opsRedo;
	 
	 this.opsDesigner = [ ];
	 this.opsRedoDesigner = [ ];
	 
	 this.opsCorrect = [ ];
	 this.opsRedoCorrect = [ ];
	 
	 this.ops = this.opsDesigner;
	 this.opsRedo = this.opsRedoDesigner;
	 
	 this.title = '';

	 this.axisshow = true;
	 this.titleshow = true;
	 
	 this.opsStudent = [ ];
	 this.opsRedoStudent = [ ];

     this.correct = [ ];
	 
	 this.tgcorrect;
	 
	 this.SetMode = function( md )
	 {
	     switch( md )
	     {
	         case "student":
	             this.boo = true;
	             this.ops = this.opsStudent;
	             this.opsRedo = this.opsRedoStudent;
	             if( this.mode == "correct" ) this.CorrectToDesigner( );
	             break;
	         
	         case "correct":
	             this.boo = true;
	             this.ops = this.opsCorrect;
	             this.opsRedo = this.opsRedoCorrect;
	             if( this.mode == "designer" || this.mode == "student" ) this.DesignerToCorrect( );
	             break;
	             
	         case "designer": 
	             this.boo = false;
	             this.ops = this.opsDesigner;
	             this.opsRedo = this.opsRedoDesigner;
	             if( this.mode == "correct" || this.mode == "student" ) this.CorrectToDesigner( );
	             break;
	     }
	     
	     this.mode = md;
	 }
	 
	 this.CorrectToDesigner = function( )
	 {
	     for( var i = 0, ln = graphMe.length; i < ln; i++ )
	         graphMe[i].CorrectToDesigner( );  
	 }
	 
	 this.DesignerToCorrect = function( )
	 {
	     //if( graphSe.mode != "student" )
	     //{
	        for( var i = 0, ln = graphMe.length; i < ln; i++ )
	        {    
	            graphMe[i].DesignerToCorrect( ); 
			    graphMe[i].iscorrect = null;
	        }    
	     
	     //}
	     
	     //else
	     //{
	         for( var i = graphMe.length-1; i >= 0; i-- )
	         {
	             var gi = graphMe[i];
	             if( gi.mode == "student" )
	             {
	                 graphMe.splice(i,1);
	                 gmloc--;
	             }
	          }
	      
	      	 CheckGraph();
    
	     //}       
	 }
	 
	 this.AddElement = function( gMe, gobj )
     {
         var n = gMe.push( gobj );
    
         if( gMe == graphMe ) gmloc = graphMe.length;
         
         this.OpsAddElement( n-1 );
     }
      
     this.HitPt = function( mpt, xg, yg, tol )
     {
         if( tol == undefined ) tol = this.handleRadius;
         
         var xpx = graphSe.ConvertXgToXpx( xg );
         var ypx = graphSe.ConvertYgToYpx( yg ); 
         var dx = xpx - mpt.x;
         var dy = ypx - mpt.y;
            
         return Math.sqrt(dx*dx + dy*dy) < tol;
     }
 	     	 
	 this.SetMaxes = function()
	 {
	 	 this.xmax = (this.xinc*this.nlines)+this.xmin;
	 	 this.ymax = (this.yinc*this.nlines)+this.ymin;
	 	
	 	 document.getElementById('xmax').value = this.xmax;
	 	 document.getElementById('ymax').value = this.ymax;

	 }
	 
	 this.SnapOnOff = function( tf )
	 {
	     this.snapIt = tf;
	     
	     //if( tf ) this.SnapAll( );
	     this.SnapAll( );
	     
	     //console.log("SnapOnOff: ", this.snapIt);
	 }
	 
	 this.SnapX = function( xg )
     {
         var sxg = xg;
         var xincd2 = graphSe.xinc/2;
         
         if( graphSe.snapIt )
         {
             var sxg = Math.round(xg/xincd2)*xincd2;
         }
         
         return sxg;
     
     }
     
     this.SnapY = function( yg )
     {
         var syg = yg;
         var yincd2 = graphSe.yinc/2;
         
         if( graphSe.snapIt )
         {
             var syg = Math.round(yg/yincd2)*yincd2;
         }
         
         return syg;
     }
     
     this.SnapAll = function( )
     {
         for( var i = 0, gln = graphMe.length; i < gln; i++ )
         {
             graphMe[i].SnapMe( );
             if( gmloc == i+1 ) graphMe[i].SetElementPoints( );
         }
     }
     
     this.NoHover = function( )
     {
         for( var i = 0, gln = graphMe.length; i < gln; i++ )
             graphMe[i].ControlMe( false );
     }
     
     this.OneHover = function( )
     {
         for( var i = 0, gln = graphMe.length; i < gln; i++ )
         {
             var gi = graphMe[i];
             if( gi != hoverObj ) gi.ControlMe( false );
         }
     }
	 
	 this.CalcConverters = function( )
	 {
	     this.px2gX = (this.xmax-this.xmin)/this.wdPx;
	     this.g2pxX = 1/this.px2gX;	
	     this.px2gY = (this.ymax-this.ymin)/this.htPx;
	     this.g2pxY = 1/this.px2gY; 
	 }
	 
	 this.convertX = function(x)
     {
	     return this.xmin+(x*this.xinc);
     }
     
     this.ConvertXpxToXg = function(xPx)
	 {
		 return this.xmin + xPx*this.px2gX;
	 }
	 
	 this.ConvertXgToXpx = function(xg)
	 {
	     return (xg - this.xmin)*this.g2pxX;
	 }

     this.convertY = function(y)
     {
	     return this.ymin+(y*this.yinc);
     }
     
     this.ConvertYpxToYg = function(yPx)
	 {
		 return this.ymax - yPx*this.px2gY;
	 }
	 
	 this.ConvertYgToYpx = function(yg)
	 {
	     return (this.ymax - yg)*this.g2pxY;
	 }

     this.reverseXC = function(x)
     {
	     return (x/(this.xmax-this.xmin))*this.wdPx
     }

     this.reverseYC = function(y)
     {
	    var n = (y/(this.ymax-this.ymin))*this.htPx;
	    return this.htPx-n;
     }
     
     this.OpsAddElement = function( gloc )
     {
         this.ops.push( { op: "add", gloc: gloc } );
     }
     
     this.OpsDeleteElement = function( gobj )
     {
         this.ops.push( { op: "delete", gobj: gobj } );
     }
     
     this.OpsMoveElement = function( gobj, type, dx, dy )
     {
         this.ops.push( { op: "move", gobj: gobj, type: type, dx: dx, dy: dy } );
     }
     
     this.Undo = function( e )
     {
         switch( e.type )
         {
             case "mousedown":
                 undoTmr = setTimeout(function()
                 { 
                     $('#myModal').modal()
                     /*undoMe = []; 
                     graphMe = []; 
                     this.ops = []; 
                     this.opsRedo = [];
                     //if( this.mode == "designer" ) {this.opsDesigner = []; this.opsRedoDesigner = []; }
                     //else if( this.mode == "correct" ) { this.opsCorrect = []; this.opsRedoCorrect = []; }
                     //else if( this.mode == "student" ) { this.opsStudent = []; this.opsRedoStudent = []; }
                     this.opsDesigner = []; 
                     this.opsRedoDesigner = [];
                     this.opsCorrect = []; 
                     this.opsRedoCorrect = [];
                     this.opsStudent = []; 
                     this.opsRedoStudent = [];*/
                 }, 2000);
                 break;
            
             case "mouseup":
                 clearTimeout( undoTmr );
                 
                 var op = this.ops.pop( );
                 
                 if( op != undefined )
                 {
                     this.opsRedo.push( op );
                     switch( op.op )
                     {
                         case "add":
                             var gobj = this.PopGraphMe( );
                             if( gobj != undefined )
                             {
                                 op.gobj = gobj;
                             }
                             break;
                        
                         case "delete":
                             var gobj = op.gobj;
                             gmloc = graphSe.InsertElement( gobj );
                             gobj.SetSettings( );
                             gobj.ControlMe( true );
                             break;
                            
                         case "move":
                             op.gobj.MoveMe( op.type, op.dx, op.dy );
                             break;
                     }
                 }
                 break;
         }
     }

     this.Redo = function ( e )
     {
         var op = this.opsRedo.pop( );
    
         if( op != undefined )
         {
             this.ops.push( op );
             switch( op.op )
             {
                 case "add":
                     if( op.gobj != undefined )
                     {
                         graphSe.InsertElement( op.gobj );
                     }
                     break;
                     
                 case "delete":
                     for( var i = 0, done = false, ln = graphMe.length; i < ln && !done; i++ )
                     {
                         if( graphMe[i] == op.gobj ) 
                         {
                             graphMe.splice(i, 1)
                             if( i < gmloc - 1 ) gmloc--;
                             done = true;
                             var gobj = graphMe[gmloc-1]
                             if( gobj != undefined )
                             {
                                 gobj.SetSettings( );
                                 gobj.ControlMe( true );
                             } 
                             //else resetSetSettings();
                         }
                     }
                     break;
                     
                         
                 case "move":
                     op.gobj.MoveMe( op.type, -op.dx, -op.dy );
                     break;
             }
         }
     }
     
     this.PopGraphMe = function( )
     {
         var gi;
         for( var le = graphMe.length - 1, poped = false; le >= 0 && !poped; le-- )
         {
             gi = graphMe[le];
             if( gi.mode == graphSe.mode )
             {
                 graphMe.splice(le,1);
                 poped = true;
             }
         }
         
         return gi;
     }
     
     this.FindInGraph = function( lbl )
     {
         var gi;
         for( var i = 0, fnd = false, ln = graphMe.length; i < ln && !fnd; i++ )
         {
             gi = graphMe[i];
             fnd = gi.label == lbl; 
         }
             
         return fnd ? gi : null;
     }
     
     this.DeleteElement = function( )
     {
         var gobj = graphMe[gmloc-1];
         if( gobj != undefined )
         {
             graphSe.OpsDeleteElement( gobj );
             graphMe.splice(gmloc-1,1);
             gmloc--;
             if( gmloc <= 0 ) gmloc = 1;
             if( graphMe.length > 0 )
             {
                 var gg = graphMe[gmloc-1];
                 gg.SetSettings( );
                 gg.ControlMe( true );
             } else
             {
             	resetSetSettings();
             }	
         }
     }
     
     this.InsertElement = function( gobj )
     {
         var tc = gobj.label[0];
         var nn = Number( gobj.label.substr(1) );
         
         for( var i = 0, done = false, ln = graphMe.length; i < ln && !done; i++ )
         {
             var gi = graphMe[i];
             if( gi.label[0] == tc && Number(gi.label.substr(1)) > nn )
             {
                 graphMe.splice(i,0,gobj);
                 done = true;
             }
         }
         
         if( !done ) { graphMe.push( gobj ); i = graphMe.length; }
         
         return i; 
     }
     

	 this.SetMaxes();
	 this.CalcConverters();
}



function Start( )
{ 
    paper.setup( document.getElementById('CanvasGraph') );  
    paper.setup( document.getElementById('CanvasAnimate') );
    paper.setup( document.getElementById('CanvasAnimate2') );
    
    can = document.getElementById("CanvasAnimate");
    ctx = can.getContext("2d");

    can2 = document.getElementById("CanvasAnimate2");
    ctx2 = can2.getContext("2d");    
    
    can.addEventListener("mousedown", MouseDown, false);
    can.addEventListener("mousemove", MouseMove, false);
    can.addEventListener("touchstart", TouchDown, false);
    can.addEventListener("touchmove", TouchXY, true);
    can.addEventListener("touchend", TouchUp, false);
    can.addEventListener("mouseout", PosOff, false);
    can.addEventListener("mouseover", PosOn, false);
 
    document.body.addEventListener("mouseup", MouseUp, false);
    document.body.addEventListener("touchcancel", TouchUp, false);
    
    var dlBtn = document.getElementById("pointerBtn");
    dlBtn.addEventListener("click", DoPointer, false);
    
    dlBtn = document.getElementById("drawpointBtn");
    dlBtn.addEventListener("click", DoDrawPoint, false);
    
    dlBtn = document.getElementById("drawlineBtn");
    dlBtn.addEventListener("click", DoDrawLine, false);
    
    dlBtn = document.getElementById("drawcurveBtn");
    dlBtn.addEventListener("click", DoDrawCurve, false);
    
    dlBtn = document.getElementById("drawfillpolylineBtn");
    dlBtn.addEventListener("click", DoDrawFillPolyline, false);
    
    dlBtn = document.getElementById("label");
    dlBtn.addEventListener("click", DoLabel, false);
    
    dlBtn = document.getElementById("drawundoBtn");
    dlBtn.addEventListener("mousedown", function(e) { graphSe.Undo(e) }, false);
    dlBtn.addEventListener("mouseup", function(e) { graphSe.Undo(e) }, false);
    
    dlBtn = document.getElementById("drawredoBtn");
    dlBtn.addEventListener("click", function(e) { graphSe.Redo(e) }, false);
    
    DrawGrid( );
   
    paper.projects[0].view.onFrame = AnimateGraph;
    //paper.projects[1].view.onFrame = DrawGraph;
    //tmr = setInterval( AnimateGraph, FDMS );
    
    StartMM();
    resize();
    
    document.getElementById("pointerBtn").click();
}

function PosOff()
{
	graphSe.showpos=false;
    ctx.clearRect(0, 0, can.width, can.height);

}	

function PosOn()
{
	graphSe.showpos=true;
}	

function Point( clr, xx, yy, szz )
{
     this.what = "point";
     
     this.studentcorrectlabel = "a";
     
     this.iscorrect = null;
     this.correctgraph;
     this.labelcorrect;
     
     this.x = xx;
     this.y = yy;
     this.color = clr;
     this.radius = szz;
     this.type = "";
     this.elementlabel="None";
     this.relementlabel="None";
	 this.bookcolor="No";
	 this.iscurrent=true;
	 this.once = 0;

	 this.interactive = graphSe.mode=="correct" || graphSe.mode=="student" ? true : false;
	 this.precise = null;
	 this.evalshift = null;
	 this.labelam = '';
	 this.taelement = 'None';
     this.labelLine = false;
     this.relselects = '';
	 
	 this.correctx=null;
	 this.correcty=null;
	 
	 this.trackAng = 0;
	 this.trackOffset = 0;
	 this.trackXg;
	 this.trackYg;
	 
	 this.xg = graphSe.ConvertXpxToXg( xx );
	 this.yg = graphSe.ConvertYpxToYg( yy );
	 
	 this.sxg = graphSe.SnapX( this.xg );
	 this.syg = graphSe.SnapY( this.yg );
	 
	 this.tempy;
	 
	 this.plumbLine = false;
	 
	 this.ghost = null;
	 
	 this.mode = graphSe.mode;
	 
	 this.dragState = "off";
	 this.dragStart = null;
	 this.dragDxDy = { dx: 0, dy: 0 };
	 
     npoints++;
     //gmloc = npoints;
	 this.label = "P"+npoints;
     this.labelvalue = npoints;
     this.moves = [ ];
     this.myPath;
     
     this.correct = [ ];
	 this.correctTolerance = 4;
	 this.correctFeedback = "Point Correct!";
	 this.notCorrectFeedback = "Point Not Correct!";
	 this.feedback = "";

	 this.templabel;
	 
	 this.correctlabel = "b";
	 
	 this.taselects = '';
     this.relselects = '';

	 this.cc = 'rgba(0, 0, 0, 1)'
	 this.ccus = 'rgba(0, 0, 0, .5)'

	 this.checkboxes = [true];
	 this.customlabels = [];

	 this.clabeloffset = "42px";
	 this.elabelmode = "";

	 this.studentdrag = null;

	 this.requiredlabel = false;

	 this.elabelmode = "";
	 	 
	 this.SetColor = function ( )
	 {
	 	if(this.elementlabel=="None") {this.cc = 'rgba(0, 0, 0, 1)'; this.ccus = 'rgba(0, 0, 0, .5)';}
	 	else if(this.elementlabel=="PPF" && this.bookcolor=="Yes") {this.cc = 'rgba(170, 95, 166, 1)'; this.ccus = 'rgba(170, 95, 166, .5)';}
	 	else if(this.elementlabel=="Demand" && this.bookcolor=="Yes") {this.cc = 'rgba(0, 131, 173, 1)'; this.ccus = 'rgba(0, 131, 173, .5)';}
	 	else if(this.elementlabel=="Supply" && this.bookcolor=="Yes") {this.cc = 'rgba(219, 92, 28, 1)'; this.ccus = 'rgba(219, 92, 28, .5)';}
	 	else if(this.elementlabel=="Fixed Cost" && this.bookcolor=="Yes") {this.cc = 'rgba(188, 189, 192, 1)'; this.ccus = 'rgba(188, 189, 192, .5)';}
	 	else if(this.elementlabel=="Indifference" && this.bookcolor=="Yes") {this.cc = 'rgba(247, 147, 29, 1)'; this.ccus = 'rgba(247, 147, 29, .5)';}
	 	else if(this.elementlabel=="Marginal Cost" && this.bookcolor=="Yes") {this.cc = 'rgba(247, 147, 29, 1)'; this.ccus = 'rgba(247, 147, 29, .5)';}
	 	else if(this.elementlabel=="Marginal Revenue" && this.bookcolor=="Yes") {this.cc = 'rgba(35, 31, 32, 1)'; this.ccus = 'rgba(35, 31, 32, .5)';}
	 	else if(this.elementlabel=="Total Cost" && this.bookcolor=="Yes") {this.cc = 'rgba(219, 92, 28, 1)'; this.ccus = 'rgba(219, 92, 28, .5)';}
	 	else if(this.elementlabel=="Variable Cost" && this.bookcolor=="Yes") {this.cc = 'rgba(238, 165, 122, 1)'; this.ccus = 'rgba(238, 165, 122, .5)';}
	 	else {this.cc = 'rgba(0, 0, 0, 1)'; this.ccus = 'rgba(0, 0, 0, .5)';}
	 }
     
     this.DrawMe = function( ctx )
     { 
         if( graphSe.mode != "correct" && graphSe.mode != "student" && graphSe.mode != this.mode 
             || (this.mode == 'correct' && graphSe.mode == "student") ) return;
         
         var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxg : this.xg );
         var ypx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syg : this.yg );
         
         this.myPath = new paper.Path.Circle(new paper.Point(xpx, ypx), this.radius);
         this.myPath.fillColor = this.iscurrent ? this.cc : this.ccus;
         
         if( graphSe.boo && this.ghost && this.mode!="correct" )
         {
             var gh = this.ghost;
             var xx = graphSe.ConvertXgToXpx( graphSe.snapIt ? gh.sxg : gh.xg );
             var xy = graphSe.ConvertYgToYpx( graphSe.snapIt ? gh.syg : gh.yg );
             var dx = xpx - xx;
             var dy = ypx - xy;             
             if( Math.sqrt(dx*dx + dy*dy) > 2 )
             {
                 this.myPath = new paper.Path.Circle(new paper.Point(xx, xy), this.radius );
                 this.myPath.fillColor = gh.clr;
             }
            
            if(this.labelLine==true)
            {
				text = new paper.PointText(new paper.Point(xx, xy+20));
				text.justification = 'center';
				text.fillColor = this.ccus;
				text.content = this.label;
			}	
         }
         
         if( this.plumbLine ) this.PlumbLine( );   

         if( this.labelLine ) this.LabelLine( );

	     if(graphSe.mode=="correct") this.SetCorrectPoints();
 	     //if( graphSe.mode == "student" ) this.CheckIsCorrect( );
        
     }
     
     this.TrackAlong = function( lbl )
     {
         if( lbl != undefined ) this.trackAlongLabel = lbl;
     
         this.trackElement = graphSe.FindInGraph( this.trackAlongLabel );
         
         if( this.trackElement != null )
         {
             var t = this.trackElement;
             switch( t.constructor.name )
             {
                 case "Line":       
                     this.ang = Math.atan2(this.yeg - this.ysg, this.xeg - this.xsg);
                     this.trackAng = Math.atan2(t.yeg - t.ysg, t.xeg - t.xsg);
                     this.Track = this.TrackLine;
                     break;
                 case "Curve":
                 case "Polyline":
                     if( lbl != undefined ) 
                     {
                         this.trackOffset = 0;
                         this.trackXg = t.pts[0];
                         this.trackYg = t.pts[1];
                         this.Track = this.TrackPath;
                     }
                     break;
             }
         }
     }
     
     this.TrackLine = function( dist )
     {  
         var ang = this.trackAng;
         var dx = Math.cos(ang)*dist;
         var dy = Math.sin(ang)*dist;
         
         return { sx: dx, sy: dy };
     }
     
     this.TrackPath = function( dist )
     {  
         var pt;
         var te = this.trackElement;
         if( dist > 0 && this.trackOffset < .985 ) this.trackOffset += .015;
         else if( dist < 0 && this.trackOffset > .015) this.trackOffset -= .015;
         
         var path = te.myPath
         if( path == undefined ) path = te.path;
         
         var pathOffset = this.trackOffset*path.length;
        
         pt = path.getPointAt(pathOffset);
         
         var txg = graphSe.ConvertXpxToXg( pt.x );
         var tyg = graphSe.ConvertYpxToYg( pt.y );
         
         var tdx = txg - this.trackXg;
         var tdy = tyg - this.trackYg;
         this.trackXg = txg;
         this.trackYg = tyg;
         
         return { sx: tdx, sy: tdy};
     }
     
     this.Track = this.TrackLine;
     
     this.CorrectToDesigner = function( )
     {
         if( this.ghost )
         {
             var gh = this.ghost;
             this.xg = gh.xg;
             this.yg = gh.yg;
             this.sxg = gh.sxg;
             this.syg = gh.syg;
         }
     }
     
     this.DesignerToCorrect = function( )
     {
         if( this.correct.length > 0 )
         {
             var ca = this.correct[0];
             this.xg = ca.xg;
             this.yg = ca.yg;
             this.SnapMe( );
         } 
     }
     
     this.SnapMe = function( )
     {
         this.sxg = graphSe.SnapX(this.xg);
         this.syg = graphSe.SnapY(this.yg);
     }
     
     this.PlumbLine = function( )
     {
         this.PathMe( );
         var ln = graphMe.length;
         for( var j = 0; j < ln; j++ ) 
         {
              var gj = graphMe[j];
              if( gj == this ) continue;
              
              if( gj instanceof Point  )
              {
                   if( this.HitMe( gj ) ) 
                   {
                        var xpx = graphSe.ConvertXgToXpx( gj.xg );
                        var ypx = graphSe.ConvertYgToYpx( gj.yg );
                        
                        var clr = 'lightblue';
                        DrawLine( clr, this.width, xpx, ypx, 0, ypx, [4, 4] ); 
                        DrawLine( clr, this.width, xpx, ypx, xpx, can.height-3, [4, 4] );
                   }
                  
              }
              else if( gj instanceof Line )
              {
                   var xepx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxg : this.xg );
                   var yepx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syg : this.yg );
                   
                   if( gj.HitMe( {x: xepx, y: yepx} ) ) 
                   {
                        var xpx = graphSe.ConvertXgToXpx( this.xg );
                        var ypx = graphSe.ConvertYgToYpx( this.yg );
                        
                        var clr = 'grey';
                        DrawLine( clr, this.width, xpx, ypx, 0, ypx, [4, 4] ); 
                        DrawLine( clr, this.width, xpx, ypx, xpx, can.height-3, [4, 4] );
 
  						var text = new paper.PointText(new paper.Point(15, yepx-10));
						text.justification = 'center';
						text.fillColor = "grey";
						text.fontSize = 10
						text.content = Math.round(graphSe.ConvertYpxToYg(yepx)*10)/10;

  						var text = new paper.PointText(new paper.Point(xepx+14, 375));
						text.justification = 'center';
						text.fillColor = "grey";
						text.fontSize = 10
						text.content = Math.round(graphSe.ConvertXpxToXg(xepx)*10)/10;

                   }
              }
         }
     }
     
     this.HitMe = function( mpt )
     {
         var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxg : this.xg );
         var ypx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syg : this.yg ); 
         
         var dx = xpx - mpt.x;
         var dy = ypx - mpt.y;
            
         return Math.sqrt(dx*dx + dy*dy) < this.radius;
     }
     
     this.MoveMe = function( typ, dx, dy )
     {
         this.xg -= dx;
         this.yg -= dy;
	     this.SnapMe( );
     }
     
     this.ControlMe = function( tf )
     {

     }
     
     this.DragMe = function( mpt, drgSt )
     {
         if( drgSt != undefined ) this.dragState = drgSt;
         
         switch( this.dragState )
         {
             case "off":
                 if( graphSe.boo && this.interactive && !this.ghost ) this.GhostMe( ); 
                 
                 dragObj = this;
                 this.dragState = "drag"; 
                 this.dragstart = mpt;
                 this.dragDxDy = { dx: 0, dy: 0 };
                 if(graphSe.mode=="student")this.studentdrag=true;
                 if(graphSe.mode=="correct")Precise(true);
                 break;
             case "drag":
                 //if( graphSe.boo && !this.ghost ) this.GhostMe( );
                 
	             var dsxg = graphSe.ConvertXpxToXg( mpt.x ) - graphSe.ConvertXpxToXg( this.dragstart.x );
	             var dsyg = graphSe.ConvertYpxToYg( mpt.y ) - graphSe.ConvertYpxToYg( this.dragstart.y );  
	             
	             if( this.taelement != "None" )
	             {
	                 this.TrackAlong();
	                 var s = this.Track( dsxg );
	                 dsxg = s.sx;
	                 dsyg = s.sy;
	             }
	             
	             this.xg += dsxg;
	             this.yg += dsyg;
	             this.SnapMe( );
	             this.SetElementPoints( );
	             this.dragstart = mpt;
	             this.dragDxDy = { dx: this.dragDxDy.dx -= dsxg, dy: this.dragDxDy.dy -= dsyg };
	             break;
	         case "drop":
	             dragObj = null;
	             this.dragState = "off"
	             if( this.dragDxDy.dx != 0 || this.dragDxDy.dy != 0 )
	             {
	                 graphSe.OpsMoveElement( this, "all", -this.dragDxDy.dx, -this.dragDxDy.dy );
	                 if( graphSe.mode == "correct" ) this.CorrectMe( );
	                 if( graphSe.mode == "student" ) this.CheckIsCorrect( );
	                 if( graphSe.mode == "designer" && this.interactive ) this.GhostMe();
	             }
	             break;
         }
     }
     
     this.CorrectMe = function( type )
     {
         this.correct[0] = { type: type == undefined ? "precise" : type, lbl: this.label, xg: this.xg, yg: this.yg, sxg: this.sxg, syg: this.syg };
     }
     
     this.CheckIsCorrect = function( mode )
     {
         var tst=true;
         if( this.correct.length > 0 && mode == undefined )
         {
             var typ = this.correct[0].type;
             var area = (typ != undefined) && (typ.length == 3);
             if( typ == "precise" || typ == undefined || area  )
             { 
                 var ca = this.correct[0];
                 var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxg : this.xg );
                 var ypx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syg : this.yg );
                 switch( ca.lbl[0] )
                 {
                     case 'P':
                         var cpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? ca.sxg : ca.xg );
                         var cpy = graphSe.ConvertYgToYpx( graphSe.snapIt ? ca.syg : ca.yg );
                         var dxs = xpx - cpx;
                         var dys = ypx - cpy;
                     
                         tst = Math.sqrt( dxs*dxs + dys*dys) < this.correctTolerance;
                         break;
                     case 'A':
                         var aao = graphSe.FindInGraph( ca.lbl );
                         tst = aao.path.contains( new paper.Point(xpx,ypx) );
                 }
             }
             else if( typ.length == 2 )
             {
                 var ca = this;
                 var cpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? ca.sxg : ca.xg );
                 var cpy = graphSe.ConvertYgToYpx( graphSe.snapIt ? ca.syg : ca.yg );
                 
                 rele = graphSe.FindInGraph( this.relementlabel );
                 if( rele instanceof Point )
                 {  
                     if( rele == this ) rele = this.correct[0]; 
                      
                     var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.sxg : rele.xg );
                     var cpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxg : this.xg );
                     
                     var lfrt = typ[1];
                     if( lfrt == "left" && cpx < xpx ) tst = true;
                     else if( lfrt == "right" && cpx > xpx ) tst = true;
                     else tst = false;
                 }
                 else if( rele instanceof Line )
                 {  
                     var cpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.sxsg : rele.xsg );
                     var cpxe = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.sxeg : rele.xeg );
                     var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxg : this.xg );
                     var lfrt = typ[1];
                     
                     if( lfrt == "left" && cpx > xpx && cpxe > xpx) tst = true;
                     else if( lfrt == "right" && cpx < xpx && cpxe < xpx ) tst = true;
                     else tst = false;
                 }
                 else if( rele instanceof Curve )
                 { 
                     var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.spts[0] : rele.pts[0] );  
                     var xpxe = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.spts[4] : rele.pts[4] );
                     if( xpxe < xpx ) { var t = xpx; xpx = xpxe; xpxe = t; } 
                     
                     var cpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxg : this.xg );
            
                     var lfrt = typ[1]
                     if( lfrt == "left" || lfrt == "right" )
                     {
                         if( lfrt == "left" && cpx < xpx && cpx < xpxe ) tst = true;
                         else if( lfrt == "right" && cpx > xpx && cpx > xpxe ) tst = true;
                         else tst = false;
                     }
                     else if( lfrt == "inward" || lfrt == "outward" )
                     {
                         var cpath = rele.myPath.clone( );
                         cpath.closed = true;
                         
                         var isInside = cpath.contains(new paper.Point(cpx,cpy));
                         if( lfrt == "inward" && isInside ) tst = true;
                         else if( lfrt == "outward" && !isInside ) tst = true;
                         else tst = false;
                     }
                 }
                 else if( rele instanceof Polyline )
                 {
                     for( var i = 0, ln = rele.pts.length-2, xmn = 10000, xmx = 0; i < ln; i += 2 )
                     {
                         var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.spts[i] : rele.pts[i] );
                         if( xpx < xmn ) xmn = xpx;
                         else if( xpx > xmx ) xmx = xpx;
                     }
                          
                     var cpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxg : this.xg );
                     
                     var lfrt = typ[1];
                     if( lfrt == "left" && cpx < xmn ) tst = true;
                     else if( lfrt == "right" && cpx > xmx) tst = true;
                     else tst = false;
                 }
             }
         }
         else if( mode == "drawing" )
         {
             for( var i = 0, tst = false, ln = graphMe.length; i < ln && !tst; i++ )
             {
                 var gi = graphMe[i];
                 if( gi.mode == "correct" && gi.what == this.what )
                 {
                     var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxg : this.xg );
                     var ypx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syg : this.yg );
                     var cpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? gi.sxg : gi.xg );
                     var cpy = graphSe.ConvertYgToYpx( graphSe.snapIt ? gi.syg : gi.yg );
                     var dxs = xpx - cpx;
                     var dys = ypx - cpy;
                     tst = Math.sqrt( dxs*dxs + dys*dys) < this.correctTolerance;
                 }
             }
         }
 
         this.feedback = tst ? this.correctgraph=true : this.correctgraph=false;

         
         if(this.requiredlabel)
         {
         	if(this.correctlabel==this.studentcorrectlabel) 
         	{
         		this.labelcorrect=true;
         	} else {
         		this.labelcorrect=false;
         	}		
         	
         } else 
         {
         	this.labelcorrect=true;
         }
         
         if(this.correctgraph==true && this.labelcorrect==true)
         {
         	this.iscorrect="<span style='color:green;'>Correct</span>";
         }	else {
         	this.iscorrect="<span style='color:red'>Not Correct</span>";
         }	
         
         //SayFeedback( this.feedback );
     }
     
     this.Subtract = function( v )
     {
         return new paper.Point( this.x - v.x, this.y - v.y )
     }

     this.LabelMe = function( tf )
     {
         this.labelLine = tf;
     }     

     this.LabelLine = function(  )
     {
		pt = graphSe.snapIt ? { x: this.sxg, y: this.syg } : { x: this.xg, y: this.yg };
		
		var xoffset = 0;
		var yoffset = 20;

		pt.x = graphSe.ConvertXgToXpx(pt.x)+xoffset;
		pt.y = graphSe.ConvertYgToYpx(pt.y)+yoffset;
		
        var clr = this.iscurrent == true ? this.cc: this.ccus;

		//console.log(clr);
		/*ctx2.fillStyle = clr;
		ctx2.font="14px sans-serif";
		ctx2.fillText(this.label,pt.x,pt.y);
		ctx2.font="10px sans-serif";*/

		if(graphSe.mode=="correct"&&this.dragstart!=undefined)
		{
			templabel = this.labelam;
		} else
		{
			templabel = this.label;
		}
			
		if(graphSe.mode=="designer")
		{
			templabel = this.label;
		}	

		if(graphSe.mode=="student"&&this.studentdrag!=null)
		{
			templabel = this.labelam;
		}				

		var text = new paper.PointText(new paper.Point(pt.x, pt.y));
		text.justification = 'center';
		text.fillColor = clr;
		text.content = templabel;
		
	}  
     
     
     this.Magnitude = function( ) 
     {
         return Math.sqrt( this.x*this.x + this.y*this.y )
     } 
     
     this.PathMe = function( )
     {
         this.path = this.myPath;
     }
     
     this.GhostMe = function( )
     {
         this.ghost = { clr: "#D0D0D0", rd: this.radius, xg: this.xg, yg: this.yg, sxg: this.sxg, syg: this.syg }
                       
     }
     
     this.PlumbMe = function( tf )
     {
         this.plumbLine = tf;
     }
     
     this.RequiredLabelMe = function( tf )
     {
         this.requiredlabel = tf;
         
         if(this.requiredlabel)
         {
 			$('#requiredlabelinputs').removeClass("hide");     	 	
			$('#requiredlabeltools').removeClass("hide");     	 	        
         } else {
 			$('#requiredlabelinputs').addClass("hide");     	 	
			$('#requiredlabeltools').addClass("hide");  
		}	           
     }

	 this.checkBoxes = function()
	 {
	 	if(document.getElementById('equilibrium').checked) {this.checkboxes[0]=true} else {this.checkboxes[0]=false};

		for(var i=0; i<this.customlabels.length; i++)
		{
		 	var str = this.customlabels[i];
		 	var lwr = str.toLowerCase();
		 	str = lwr.replace(/\s+/g, '');

			if(document.getElementById(str).checked) {this.checkboxes[1+i+1]=true} else {this.checkboxes[1+i+1]=false};	
				 	
		 	//html += '<input type="checkbox" id="'+str+'" checked> '+this.customlabels[i]+'<br>'
		 	//this.checkboxes[i+9] = false;
		}


     	this.CorrectLabelDropdown(); 

     	//this.SetSettings();

	 }
	 
	 this.checkBoxHTML = function()
	 {
	 	var html = '';
	 	
	 	if(this.checkboxes[0])
	 	{
	 		html += '<input type="checkbox" id="equilibrium" checked> Equilibrium<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="equilibrium"> Equilibrium<br>'	 	
	 	}
	 	
		for(var i=0; i<this.customlabels.length; i++)
		{
		 	var str = this.customlabels[i];
		 	var lwr = str.toLowerCase();
		 	str = lwr.replace(/\s+/g, '');
		 	
		 	html += '<input type="checkbox" id="'+str+'" checked> '+this.customlabels[i]+'<br>'
		 	//this.checkboxes[i+9] = false;
		}

	 	this.checkboxhtml = html;
	 	
	 	//document.getElementById('checkform').innerHTML = this.checkboxhtml;
	 }

     this.addLabel = function()
     {
     	this.customlabels.push(document.getElementById('newlabel').value)
     	
     	var str = document.getElementById('newlabel').value;
		var lwr = str.toLowerCase();
		str = lwr.replace(/\s+/g, '');
     	
     	this.checkBoxHTML();
     	
     	document.getElementById('checkform').innerHTML = this.checkboxhtml;
     	
		this.CorrectLabelDropdown();

		var fstr = document.getElementById("cltext2").style.paddingTop;
		var fstr2 = fstr.split("px");
		fstr = fstr2[0];
		fstr = Number(fstr)+20;
		document.getElementById("cltext2").style.paddingTop = fstr+"px";
		this.clabeloffset = fstr+"px";	
     }	

     this.CorrectLabelDropdown = function ()
     {
     		var html = '<option value="None">None</option>'

			if(document.getElementById('equilibrium').checked) {html += '<option value="Equilibrium">Equilibrium</option>'} else {};

			for(var i=0; i<this.customlabels.length; i++)
			{
				var str = this.customlabels[i];
				var lwr = str.toLowerCase();
				str = lwr.replace(/\s+/g, '');
			
				if(document.getElementById(str)) {
					if(document.getElementById(str).checked) {html += '<option value="'+this.customlabels[i]+'">'+this.customlabels[i]+'</option>'} else {}
				}
				//this.checkboxes[i+9] = false;
			}
       		
     		this.clselects = html;

     	    document.getElementById("cldropdown").innerHTML = html;		
		 	document.getElementById('cldropdown').value = this.correctlabel;

     }     

          
     this.SetSettings = function( )
     {
		 //this.SetMaxes();

     	 this.TrackAgainstDropdown();   
     	 this.RelativeDropdown();   
      	 this.checkBoxHTML();
    	 
     	 $('#bottomtools').removeClass("hide");
     	 
     	 var html = '<div class="sectionhead"><span id="elementhead">Element Settings </span><button class="glyphicon glyphicon-left" aria-hidden="true" style="margin-left: 30px; background: none; border: none;" onclick="leftArrow();"></button><span id="toplabel'+this.labelvalue+'" class="elementid">'+this.label+'</span><button class="glyphicon glyphicon-right" aria-hidden="true" onclick="rightArrow();" style="background: none; border: none;"></span></div>'
     	 html += '<div class="hrm"></div>'
		 html += '<div class="row" style="margin-left: 20px;">'
		 html += '<div class="col-sm-6">'
     	 html += '<div id="designertools">'
		 html += '<div class="tool">Element Type</div>'
		 html += '<div class="tool"></div>'
		 html += '<div class="tool">Label</div>'
		 html += '<div class="tool">Show Label</div>'
		 html += '<div class="tool">Coordinates</div>'
		 html += '<div class="tool">Show Plumbs</div>'
		 html += '</div>'
		 html += '</div>'
		 html += '<div class="col-sm-6" style="padding-top: 8px;">'
     	 html += '<div id="designerinputs">'
		 html += '<div class="styled-select"><select id="eldropdown" class="select-class" onchange="GetElement(this.value)"></span><option value="None">None</option><option value="Equilibrium">Equilibrium</option></select></div>'
		 html += '<button id="bcbutton" aria-hidden="true" onclick="bookColor();">Use Book Color <span class="glyphicon glyphicon-uncheckedmm"></span></button>'
		 html += '<div><input id="xlabel'+this.labelvalue+'" type="text" class="small-label" placeholder="'+this.label+'" onkeyup="labelUpdate(this.value)" maxlength="8"></div>'	  			
		 html += '<div><label class="switch tool"><input id="labeltoggle" type="checkbox" onclick="update();"><div class="slider"><span class="ontext">ON</span><span class="offtext">OFF</span></div></label></div>'
		 html += '<div>(<input id="xpoint" type="number" class="point-input" value="'+this.sxg+'" step="'+graphSe.xmax/Number(graphSe.wdPx)+'" oninput="xUpdate(this.value)" onkeypress="return event.charCode >= 48 && event.charCode <= 57 && event.charCode = 110">,<input id="ypoint" type="number" class="point-input" value="'+this.syg+'" oninput="yUpdate(this.value)" step="'+graphSe.ymax/Number(graphSe.htPx)+'" onkeypress="return event.charCode >= 48 && event.charCode <= 57 && event.charCode = 110">)</div>'	  			
		 html += '<div><label class="switch tool"><input id="plumbtoggle" type="checkbox" onclick="update();"><div class="slider"><span class="ontext">ON</span><span class="offtext">OFF</span></div></label></div>'
		 html += '</div>'	  			
		 html += '</div>'	  			
	     html += '</div>'	

     	 $('#interactive').removeClass("hide");

     	 var html2 = '<div id="sectionpadding" class="sectionhead"></div>'
		 html2 += '<div class="row" style="margin-left: 20px;">'
		 html2 += '<div id="intleft" class="col-sm-6">'
		 html2 += '<button class="fake-radio" id="binteractive" onclick="Interactive(true);"> <div class="radio-off"><div id="binteractivero" class="radio-on hide"></div></div>Interactive</button><br>'
		 html2 += '<div id="ilabels" class="hide"><div class="tool">Label after move</div>'
		 html2 += '<div class="tool">Track against</div>'		 
		 html2 += '</div>'
		 html2 += '</div>'		 
		 html2 += '<div id="intright" class="col-sm-6">'
		 html2 += '<button class="fake-radio" id="bstatic" onclick="Interactive(false);"> <div class="radio-off"><div id="bstaticro" class="radio-on"></div></div>Static<br></button>'
		 html2 += '<div id="iinputs" class="hide"><div><input id="labelam" type="text" value="'+this.labelam+'" oninput="labelAMUpdate(this.value)" style="margin-top: 10px; width: 75px"></div>'	  			
		 html2 += '<div class="styled-select"><select id="tadropdown" class="select-class" onchange="TAElement(this.value)" value="'+this.taelement+'" style="margin-top:10px">'+this.taselects+'</select></div>'
		 html2 += '</div>'	
	     html2 += '</div>'	
		 html2 += '<div id="elabel" class="row hide">'
		 html2 += '<div class="col-sm-6">'
		 html2 += '<div class="tool"><strong>Evaluated on</strong></div>'		 
		 html2 += '</div>'	
		 html2 += '<div class="col-sm-6">'
		 html2 += '<div id="elabelmode" class="" style="margin-top: 11px;">Interaction</div>'		 		   			
		 html2 += '</div>'	
		 html2 += '</div>'	

		 var html3 = '<div class="row" style="margin-left: 20px;">'
		 html3 += '<div class="col-sm-6">'
		 html3 += '<button class="fake-radio" id="bprecise" onclick="Precise(true);"> <div class="radio-off"><div id="bprecisero" class="radio-on hide"></div></div>Precise</button><br>'
		 html3 += '<div id="precisetools" class="hide">'
		 html3 += '<div class="tool">Coordinates</div>'
		 html3 += '</div>'
		 html3 += '<div id="relativetools" class="hide">'
		 html3 += '<div class="tool">Relative to:</div>'
		 html3 += '<div id="relativetools2" class="hide">'
		 html3 += '<div class="tool">Shift from origin</div>'
		 html3 += '</div>'
		 html3 += '<div id="drawarea" class="hide" style="width: 200px; margin-top: 10px; margin-left: 10px; position:relative; top: 10px;"><button type="button" class="btn btn-econ-sw5" onclick="DoAcceptedArea(gmloc-1)"><span class="glyphicon glyphicon-pentagon" aria-hidden="true"></span><img id="areashade" src="./images/areashade.png"></img></button><span style="padding-left: 5px;">Draw Accepted Area</span></div>'	
		 html3 += '</div>'	
		 html3 += '</div>'	
		 html3 += '<div class="col-sm-6">'
		 html3 += '<button class="fake-radio" id="brelative" onclick="Precise(false);"> <div class="radio-off"><div id="brelativero" class="radio-on"></div></div>Relative<br></button>'
		 html3 += '<div id="preciseinputs" class="hide" style="position:relative; top: 10px">'
		 html3 += '<div>(<input id="xpointc" type="number" class="point-input" value="'+this.sxg+'" step="'+graphSe.xmax/Number(graphSe.wdPx)+'" oninput="xUpdate(this.value)" onkeypress="return event.charCode >= 48 && event.charCode <= 57">,<input id="ypointc" type="number" class="point-input" value="'+this.syg+'" oninput="yUpdate(this.value)" step="'+graphSe.ymax/Number(graphSe.htPx)+'" onkeypress="return event.charCode >= 48 && event.charCode <= 57">)</div>'	  			
		 html3 += '</div>'	
		 html3 += '<div id="relativeinputs" class="hide">'
		 html3 += '<div class="styled-select" style="margin-top:9px"><select id="reldropdown" class="select-class" onchange="GetRelativeElement(this.value)"></span>'+this.relselects+'</select></div>'
		 html3 += '<div id="relativeinputs2" class="hide">'
		 html3 += '<button class="fake-radio" id="sleft" onclick="ShiftLeft();" style="margin-top:13px;"> <div class="radio-off"><div id="sleftro" class="radio-on hide"></div></div>Left</button><br>'
		 html3 += '<button class="fake-radio" id="sright" onclick="ShiftRight();" style="margin-top:0px;"> <div class="radio-off"><div id="srightro" class="radio-on hide"></div></div>Right</button><br>'
		 html3 += '</div>'	
		 html3 += '</div>'	
		 html3 += '</div>'	
		 html3 += '</div>'	
		 
		 var html4 = '<div class="row" style="margin-left: 20px;">'
		 html4 += '<div class="col-sm-6">'
		 html4 += '<div class="tool" style="margin-top: 0px;">Required label</div>'
		 html4 += '<div id="requiredlabeltools" class="hide">'
		 html4 += '<div class="tool">Label Choices</div>'
		 html4 += '<div id="cltext2" class="tool" style="padding-top: '+this.clabeloffset+'">Correct Label</div>'
		 html4 += '</div>'	
		 html4 += '</div>'	
		 html4 += '<div class="col-sm-6">'
		 html4 += '<div id="rtoggleshell" style="margin-top:10px;"><label class="switch tool"><input id="rltoggle" type="checkbox" onclick="update();"><div class="slider"><span class="ontext">ON</span><span class="offtext">OFF</span></div></label></div>'
		 html4 += '<div id="requiredlabelinputs" class="hide">'
		 html4 += '<form id="checkform" onclick="checkBoxes();">'+this.checkboxhtml+'</form>'
		 html4 += '<div><input id="newlabel" type="text" class="" placeholder="Custom label" onkeyup="" style="width: 100px; margin-top: 10px;"><button class="btn-nothing" onclick="addLabel()"> <span class="glyphicon glyphicon-cplus"></span></button></div>'
		 html4 += '<div class="styled-select" style="margin-top: 10px"><select id="cldropdown" class="select-class" onchange="GetCorrectLabel(this.value)"></span><option value="None">None</option><option value="Equilibrium">Equilibrium</option></select></div>'
		 html4 += '</div>'	
		 html4 += '</div>'	

		 var html5 = '<div class="row" style="margin-left: 20px;">'
		 html5 += '<div class="col-sm-6">'
		 html5 += '<div class="tool">Element Type</div>'
		 html5 += '<div class="tool">Coordinates</div>'
		 html5 += '</div>'
		 html5 += '<div class="col-sm-6" style="padding-top: 8px;">'
		 html5 += '<div class="styled-select"><select id="eldropdown" class="select-class" onchange="GetElement(this.value)"></span><option value="None">None</option><option value="Demand">Demand</option><option value="Fixed Cost">Fixed Cost</option><option value="Indifference">Indifference</option><option value="Marginal Cost">Marginal Cost</option><option value="Marginal Revenue">Marginal Revenue</option><option value="PPF">PPF</option><option value="Supply">Supply</option><option value="Total Cost">Total Cost</option><option value="Variable Cost">Variable Cost</option></select></div>'
		 html5 += '<div style="margin-top: 10px;">(<input id="xpointd" type="number" class="point-input" value="'+this.sxg+'" step="'+graphSe.xmax/Number(graphSe.wdPx)+'" oninput="xUpdate(this.value)" onkeypress="return event.charCode >= 48 && event.charCode <= 57 && event.charCode = 110">,<input id="ypointd" type="number" class="point-input" value="'+this.syg+'" oninput="yUpdate(this.value)" step="'+graphSe.ymax/Number(graphSe.htPx)+'" onkeypress="return event.charCode >= 48 && event.charCode <= 57 && event.charCode = 110">)</div>'	  			
		 html5 += '</div>'	  			
		 html5 += '</div>'	  			

		 		 
		 document.getElementById("bottomtools").innerHTML = html;		
		 document.getElementById("interactive").innerHTML = html2;		
		 document.getElementById("interactivetools").innerHTML = html3;		
		 document.getElementById("labeldetails").innerHTML = html4;		
		 document.getElementById("drawingtools").innerHTML = html5;		
		
		 document.getElementById('eldropdown').value = this.elementlabel;
		 document.getElementById('plumbtoggle').checked = this.plumbLine;
		 document.getElementById('rltoggle').checked = this.requiredlabel;

		 document.getElementById('tadropdown').value = this.taelement;
		 document.getElementById('reldropdown').value = this.relementlabel;
		 document.getElementById('cldropdown').value = this.correctlabel;

		 this.InteractiveMe( this.interactive );
		 this.PreciseMe( this.precise );
		 this.EvalShift( this.evalshift );
		 
		 this.SetElementPoints( );
		 
		 this.DisplayBookColor();
		 
		 this.HighLight();

		 this.InteractiveReset();

		 this.CheckRLabel();
		 
		 this.CorrectTools();
  
 		 $('#emptydesigner').addClass("hide");		

		 if(this.labelLine==true) 
		 {
		 	document.getElementById("labeltoggle").checked = true;	
		 } else
		 {	
		 	document.getElementById("labeltoggle").checked = false;	
		 }

     } 
     
     this.SetElementPoints = function( )
     {
         document.getElementById('xpoint').value = graphSe.snapIt ? this.sxg : this.xg;
		 document.getElementById('ypoint').value = graphSe.snapIt ? this.syg : this.yg;

         document.getElementById('xpointd').value = graphSe.snapIt ? this.sxg : this.xg;
		 document.getElementById('ypointd').value = graphSe.snapIt ? this.syg : this.yg;		 
     }

     this.SetCorrectPoints = function( )
     {         
         if(this.precise)
         {
			 this.correctx = graphSe.snapIt ? this.sxg : this.xg;
			 this.correcty = graphSe.snapIt ? this.syg : this.yg;
		 
		     if( document.getElementById('xpointc') != null )
		     {
			     document.getElementById('xpointc').value = this.correctx;
			     document.getElementById('ypointc').value = this.correcty;
			 }
		 } 	 
     }     
    
     this.SetElementLabel = function(text)
     {
     	 this.elementlabel = text;

		 this.SetColor();   
		 
		 //console.log("the text:"+text);
		 var newstring = text;
		 var nssplit = text.split("");
		 var letter = nssplit[0].toUpperCase();
		 if(text!="None") 
		 {
		 	this.shortlabel = letter;
		 
		 	this.LabelFromPulldown();
		 	this.SetSettings();
		 }	
		   	 
     }

    this.SetCorrectStudentLabel = function(text)
     {
     	 this.studentcorrectlabel = text;
     	 
     	 this.CheckIsCorrect("label");	   	 
     }
	
     this.SetRelativeElementLabel = function(text)
     {
     	 this.relementlabel = text;
     	 
     	 this.CheckRLabel();
     }
	
     this.SetCorrectLabel = function(text)
     {
     	 this.correctlabel = text;
     }
	
	 this.CheckRLabel = function()
	 {
	     if(this.relementlabel=="Accepted Area")
     	 {
   			$('#relativetools2').addClass("hide");     	 	
			$('#relativeinputs2').addClass("hide");      	 
   			$('#drawarea').removeClass("hide");     	 	
    	 } else if (this.relementlabel=="None")
     	 {
  			$('#relativetools2').addClass("hide");     	 	
			$('#relativeinputs2').addClass("hide");     	 
    		$('#drawarea').addClass("hide");     	 	
    	 } else
     	 {
			$('#relativetools2').removeClass("hide");     	 	
			$('#relativeinputs2').removeClass("hide");     	 	
   			$('#drawarea').addClass("hide");     	 	
     	 }
	 }
	 
	 this.SetBookColor = function(text)
	 {
	 	this.bookcolor = text;	 	

		this.SetColor();
	 }

	 this.GetBookColor = function(text)
	 {
	 	return this.bookcolor;	
	 }	 	 

	 this.DisplayBookColor = function()
	 {
	 	if(this.bookcolor=="Yes")
	 	{
			document.getElementById('bcbutton').innerHTML = 'Use Book Color <span class="glyphicon glyphicon-checkedmm"></span>';
	 	} else 
	 	{
	 		document.getElementById('bcbutton').innerHTML = 'Use Book Color <span class="glyphicon glyphicon-uncheckedmm"></span>';
	 	}
	 }

	 this.HighLight = function()
	 {
	 	for(i=0; i<graphMe.length; i++)
	 	{
	 		graphMe[i].iscurrent=false	
	 	}	
	 	
	 	this.iscurrent=true
	 }
	 
	 this.UpdateLabelText = function()
	 {
		console.log(document.getElementById('xlabel'+this.labelvalue).value);
		document.getElementById('xlabel'+this.labelvalue).value = this.label;	 	
		document.getElementById('toplabel'+this.labelvalue).innerHTML = this.label;	 	
	 }

	 this.InteractiveMe = function( tf )
     {
        this.interactive = tf;
        if( tf ) { $("#binteractivero").removeClass("hide"); $("#bstaticro").addClass("hide"); }
        else { $("#binteractivero").addClass("hide"); $("#bstaticro").removeClass("hide"); }
     }

     
     this.CorrectTools = function()
     {
     	if(graphSe.mode=='correct')
     	{
 			if(this.interactive!=false)$('#labeldetails').removeClass("hide");
 			$('#designertools').addClass("hide");
			$('#designerinputs').addClass("hide");      	
			$('#elabel').removeClass("hide");      	
			$('#elabelmode').removeClass("hide");      	
			$('#intleft').addClass("hide");      	
			$('#intright').addClass("hide");      	
		 	document.getElementById("elementhead").innerHTML = "Evaluation Settings";		
			document.getElementById("interactive").style.background = "#fbfbfb";
			document.getElementById("interactive").style.marginTop = "0px";
 			$('#sectionpadding').addClass("hide");

			if( this.interactive )
			{
		 		document.getElementById("elabelmode").innerHTML = "Interactive";
		 		this.elabelmode = "Interactive";		
				$('#interactivetools').removeClass("hide");      	
			} else {
		 		document.getElementById("elabelmode").innerHTML = "Static";		
		 		this.elabelmode = "Static";				 		
				$('#interactivetools').addClass("hide");      	
			}	
			
			if(this.mode=="correct")
			{
		 		document.getElementById("elabelmode").innerHTML = "Drawing";
		 		this.elabelmode = "Drawing";				
				$('#interactivetools').addClass("hide");   				
				$('#drawingtools').removeClass("hide");   				
 				$('#labeldetails').removeClass("hide");
			}     
			if(document.getElementById('rltoggle').checked)
			{
				$('#requiredlabeltools').removeClass("hide");   				
 				$('#requiredlabelinputs').removeClass("hide");	
 		 		document.getElementById('cldropdown').value = this.correctlabel;				
			} else 
			{
				$('#requiredlabeltools').addClass("hide");   				
 				$('#requiredlabelinputs').addClass("hide");					
			}
			if(this.elabelmode=="Drawing")
			{
				$('#drawingtools').removeClass("hide");   							
			} else
			{
				$('#drawingtools').addClass("hide");   				
			}

     	} else if(graphSe.mode=='student')
     	{
 				$('#interactive').addClass("hide");   				
				$('#bottomtools').addClass("hide");
 				$('#interactivetools').addClass("hide");   				
				$('#requiredlabeltools').addClass("hide");   				
 				$('#requiredlabelinputs').addClass("hide");					   				
    		
     	} else 
     	{
 			$('#labeldetails').addClass("hide");
			$('#designertools').removeClass("hide");
			$('#designerinputs').removeClass("hide");     	
			//$('#elabel').addClass("hide");      	
			$('#elabelmode').addClass("hide");      
 			$('#intleft').removeClass("hide");      	
			$('#intright').removeClass("hide");  
 		 	document.getElementById("elementhead").innerHTML = "Element Settings";		
			document.getElementById("interactive").style.background = "#f6f6f6";
			document.getElementById("interactive").style.marginTop = "0px";
  			$('#sectionpadding').removeClass("hide");
			$('#interactivetools').addClass("hide");      	
				$('#requiredlabeltools').addClass("hide");   				
 				$('#requiredlabelinputs').addClass("hide");	
    	}
     }

     
     this.InteractiveReset = function ()
     {
			if( this.interactive )
			{
				$('#ilabels').removeClass("hide");
				$('#iinputs').removeClass("hide");
			} else {
				$('#ilabels').addClass("hide");
				$('#iinputs').addClass("hide");
			}	     
     }
     
     this.TrackAgainstDropdown = function ()
     {
     	var html = '<option value="None">None</option>'
     	for( i=0; i < graphMe.length; i++ ) 
     	{
     		//if( graphMe[i].label != this.label && graphMe[i].label[0] == 'L' )
     		if( graphMe[i].label != this.label )
     		{
				var graphlabel = graphMe[i].label;
				html += '<option value="'+graphlabel+'">'+graphlabel+'</option>'
			}	
     	}
     		
     		this.taselects = html;
     }

     this.RelativeDropdown = function ()
     {
     		var html = '<option value="None">None</option>'
     		html += '<option value="Accepted Area">Accepted Area</option>'
     		for(i=0; i<graphMe.length; i++) 
     		{
					var graphlabel = graphMe[i].label;
					html += '<option value="'+graphlabel+'">'+graphlabel+'</option>'
     		}
     		
     		this.relselects = html;
     }     

	 this.EvalShift = function( text )
     {
        this.evalshift = text;
        if( this.evalshift=="left" ) { $("#sleftro").removeClass("hide"); $("#srightro").addClass("hide");}
        else if (this.evalshift==null) {$("#sleftro").addClass("hide"); $("#srightro").addClass("hide");}
        else 
        {  
        	$("#sleftro").addClass("hide"); $("#srightro").removeClass("hide"); 
        	//$('#relativetools').removeClass("hide");
			//$('#relativeinputs').removeClass("hide");
        }
        
        if(  text != null ) this.CorrectMe( ["relative",text] );
     }    

	 this.PreciseMe = function( tf )
     {
        this.precise = tf;
        if( tf ) 
        { 
        	$("#bprecisero").removeClass("hide"); $("#brelativero").addClass("hide");
        	$('#relativetools').addClass("hide");
			$('#relativeinputs').addClass("hide");   
        	$('#precisetools').removeClass("hide");
			$('#preciseinputs').removeClass("hide");   			  			    
        }
        else if (tf==null) {$("#bprecisero").addClass("hide"); $("#brelativero").addClass("hide");}
        else 
        {  
        	$("#bprecisero").addClass("hide"); $("#brelativero").removeClass("hide"); 
        	$('#relativetools').removeClass("hide");
			$('#relativeinputs').removeClass("hide");
        	$('#relativetools2').addClass("hide");
			$('#relativeinputs2').addClass("hide");			
        	$('#precisetools').addClass("hide");
			$('#preciseinputs').addClass("hide");   
		}
     }    
     
     this.LabelMeDrop = function( )
     {

		console.log("label me drop");
        var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxg : this.xg );
        var ypx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syg : this.yg );
         
        var xspx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxsg : this.xsg );
        var yspx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.sysg : this.ysg );
        var xepx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxeg : this.xeg );
        var yepx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syeg : this.yeg );

		var div = document.createElement("div");
		div.id = 'dlabel';
		div.style.position = "absolute";
		div.style.left = xpx+47+'px';
		div.style.top = ypx+189+'px';
		div.style.zIndex = "10000";
		div.className = 'styled-select';
			
		div.innerHTML = '<select id="elabel" class="select-class" onchange="GetCorrectStudentLabel(this.value)"></span>'+this.clselects+'</select>'
		document.getElementById('graphcontainer').appendChild(div);	
		
	}   

     this.SetSettings();
   
}

function Line( clr, xxs, yys, xxe, yye, szz )
{
     this.what = "line";

	 this.mo;
	 
     this.studentcorrectlabel = "a";
     
     this.iscorrect = null;
     this.correctgraph;
     this.labelcorrect;
	 this.correctlabel = "b";

	 this.ang = null;
	 
     this.xs = xxs;
     this.ys = yys;
     this.xe = xxe;
     this.ye = yye;
          
     this.xsg = graphSe.ConvertXpxToXg( xxs );
	 this.ysg = graphSe.ConvertYpxToYg( yys );
     this.xeg = graphSe.ConvertXpxToXg( xxe );
	 this.yeg = graphSe.ConvertYpxToYg( yye );
	 
	 this.sxsg = graphSe.SnapX( this.xsg );
	 this.sysg = graphSe.SnapY( this.ysg );
	 this.sxeg = graphSe.SnapX( this.xeg );
	 this.syeg = graphSe.SnapY( this.yeg );

	 this.uvPx;
     
     this.color = clr;
     this.width = 2;

     this.elementlabel="None";
     this.relementlabel="None";
	 this.bookcolor="No";
	 this.iscurrent=true;
	 this.interactive = graphSe.mode=="correct" ? true : false;
	 this.precise = null;
	 this.evalshift = null;
	 this.labelam = '';
	 this.taelement = 'None';
     this.labelLine = false;
     this.relselects = '';
     	 	 
	 this.correct = [ ];
	 this.correctTolerance = 4;
	 this.correctFeedback = "Line Correct!";
	 this.notCorrectFeedback = "Line Not Correct!";
	 this.feedback = "";
	 
	 this.m = 0;
	 this.distance = 0;
	
	 this.labelam = '';
	 this.taelement = 'None';
	 
     lpoints++;
     //gmloc = lpoints;
	 this.label = "L"+lpoints;
     this.labelvalue = lpoints;
     this.trackAlongLabel = null;
     this.trackAng = 0;
     
     this.plumbLine = false;
     this.labelLine = false;
     
     this.dragState = "off";
     this.dragStart = null;
     this.dragDxDy = { dx: 0, dy: 0 };

	 this.studentdrag = null;
     
     this.ghost = null;
     
     this.showControl = false;
     
     this.mode = graphSe.mode;
       
     this.taselects = '';
     this.relselects = '';
     this.clselects = '';

	 this.cc = 'rgba(0, 0, 0, 1)'
	 this.ccus = 'rgba(0, 0, 0, .5)'

	 this.checkboxes = [true, true, true, true, true, true, true, true, true];
	 this.customlabels = [];

	 this.clabeloffset = "202px";
	 this.elabelmode = "";

	 this.SetColor = function ( )
	 {
	 	if(this.elementlabel=="None") {this.cc = 'rgba(0, 0, 0, 1)'; this.ccus = 'rgba(0, 0, 0, .5)';}
	 	else if(this.elementlabel=="PPF" && this.bookcolor=="Yes") {this.cc = 'rgba(170, 95, 166, 1)'; this.ccus = 'rgba(170, 95, 166, .5)';}
	 	else if(this.elementlabel=="Demand" && this.bookcolor=="Yes") {this.cc = 'rgba(0, 131, 173, 1)'; this.ccus = 'rgba(0, 131, 173, .5)';}
	 	else if(this.elementlabel=="Supply" && this.bookcolor=="Yes") {this.cc = 'rgba(219, 92, 28, 1)'; this.ccus = 'rgba(219, 92, 28, .5)';}
	 	else if(this.elementlabel=="Fixed Cost" && this.bookcolor=="Yes") {this.cc = 'rgba(188, 189, 192, 1)'; this.ccus = 'rgba(188, 189, 192, .5)';}
	 	else if(this.elementlabel=="Indifference" && this.bookcolor=="Yes") {this.cc = 'rgba(247, 147, 29, 1)'; this.ccus = 'rgba(247, 147, 29, .5)';}
	 	else if(this.elementlabel=="Marginal Cost" && this.bookcolor=="Yes") {this.cc = 'rgba(247, 147, 29, 1)'; this.ccus = 'rgba(247, 147, 29, .5)';}
	 	else if(this.elementlabel=="Marginal Revenue" && this.bookcolor=="Yes") {this.cc = 'rgba(35, 31, 32, 1)'; this.ccus = 'rgba(35, 31, 32, .5)';}
	 	else if(this.elementlabel=="Total Cost" && this.bookcolor=="Yes") {this.cc = 'rgba(219, 92, 28, 1)'; this.ccus = 'rgba(219, 92, 28, .5)';}
	 	else if(this.elementlabel=="Variable Cost" && this.bookcolor=="Yes") {this.cc = 'rgba(238, 165, 122, 1)'; this.ccus = 'rgba(238, 165, 122, .5)';}
	 	else {this.cc = 'rgba(0, 0, 0, 1)'; this.ccus = 'rgba(0, 0, 0, .5)';}
	 }

	 this.setStudentColor = function ( )
	 {
	 	if(this.studentcorrectlabel=="None") {this.cc = 'rgba(0, 0, 0, 1)'; this.ccus = 'rgba(0, 0, 0, .5)';}
	 	else if(this.studentcorrectlabel=="PPF") {this.cc = 'rgba(170, 95, 166, 1)'; this.ccus = 'rgba(170, 95, 166, .5)';}
	 	else if(this.studentcorrectlabel=="Demand") {this.cc = 'rgba(0, 131, 173, 1)'; this.ccus = 'rgba(0, 131, 173, .5)';}
	 	else if(this.studentcorrectlabel=="Supply") {this.cc = 'rgba(219, 92, 28, 1)'; this.ccus = 'rgba(219, 92, 28, .5)';}
	 	else if(this.studentcorrectlabel=="Fixed Cost") {this.cc = 'rgba(188, 189, 192, 1)'; this.ccus = 'rgba(188, 189, 192, .5)';}
	 	else if(this.studentcorrectlabel=="Indifference") {this.cc = 'rgba(247, 147, 29, 1)'; this.ccus = 'rgba(247, 147, 29, .5)';}
	 	else if(this.studentcorrectlabel=="Marginal Cost") {this.cc = 'rgba(247, 147, 29, 1)'; this.ccus = 'rgba(247, 147, 29, .5)';}
	 	else if(this.studentcorrectlabel=="Marginal Revenue") {this.cc = 'rgba(35, 31, 32, 1)'; this.ccus = 'rgba(35, 31, 32, .5)';}
	 	else if(this.studentcorrectlabel=="Total Cost") {this.cc = 'rgba(219, 92, 28, 1)'; this.ccus = 'rgba(219, 92, 28, .5)';}
	 	else if(this.studentcorrectlabel=="Variable Cost") {this.cc = 'rgba(238, 165, 122, 1)'; this.ccus = 'rgba(238, 165, 122, .5)';}
	 	else {this.cc = 'rgba(0, 0, 0, 1)'; this.ccus = 'rgba(0, 0, 0, .5)';}
	 }

     this.DrawMe = function( ctx )
     {
         if( graphSe.mode != "correct" && graphSe.mode != "student" && graphSe.mode != this.mode 
             || (this.mode == 'correct' && graphSe.mode == "student") ) return;
         
         var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxg : this.xg );
         var ypx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syg : this.yg );
         
         var xspx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxsg : this.xsg );
         var yspx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.sysg : this.ysg );
         var xepx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxeg : this.xeg );
         var yepx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syeg : this.yeg );
         
         //this.SetColor();
         var clr = this.iscurrent == true ? this.cc: this.ccus;
     
     	 if(graphSe.mode == "student") clr = this.cc;
          
         if( graphSe.boo && this.ghost && this.mode!="correct" )
         {
             var gh = this.ghost;
             var gxspx = graphSe.ConvertXgToXpx( graphSe.snapIt ? gh.sxsg : gh.xsg );
             var gyspx = graphSe.ConvertYgToYpx( graphSe.snapIt ? gh.sysg : gh.ysg );
             var gxepx = graphSe.ConvertXgToXpx( graphSe.snapIt ? gh.sxeg : gh.xeg );
             var gyepx = graphSe.ConvertYgToYpx( graphSe.snapIt ? gh.syeg : gh.yeg );
             
             var dsx = xspx-gxspx;
             var dsy = yspx-gyspx;
             var dex = xepx-gxepx;
             var dey = yepx-gyepx;
             
             /*var tol = 4;
             if( (Math.sqrt(dsx*dsx+dsy*dsy) > tol) && (Math.sqrt(dex*dex+dey*dey) > tol) )*/
                 DrawLine( gh.clr, gh.wd, gxspx, gyspx, gxepx, gyepx, [2, 2] );
         
            if(this.labelLine==true)
            {
				text = new paper.PointText(new paper.Point(gxepx+10, gyepx+17));
				text.justification = 'center';
				text.fillColor = this.ccus;
				text.content = this.label;
			}	
         
         
         }

         if( xepx != undefined )
             DrawLine( clr, this.width, xspx, yspx, xepx, yepx );

	
         if( this.plumbLine ) this.PlumbLine( );
         
         if( this.iscurrent ) this.ControlPoints( );
	 
	 if( this.labelLine ) this.LabelLine( );

     }
     
     this.UnitMe = function( )
     {
         var xsPx = graphSe.ConvertXpxToXg( this.xsg );
         var ysPx = graphSe.ConvertYpxToYg( this.ysg );
         var xePx = graphSe.ConvertXpxToXg( this.xeg );
         var yePx = graphSe.ConvertYpxToYg( this.yeg );
         
         var ps = new paper.Point( xsPx, ysPx );
         var pe = new paper.Point( xePx, yePx );
         this.uvPx = pe.subtract(ps).normalize();
         return;
     }
     
     this.TrackAlong = function( lbl )
     {
         if( lbl != undefined ) this.trackAlongLabel = lbl;
     
         this.trackElement = graphSe.FindInGraph( this.trackAlongLabel );
         
         if( this.trackElement != null )
         {
             var t = this.trackElement;
             switch( t.constructor.name )
             {
                 case "Line":       
                     this.ang = Math.atan2(this.yeg - this.ysg, this.xeg - this.xsg);
                     this.trackAng = Math.atan2(t.yeg - t.ysg, t.xeg - t.xsg);
                     this.Track = this.TrackLine;
                     break;
                 case "Curve":
                 case "Polyline":
                     if( lbl != undefined ) 
                     {
                         this.trackOffset = -1;
                         this.trackXg = t.pts[0];
                         this.trackYg = t.pts[1];
                         this.Track = this.TrackPath;
                     }
                     break;
             }
         }
     }
     
     this.TrackLine = function( dist )
     {  
         var ang = this.trackAng;
         var dx = Math.cos(ang)*dist;
         var dy = Math.sin(ang)*dist;
         
         return { sx: dx, sy: dy };
     }
     
     this.TrackPath = function( dist )
     {  
         var pt;
         var te = this.trackElement;
         
         var path = te.myPath;
         if( path == undefined ) path = te.path;
         
         this.UnitMe( );
         
         if( this.trackOffset == -1 )
         {
             this.PathMe();
             var gii = this.path.getIntersections( path );
             var g0 = gii[0];
             if( g0 != undefined)
             {
                 this.trackOffset = path.getOffsetOf( g0.point )/path.length;
             
                 this.ds = g0.point.getDistance( this.path.segments[0].point );
                 this.de = g0.point.getDistance( this.path.segments[1].point );
             }
         }
         
         if( this.trackOffset >= 0 )
         { 
             var pathOffset = this.trackOffset*path.length;
             pt = path.getPointAt(pathOffset);
         
             if( this.ds >= this.de )
             {
                 var psx = pt.subtract(this.uvPx.multiply(this.ds));
                 var txsg = graphSe.ConvertXpxToXg( psx.x );
                 var tysg = graphSe.ConvertYpxToYg( psx.y );
                 var tdx = txsg - this.xsg;
                 var tdy = tysg - this.ysg;
             }
             else
             {
                 var pex = pt.add(this.uvPx.multiply(this.de));
                 var txeg = graphSe.ConvertXpxToXg( pex.x );
                 var tyeg = graphSe.ConvertYpxToYg( pex.y );
                 var tdx = txeg - this.xeg;
                 var tdy = tyeg - this.yeg;
             }
         
             if( dist > 0 && this.trackOffset < .985 ) this.trackOffset += .015;
             else if( dist < 0 && this.trackOffset > .015) this.trackOffset -= .015;
         }
         else { tdx = 0; tdy = 0; }
         
         return { sx: tdx, sy: tdy};
     }
     
     this.Track = this.TrackLine;
     
     
     this.CorrectToDesigner = function( )
     {
         if( this.ghost )
         {
             var gh = this.ghost;
             this.xsg = gh.xsg;
             this.ysg = gh.ysg;
             this.xeg = gh.xeg;
             this.yeg = gh.yeg;
             this.sxsg = gh.sxsg;
             this.sysg = gh.sysg;
             this.sxeg = gh.sxeg;
             this.syeg = gh.syeg;
         }
     }
     
     this.DesignerToCorrect = function( )
     {
         if( this.correct.length > 0 )
         {
             var ca = this.correct[0];
             this.xsg = ca.xsg;
             this.ysg = ca.ysg;
             this.xeg = ca.xeg;
             this.yeg = ca.yeg;
             this.SnapMe( );
         } 
     
     
     }
     
     
     this.ControlPoints = function( )
     {
         var pt = graphSe.snapIt ? { x: this.sxsg, y: this.sysg } : { x: this.xsg, y: this.ysg };
         var ps = new paper.Path.Circle(new paper.Point(graphSe.ConvertXgToXpx(pt.x), graphSe.ConvertYgToYpx(pt.y)), graphSe.handleRadius);
         ps.strokeColor = graphSe.handleColor;
         ps.strokeWidth = 1;
         
         if( this.xeg != undefined )
         {
             pt = graphSe.snapIt ? { x: this.sxeg, y: this.syeg } : { x: this.xeg, y: this.yeg };
             var pe = new paper.Path.Circle(new paper.Point(graphSe.ConvertXgToXpx(pt.x), graphSe.ConvertYgToYpx(pt.y)), graphSe.handleRadius);
             pe.strokeColor = graphSe.handleColor;
             pe.strokeWidth = 1;
         }
     }
     
     this.SnapMe = function( )
     {
         this.sxsg = graphSe.SnapX( this.xsg );
	     this.sysg = graphSe.SnapY( this.ysg );
	     this.sxeg = graphSe.SnapX( this.xeg );
	     this.syeg = graphSe.SnapX( this.yeg );
     }
     
     this.AddEndPt = function( xxe, yye, done )
     {
         this.xeg = graphSe.ConvertXpxToXg( xxe );
	     this.yeg = graphSe.ConvertYpxToYg( yye );
	     
	     this.sxeg = graphSe.SnapX( this.xeg );
	     this.syeg = graphSe.SnapY( this.yeg );
	     
	     this.UnitMe( );
	     
	     if( graphSe.mode == "correct" ) this.CorrectMe( );
	     if( graphSe.mode == "student" && done ) this.CheckIsCorrect( "drawing" );
	     
	     this.SetSettings();
     }
     
     this.PathMe = function( )
     {
         this.path = new paper.Path( );
         
         var xspx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxsg : this.xsg );
         var yspx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.sysg : this.ysg ); 
         var xepx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxeg : this.xeg );
         var yepx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syeg : this.yeg );
         
         this.path.add( new paper.Point( xspx, yspx) );
         this.path.add( new paper.Point( xepx, yepx) );
     }
     
     this.HitMe = function( pxy, tol )
     {
         var hitCp = false;
         var xspx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxsg : this.xsg );
         var yspx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.sysg : this.ysg );
         var xepx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxeg : this.xeg );
         var yepx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syeg : this.yeg );
         
         if( tol == undefined ) tol = 4;
          
         var a = new paper.Point( xspx, yspx );
         var b = new paper.Point( xepx, yepx );
         var p = new paper.Point( pxy.x, pxy.y );
         var ab = b.subtract(a).length;
         var ap = p.subtract(a).length;
         var pb = b.subtract(p).length;
         
         var onLine = Math.abs(ab - ap - pb) < tol;
         if( !onLine )
         {
              var xsg = graphSe.snapIt ? this.sxsg : this.xsg;
              var ysg = graphSe.snapIt ? this.sysg : this.ysg;
              var xeg = graphSe.snapIt ? this.sxeg : this.xeg;
              var yeg = graphSe.snapIt ? this.syeg : this.yeg;
                 
              hitCp = graphSe.HitPt(pxy, xsg, ysg, graphSe.handleRadius) ||
                      graphSe.HitPt(pxy, xeg, yeg, graphSe.handleRadius);
         }
         
         return onLine || hitCp;
     }
     
     this.MoveMe = function( type, dx, dy )
     {
         if( type == "start" || type == "all" ) { this.xsg -= dx; this.ysg -= dy; }
         if( type == "end" || type == "all" ) { this.xeg -= dx; this.yeg -= dy; }
	     this.SnapMe( );
     }
     
     this.ControlMe = function( tf )
     {
         this.showControl = tf; 
     }
     
     this.DragMe = function( mpt, drgSt )
     {
         if( drgSt != undefined ) this.dragState = drgSt;
         
         switch( this.dragState )
         {
             case "off":
                 if( graphSe.boo && this.interactive && !this.ghost ) this.GhostMe( ); 
                 
                 dragObj = this;
                 this.dragstart = mpt;
                 this.dragDxDy = { dx: 0, dy: 0 };
                 var pts = graphSe.snapIt ? { x: this.sxsg, y: this.sysg } : { x: this.xsg, y: this.ysg };
                 var pte = graphSe.snapIt ? { x: this.sxeg, y: this.syeg } : { x: this.xeg, y: this.yeg };
                 if( graphSe.HitPt(mpt,pts.x,pts.y,graphSe.handleRadius) ) this.dragState = "dragStart";
                 else if( graphSe.HitPt(mpt,pte.x,pte.y,graphSe.handleRadius) ) this.dragState = "dragEnd";
                 else this.dragState = "dragLine"; 
	             this.SetElementPoints( );

	     		 if(graphSe.mode=="correct") this.SetCorrectPoints();
                  if(graphSe.mode=="correct")Precise(true);
                if(graphSe.mode=="student")this.studentdrag=true;
                break;
                 
             case "dragStart":
                 //if( graphSe.boo && !this.ghost ) this.GhostMe( ); 
                 
                 var dsxg = graphSe.ConvertXpxToXg( this.dragstart.x ) - graphSe.ConvertXpxToXg( mpt.x );
	             var dsyg = graphSe.ConvertYpxToYg( this.dragstart.y ) - graphSe.ConvertYpxToYg( mpt.y );
	             this.xsg -= dsxg;
	             this.ysg -= dsyg;
	             this.SnapMe( );
	             this.SetElementPoints( );

	     		 if(graphSe.mode=="correct") this.SetCorrectPoints();
	             this.dragstart = mpt;
	             this.dragDxDy = { dx: this.dragDxDy.dx += dsxg, dy: this.dragDxDy.dy += dsyg };
	             this.dragPt = "start"
	             break;
	             
	         case "dragEnd":
	             //if( graphSe.boo && !this.ghost ) this.GhostMe( ); 
	             
	             var dsxg = graphSe.ConvertXpxToXg( this.dragstart.x ) - graphSe.ConvertXpxToXg( mpt.x );
	             var dsyg = graphSe.ConvertYpxToYg( this.dragstart.y ) - graphSe.ConvertYpxToYg( mpt.y );
	             this.xeg -= dsxg;
	             this.yeg -= dsyg;
	             this.SnapMe( );
	             this.SetElementPoints( );

	     		 if(graphSe.mode=="correct") this.SetCorrectPoints();
	             this.dragstart = mpt;
	             this.dragDxDy = { dx: this.dragDxDy.dx += dsxg, dy: this.dragDxDy.dy += dsyg };
	             this.dragPt = "end";
	             break; 
	             
	         case "dragLine":
	             //if( graphSe.boo && !this.ghost ) this.GhostMe( ); 
	             
	             //var dsxg = graphSe.ConvertXpxToXg( this.dragstart.x ) - graphSe.ConvertXpxToXg( mpt.x );
	             //var dsyg = graphSe.ConvertYpxToYg( this.dragstart.y ) - graphSe.ConvertYpxToYg( mpt.y );
	             var dsxg = graphSe.ConvertXpxToXg( mpt.x ) - graphSe.ConvertXpxToXg( this.dragstart.x );
	             var dsyg = graphSe.ConvertYpxToYg( mpt.y ) - graphSe.ConvertYpxToYg( this.dragstart.y ); 
	             
	             if( this.taelement != "None" )
	             {
	                 this.TrackAlong( );
	                 var s = this.Track( dsxg );
	                 dsxg = s.sx;
	                 dsyg = s.sy;
	             }
	             
	             this.xsg += dsxg;
	             this.ysg += dsyg;
	             this.xeg += dsxg;
	             this.yeg += dsyg;
	             this.SnapMe( );
	             
	             this.SetElementPoints( );

	     		 if(graphSe.mode=="correct") this.SetCorrectPoints();

	             
	             this.dragstart = mpt;
	             this.dragDxDy = { dx: this.dragDxDy.dx -= dsxg, dy: this.dragDxDy.dy -= dsyg };
	             this.dragPt = "all";
	             break;
	             
	         case "drop":
	             dragObj = null;
	             if( this.taelement != "None" ) this.TrackAlong( this.taelement );
	             this.dragState = "off";
	             this.dragStart = null;
	             if( this.dragDxDy.dx != 0 || this.dragDxDy.dy != 0 )
	             {
	                 this.SetElementPoints( );
	     		     if(graphSe.mode=="correct") this.SetCorrectPoints(); 
	                 graphSe.OpsMoveElement( this, this.dragPt, -this.dragDxDy.dx, -this.dragDxDy.dy );
	                 if( graphSe.mode == "correct" ) this.CorrectMe( );
	                 if( graphSe.mode == "student" ) this.CheckIsCorrect( );
	                 if( graphSe.mode == "designer" && this.interactive ) this.GhostMe();
	             }
	             break;
         }
     }
     
     this.CorrectMe = function( type )
     {
         this.correct[0] = { type: type == undefined ? "precise" : type, lbl: this.label, xsg: this.xsg, ysg: this.ysg, xeg: this.xeg, yeg: this.yeg,
         	sxsg: this.sxsg, sysg: this.sysg, sxeg: this.sxeg, syeg: this.syeg };
     }
     
     this.CheckIsCorrect = function( mode )
     {
         var tst=true;
         this.labelcorrect=false;
         
         if( this.correct.length > 0 && mode == undefined )
         {
             var typ = this.correct[0].type;
             var area = (typ != undefined) && (typ.length == 3);
             if( typ == "precise" || typ == undefined || area  )
             {
                 var ca = this.correct[0];
                 var pxs = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxsg : this.xsg );
                 var pys = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.sysg : this.ysg );
                 var pxe = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxeg : this.xeg );
                 var pye = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syeg : this.yeg );
                 switch( ca.lbl[0] )
                 {
                     case 'L':
                         var cxs = graphSe.ConvertXgToXpx( graphSe.snapIt ? ca.sxsg : ca.xsg );
                         var cys = graphSe.ConvertYgToYpx( graphSe.snapIt ? ca.sysg : ca.ysg );
                         var cxe = graphSe.ConvertXgToXpx( graphSe.snapIt ? ca.sxeg : ca.xeg );
                         var cye = graphSe.ConvertYgToYpx( graphSe.snapIt ? ca.syeg : ca.yeg );
                         var dxs = pxs - cxs;
                         var dys = pys - cys;
                         var dxe = pxe - cxe;
                         var dye = pye - cye;
                         
                         var ds = Math.sqrt(dxs*dxs + dys*dys);
                         var de = Math.sqrt(dxe*dxe + dye*dye);
                         
                         var dxsr = pxs - cxe;
                         var dysr = pys - cye;
                         var dxer = pxe - cxs;
                         var dyer = pye - cys;
                         
                         var dsr = Math.sqrt(dxsr*dxsr + dysr*dysr);
                         var der = Math.sqrt(dxer*dxer + dyer*dyer);
                         
                         ds = Math.min(ds,dsr);
                         de = Math.min(de,der);
                         
                         tst = ds < this.correctTolerance && de < this.correctTolerance;
                         break;       
                     case 'A':
                         var aao = graphSe.FindInGraph( ca.lbl );
                         tst = aao.path.contains(new paper.Point(pxs,pys)) 
                               && aao.path.contains(new paper.Point(pxe,pye));
                         break;
                           
                     default:
                         tst = false;
                         break; 
                 }
             }
             else if( typ.length == 2 )
             {
                 var rele;
                 this.PathMe( );
                 //var ca = this.correct[0];
                 var ca = this; 
                 var cpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? ca.sxsg : ca.xsg );
                 var cpy = graphSe.ConvertYgToYpx( graphSe.snapIt ? ca.sysg : ca.ysg );
                 var cpxe = graphSe.ConvertXgToXpx( graphSe.snapIt ? ca.sxeg : ca.xeg );
                 var cpye = graphSe.ConvertYgToYpx( graphSe.snapIt ? ca.syeg : ca.yeg );
                 
                 rele = graphSe.FindInGraph( this.relementlabel );
                 if( rele instanceof Line )
                 {  
                     if( rele == this ) rele = this.correct[0]; 
                      
                     var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.sxsg : rele.xsg );
                     var ypx = graphSe.ConvertYgToYpx( graphSe.snapIt ? rele.sysg : rele.ysg );
                     var xpxe = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.sxeg : rele.xeg );
                     var ypxe = graphSe.ConvertYgToYpx( graphSe.snapIt ? rele.syeg : rele.yeg );
                 
                     var s = new paper.Point(xpx,ypx);
                     var e = new paper.Point(xpxe,ypxe);
                     var cs = new paper.Point(cpx,cpy);
                     var ce = new paper.Point(cpxe,cpye);
                     
                     var isLeft = (e.x - s.x)*(cs.y - s.y) > (e.y - s.y)*(cs.x - s.x) &&
                                  (e.x - s.x)*(ce.y - s.y) > (e.y - s.y)*(ce.x - s.x);
                              
                              
                 
                     var lfrt = typ[1];
                     if( lfrt == "left" && isLeft ) tst = true;
                     else if( lfrt == "right" && !isLeft ) tst = true;
                     else tst = false;
                 }
                 else if( rele instanceof Point )
                 {
                     var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.sxg : rele.xg );
                     var ypx = graphSe.ConvertYgToYpx( graphSe.snapIt ? rele.syg : rele.yg );
                     var cpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxsg : this.xsg );
                     var cpxe = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxeg : this.xeg );
                     
                     var lfrt = typ[1];
                     if( lfrt == "left" && cpx < xpx && cpxe < xpx ) tst = true;
                     else if( lfrt == "right" && cpx > xpx && cpxe > xpx) tst = true;
                     else tst = false;
                 }
                 else if( rele instanceof Curve )
                 {
                     var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.spts[0] : rele.pts[0] );  
                     var xpxe = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.spts[4] : rele.pts[4] );
                     if( xpxe < xpx ) { var t = xpx; xpx = xpxe; xpxe = t; }
                     var cpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxsg : this.xsg );
                     var cpxe = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxeg : this.xeg );
                 
                     var lfrt = typ[1];
                     if( lfrt == "left" && cpx < xpx && cpxe < xpx ) tst = true;
                     else if( lfrt == "right" && cpx > xpxe && cpxe > xpxe) tst = true;
                     else tst = false;
                 }
                 else if( rele instanceof Polyline )
                 {
                     for( var i = 0, ln = rele.pts.length-2, xmn = 10000, xmx = 0; i < ln; i += 2 )
                     {
                         var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.spts[i] : rele.pts[i] );
                         if( xpx < xmn ) xmn = xpx;
                         else if( xpx > xmx ) xmx = xpx;
                     }
                          
                     var cpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxsg : this.xsg );
                     var cpxe = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxeg : this.xeg );
                 
                     
                     var lfrt = typ[1];
                     if( lfrt == "left" && cpx < xmn && cpxe < xmn ) tst = true;
                     else if( lfrt == "right" && cpx > xmx && cpxe > xmx) tst = true;
                     else tst = false;
                 }
                 
             }
         }
         else if( mode == "drawing" )
         {
             for( var i = 0, tst = false, ln = graphMe.length; i < ln  && !tst; i++ )
             {
                 var gi = graphMe[i];
                 if( gi.mode == "correct" && gi.what == this.what )
                 {
                     var pxs = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxsg : this.xsg );
                     var pys = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.sysg : this.ysg );
                     var pxe = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxeg : this.xeg );
                     var pye = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syeg : this.yeg );
                     var cxs = graphSe.ConvertXgToXpx( graphSe.snapIt ? gi.sxsg : gi.xsg );
                     var cys = graphSe.ConvertYgToYpx( graphSe.snapIt ? gi.sysg : gi.ysg );
                     var cxe = graphSe.ConvertXgToXpx( graphSe.snapIt ? gi.sxeg : gi.xeg );
                     var cye = graphSe.ConvertYgToYpx( graphSe.snapIt ? gi.syeg : gi.yeg );
                     var dxs = pxs - cxs;
                     var dys = pys - cys;
                     var dxe = pxe - cxe;
                     var dye = pye - cye;
                     
                     tst = Math.sqrt(dxs*dxs + dys*dys) < this.correctTolerance 
                           && Math.sqrt(dxe*dxe + dye*dye) < this.correctTolerance
                 }
             }
         }
 
         this.feedback = tst ? this.correctgraph=true : this.correctgraph=false;

         
         if(this.requiredlabel)
         {
         	if(this.correctlabel==this.studentcorrectlabel) 
         	{
         		this.labelcorrect=true;
         	} else {
         		this.labelcorrect=false;
         	}		
         	
         } else 
         {
         	this.labelcorrect=true;
         }
         
         if(this.correctgraph==true && this.labelcorrect==true)
         {
         	this.iscorrect="<span style='color:green;'>Correct</span>";
         }	else {
         	this.iscorrect="<span style='color:red'>Not Correct</span>";
         }	
         
         //SayFeedback( this.feedback );
     }
     
     this.GhostMe = function( )
     {
         //if( !this.ghost )
         //{
             this.ghost = { clr: "darkgray", wd: this.width, xsg: this.xsg, ysg: this.ysg, sxsg: this.sxsg, sysg: this.sysg,
                       xeg: this.xeg, yeg: this.yeg, sxeg: this.sxeg, syeg: this.syeg };
         //}
     }
     
     this.PlumbMe = function( tf )
     {
         this.plumbLine = tf;
     }

     this.LabelMe = function( tf )
     {
         this.labelLine = tf;
     }     
     
     this.PlumbLine = function( )
     {
         this.PathMe( );
         var ln = graphMe.length;
         for( var j = 0; j < ln; j++ ) 
         {
              var gj = graphMe[j];
              if( gj == this ) continue;
              
              if( gj instanceof Point )
              {
                   var px = graphSe.ConvertXgToXpx( graphSe.snapIt ? gj.sxg : gj.xg );
                   var py = graphSe.ConvertYgToYpx( graphSe.snapIt ? gj.syg : gj.yg );
                   
                   if( this.HitMe( {x: px, y: py}, .2 ) ) 
                   {
                        var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? gj.sxg : gj.xg );
                        var ypx = graphSe.ConvertYgToYpx( graphSe.snapIt ? gj.syg : gj.yg ); 
                        
                        var clr = 'grey';
                        DrawLine( clr, this.width, xpx, ypx, 0, ypx, [4, 4] ); 
                        DrawLine( clr, this.width, xpx, ypx, xpx, can.height-3, [4, 4] );
                   }
                  
              }
              else
              {
                   gj.PathMe();
                   var gii = this.path.getIntersections( gj.path );
            
                   for (var k = 0; k < gii.length; k++)
                   {
                          var clr = 'grey';
                          var giik = gii[k];
                          DrawLine( clr, 1, giik.point.x, giik.point.y, 0, giik.point.y, [4, 4] );
                          DrawLine( clr, 1, giik.point.x, giik.point.y, giik.point.x, can.height-3, [4, 4] );

 
  						var text = new paper.PointText(new paper.Point(15, giik.point.y-10));
						text.justification = 'center';
						text.fillColor = "grey";
						text.fontSize = 10
						text.content = Math.round(graphSe.ConvertYpxToYg(giik.point.y)*10)/10;

  						var text = new paper.PointText(new paper.Point(giik.point.x+14, 375));
						text.justification = 'center';
						text.fillColor = "grey";
						text.fontSize = 10
						text.content = Math.round(graphSe.ConvertXpxToXg(giik.point.x)*10)/10

/*
			              ctx2.fillStyle = "grey";
			              ctx2.fillText(Math.round(graphSe.ConvertYpxToYg(giik.point.y)*10)/10,55,giik.point.y+10);
                  
		                  ctx2.fillStyle = "grey";
			              ctx2.fillText(Math.round(graphSe.ConvertXpxToXg(giik.point.x)*10)/10,giik.point.x+54,395);		                   		  
*/
                   }
              }
         }
     }


	 this.checkBoxes = function()
	 {
	 	if(document.getElementById('demand').checked) {this.checkboxes[0]=true} else {this.checkboxes[0]=false};
	 	if(document.getElementById('fixedcost').checked) {this.checkboxes[1]=true} else {this.checkboxes[1]=false};
	 	if(document.getElementById('indifference').checked) {this.checkboxes[2]=true} else {this.checkboxes[2]=false};
	 	if(document.getElementById('marginalcost').checked) {this.checkboxes[3]=true} else {this.checkboxes[3]=false};
	 	if(document.getElementById('marginalrevenue').checked) {this.checkboxes[4]=true} else {this.checkboxes[4]=false};
	 	if(document.getElementById('ppf').checked) {this.checkboxes[5]=true} else {this.checkboxes[5]=false};
	 	if(document.getElementById('supply').checked) {this.checkboxes[6]=true} else {this.checkboxes[6]=false};
	 	if(document.getElementById('totalcost').checked) {this.checkboxes[7]=true} else {this.checkboxes[7]=false};
	 	if(document.getElementById('variablecost').checked) {this.checkboxes[8]=true} else {this.checkboxes[8]=false};

		for(var i=0; i<this.customlabels.length; i++)
		{
		 	var str = this.customlabels[i];
		 	var lwr = str.toLowerCase();
		 	str = lwr.replace(/\s+/g, '');

			if(document.getElementById(str).checked) {this.checkboxes[8+i+1]=true} else {this.checkboxes[8+i+1]=false};	
				 	
		 	//html += '<input type="checkbox" id="'+str+'" checked> '+this.customlabels[i]+'<br>'
		 	//this.checkboxes[i+9] = false;
		}


     	this.CorrectLabelDropdown(); 

     	//this.SetSettings();

	 }
	 
	 this.checkBoxHTML = function()
	 {
	 	var html = '';
	 	
	 	if(this.checkboxes[0])
	 	{
	 		html += '<input type="checkbox" id="demand" checked> Demand<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="demand"> Demand<br>'	 	
	 	}
	 	
	 	if(this.checkboxes[1])
	 	{
	 		html += '<input type="checkbox" id="fixedcost" checked> Fixed Cost<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="fixedcost"> Fixed Cost<br>'	 	
	 	}	 	
	 	
	 	if(this.checkboxes[2])
	 	{
	 		html += '<input type="checkbox" id="indifference" checked> Indifference<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="indifference"> Indifference<br>'	 	
	 	}
	 	
	 	if(this.checkboxes[3])
	 	{
	 		html += '<input type="checkbox" id="marginalcost" checked> Marginal Cost<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="marginalcost"> Marginal Cost<br>'	 	
	 	}
	 	
	 	if(this.checkboxes[4])
	 	{
	 		html += '<input type="checkbox" id="marginalrevenue" checked> Marginal Revenue<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="marginalrevenue"> Marginal Revenue<br>'	 	
	 	}
	 		 	
	 	if(this.checkboxes[5])
	 	{
	 		html += '<input type="checkbox" id="ppf" checked> PPF<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="ppf"> PPF<br>'	 	
	 	}

	 	if(this.checkboxes[6])
	 	{
	 		html += '<input type="checkbox" id="supply" checked> Supply<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="supply"> Supply<br>'	 	
	 	}	 		 

	 	if(this.checkboxes[7])
	 	{
	 		html += '<input type="checkbox" id="totalcost" checked> Total Cost<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="totalcost"> Total Cost<br>'	 	
	 	}		 	

	 	if(this.checkboxes[8])
	 	{
	 		html += '<input type="checkbox" id="variablecost" checked> Variable Cost<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="variablecost"> Variable Cost<br>'	 	
	 	}			 	

		for(var i=0; i<this.customlabels.length; i++)
		{
		 	var str = this.customlabels[i];
		 	var lwr = str.toLowerCase();
		 	str = lwr.replace(/\s+/g, '');
		 	
		 	html += '<input type="checkbox" id="'+str+'" checked> '+this.customlabels[i]+'<br>'
		 	//this.checkboxes[i+9] = false;
		}

	 	this.checkboxhtml = html;
	 	
	 	//document.getElementById('checkform').innerHTML = this.checkboxhtml;
	 }

     this.SetSettings = function( )
     {
     	 this.CalculateSlope();
     	 //this.LineUpdate();
     	    
     	 this.TrackAgainstDropdown();   
     	 this.RelativeDropdown();  
     	 this.checkBoxHTML();
     	      	 
     	 $('#bottomtools').removeClass("hide");
     	 
     	 var html = '<div class="sectionhead"><span id="elementhead">Element Settings</span><button class="glyphicon glyphicon-left" aria-hidden="true" style="margin-left: 30px; background: none; border: none;" onclick="leftArrow();"></button><span id="toplabel'+this.labelvalue+'" class="elementid">'+this.label+'</span><button class="glyphicon glyphicon-right" aria-hidden="true" onclick="rightArrow();" style="background: none; border: none;"></span></div>'
     	 html += '<div class="hrm"></div>'
		 html += '<div class="row" style="margin-left: 20px;">'
		 html += '<div class="col-sm-6">'
     	 html += '<div id="designertools">'
		 html += '<div class="tool">Element Type</div>'
		 html += '<div class="tool"></div>'
		 html += '<div class="tool">Label</div>'
		 html += '<div class="tool">Show Label</div>'
		 html += '<div class="tool">Slope</div>'
		 html += '<div class="tool">Origin Point</div>'
		 html += '<div class="tool">End Point</div>'
		 html += '<div class="tool">Show Plumbs</div>'
		 html += '</div>'
		 html += '</div>'
		 html += '<div class="col-sm-6" style="padding-top: 8px;">'
     	 html += '<div id="designerinputs">'
		 html += '<div class="styled-select"><select id="eldropdown" class="select-class" onchange="GetElement(this.value)"></span><option value="None">None</option><option value="Demand">Demand</option><option value="Fixed Cost">Fixed Cost</option><option value="Indifference">Indifference</option><option value="Marginal Cost">Marginal Cost</option><option value="Marginal Revenue">Marginal Revenue</option><option value="PPF">PPF</option><option value="Supply">Supply</option><option value="Total Cost">Total Cost</option><option value="Variable Cost">Variable Cost</option></select></div>'
		 html += '<button id="bcbutton" aria-hidden="true" onclick="bookColor();">Use Book Color <span class="glyphicon glyphicon-uncheckedmm"></span></button>'
		 html += '<div><input id="xlabel'+this.labelvalue+'" type="text" class="small-label" placeholder="'+this.label+'" onkeyup="labelUpdate(this.value)" maxlength="5"></div>'	  			
		 html += '<div><label class="switch tool"><input id="labeltoggle" type="checkbox" onclick="update();"><div class="slider"><span class="ontext">ON</span><span class="offtext">OFF</span></div></label></div>'
		 html += '<div><input id="slope" type="number" step="0.01" class="slope-input" placeholder="'+this.m+'" value="'+this.m+'" oninput="slopeUpdate(this.value)"></div>'	  			
		 html += '<div>(<input id="xspoint" type="number" class="point-input" value="'+this.xsg+'" step="'+graphSe.xmax/Number(graphSe.wdPx)+'" oninput="xsUpdate(this.value)">,<input id="yspoint" type="number" class="point-input" value="'+this.ysg+'" step="'+graphSe.ymax/Number(graphSe.htPx)+'" oninput="ysUpdate(this.value)" >)</div>'	  			
		 html += '<div>(<input id="xepoint" type="number" class="point-input" value="'+this.xeg+'" step="'+graphSe.xmax/Number(graphSe.wdPx)+'" oninput="xeUpdate(this.value)" >,<input id="yepoint" type="number" class="point-input" value="'+this.yeg+'" step="'+graphSe.ymax/Number(graphSe.htPx)+'" oninput="yeUpdate(this.value)" >)</div>'	  			
		 html += '<div><label class="switch tool"><input id="plumbtoggle" type="checkbox" onclick="update();"><div class="slider"><span class="ontext">ON</span><span class="offtext">OFF</span></div></label></div>'
		 html += '</div>'	  			
		 html += '</div>'	  			
	     html += '</div>'		

     	 $('#interactive').removeClass("hide");

     	 var html2 = '<div id="sectionpadding" class="sectionhead"></div>'
		 html2 += '<div class="row" style="margin-left: 20px;">'
		 html2 += '<div id="intleft" class="col-sm-6">'
		 html2 += '<button class="fake-radio" id="binteractive" onclick="Interactive(true);"> <div class="radio-off"><div id="binteractivero" class="radio-on hide"></div></div>Interactive</button><br>'
		 html2 += '<div id="ilabels" class="hide"><div class="tool">Label after move</div>'
		 html2 += '<div class="tool">Track against</div>'		 
		 html2 += '</div>'
		 html2 += '</div>'		 
		 html2 += '<div id="intright" class="col-sm-6">'
		 html2 += '<button class="fake-radio" id="bstatic" onclick="Interactive(false);"> <div class="radio-off"><div id="bstaticro" class="radio-on"></div></div>Static<br></button>'
		 html2 += '<div id="iinputs" class="hide"><div><input id="labelam" type="text" value="'+this.labelam+'" oninput="labelAMUpdate(this.value)" style="margin-top: 10px; width: 75px"></div>'	  			
		 html2 += '<div class="styled-select"><select id="tadropdown" class="select-class" onchange="TAElement(this.value)" value="'+this.taelement+'" style="margin-top:10px">'+this.taselects+'</select></div>'
		 html2 += '</div>'	
	     html2 += '</div>'	
		 html2 += '<div id="elabel" class="row hide">'
		 html2 += '<div class="col-sm-6">'
		 html2 += '<div class="tool"><strong>Evaluated on</strong></div>'		 
		 html2 += '</div>'	
		 html2 += '<div class="col-sm-6">'
		 html2 += '<div id="elabelmode" class="" style="margin-top: 11px;">Interaction</div>'		 		   			
		 html2 += '</div>'	
		 html2 += '</div>'	
		 
		 var html3 = '<div class="row" style="margin-left: 20px;">'
		 html3 += '<div class="col-sm-6">'
		 html3 += '<button class="fake-radio" id="bprecise" onclick="Precise(true);"> <div class="radio-off"><div id="bprecisero" class="radio-on hide"></div></div>Precise</button><br>'
		 html3 += '<div id="precisetools" class="hide">'
		 html3 += '<div class="tool">Slope</div>'
		 html3 += '<div class="tool">Origin Point</div>'
		 html3 += '<div class="tool">End Point</div>'
		 html3 += '</div>'
		 html3 += '<div id="relativetools" class="hide">'
		 html3 += '<div class="tool">Relative to:</div>'
		 html3 += '<div id="relativetools2" class="hide">'
		 html3 += '<div class="tool">Shift from origin</div>'
		 html3 += '</div>'
		 html3 += '<div id="drawarea" class="hide" style="width: 200px; margin-top: 10px; margin-left: 10px; position:relative; top: 10px;"><button type="button" onclick="DoAcceptedArea(gmloc-1)" class="btn btn-econ-sw5"><span class="glyphicon glyphicon-pentagon" aria-hidden="true"></span><img id="areashade" src="./images/areashade.png"></img></button><span style="padding-left: 5px;">Draw Accepted Area</span></div>'	
		 html3 += '</div>'	
		 html3 += '</div>'	
		 html3 += '<div class="col-sm-6">'
		 html3 += '<button class="fake-radio" id="brelative" onclick="Precise(false);"> <div class="radio-off"><div id="brelativero" class="radio-on"></div></div>Relative<br></button>'
		 html3 += '<div id="preciseinputs" class="hide" style="position:relative; top: 10px">'
		 html3 += '<div><input id="slopec" type="number" step="0.01" class="slope-input" placeholder="'+this.m+'" value="'+this.m+'" oninput="slopeUpdate(this.value)"></div>'	  			
		 html3 += '<div>(<input id="xspointc" type="number" class="point-input" value="'+this.xsg+'" step="'+graphSe.xmax/Number(graphSe.wdPx)+'" oninput="xsUpdate(this.value)">,<input id="yspointc" type="number" class="point-input" value="'+this.ysg+'" step="'+graphSe.ymax/Number(graphSe.htPx)+'" oninput="ysUpdate(this.value)" >)</div>'	  			
		 html3 += '<div>(<input id="xepointc" type="number" class="point-input" value="'+this.xeg+'" step="'+graphSe.xmax/Number(graphSe.wdPx)+'" oninput="xeUpdate(this.value)" >,<input id="yepointc" type="number" class="point-input" value="'+this.yeg+'" step="'+graphSe.ymax/Number(graphSe.htPx)+'" oninput="yeUpdate(this.value)" >)</div>'	  			
		 html3 += '</div>'	
		 html3 += '<div id="relativeinputs" class="hide">'
		 html3 += '<div class="styled-select" style="margin-top:9px"><select id="reldropdown" class="select-class" onchange="GetRelativeElement(this.value)"></span>'+this.relselects+'</select></div>'
		 html3 += '<div id="relativeinputs2" class="hide">'
		 html3 += '<button class="fake-radio" id="sleft" onclick="ShiftLeft();" style="margin-top:13px;"> <div class="radio-off"><div id="sleftro" class="radio-on hide"></div></div>Left</button><br>'
		 html3 += '<button class="fake-radio" id="sright" onclick="ShiftRight();" style="margin-top:0px;"> <div class="radio-off"><div id="srightro" class="radio-on hide"></div></div>Right</button><br>'
		 html3 += '</div>'	
		 html3 += '</div>'	
		 html3 += '</div>'	
		 html3 += '</div>'	

		 var html4 = '<div class="row" style="margin-left: 20px;">'
		 html4 += '<div class="col-sm-6">'
		 html4 += '<div class="tool" style="margin-top: 0px;">Required label</div>'
		 html4 += '<div id="requiredlabeltools" class="hide">'
		 html4 += '<div class="tool">Label Choices</div>'
		 html4 += '<div id="cltext2" class="tool" style="padding-top: '+this.clabeloffset+'">Correct Label</div>'
		 html4 += '</div>'	
		 html4 += '</div>'	
		 html4 += '<div class="col-sm-6">'
		 html4 += '<div id="rtoggleshell" style="margin-top:10px;"><label class="switch tool"><input id="rltoggle" type="checkbox" onclick="update();"><div class="slider"><span class="ontext">ON</span><span class="offtext">OFF</span></div></label></div>'
		 html4 += '<div id="requiredlabelinputs" class="hide">'
		 html4 += '<form id="checkform" onclick="checkBoxes();">'+this.checkboxhtml+'</form>'
		 html4 += '<div><input id="newlabel" type="text" class="" placeholder="Custom label" onkeyup="" style="width: 100px; margin-top: 10px;"><button class="btn-nothing" onclick="addLabel()"> <span class="glyphicon glyphicon-cplus"></span></button></div>'
		 html4 += '<div class="styled-select" style="margin-top: 10px"><select id="cldropdown" class="select-class" onchange="GetCorrectLabel(this.value)"></span>'+this.clselects+'</select></div>'
		 html4 += '</div>'	
		 html4 += '</div>'	
		 html4 += '</div>'	

		 var html5 = '<div class="row" style="margin-left: 20px;">'
		 html5 += '<div class="col-sm-6">'
		 html5 += '<div class="tool">Element Type</div>'
		 html5 += '<div class="tool">Slope</div>'
		 html5 += '<div class="tool">Origin Point</div>'
		 html5 += '<div class="tool">End Point</div>'
		 html5 += '</div>'
		 html5 += '<div class="col-sm-6" style="padding-top: 8px;">'
		 html5 += '<div class="styled-select"><select id="eldropdown" class="select-class" onchange="GetElement(this.value)"></span><option value="None">None</option><option value="Demand">Demand</option><option value="Fixed Cost">Fixed Cost</option><option value="Indifference">Indifference</option><option value="Marginal Cost">Marginal Cost</option><option value="Marginal Revenue">Marginal Revenue</option><option value="PPF">PPF</option><option value="Supply">Supply</option><option value="Total Cost">Total Cost</option><option value="Variable Cost">Variable Cost</option></select></div>'
		 html5 += '<div style="margin-top:12px;"><input id="slope" type="number" step="0.01" class="slope-input" placeholder="'+this.m+'" value="'+this.m+'" oninput="slopeUpdate(this.value)"></div>'	  			
		 html5 += '<div>(<input id="xspointd" type="number" class="point-input" value="'+this.xsg+'" step="'+graphSe.xmax/Number(graphSe.wdPx)+'" oninput="xsUpdate(this.value)">,<input id="yspointd" type="number" class="point-input" value="'+this.ysg+'" step="'+graphSe.ymax/Number(graphSe.htPx)+'" oninput="ysUpdate(this.value)" >)</div>'	  			
		 html5 += '<div>(<input id="xepointd" type="number" class="point-input" value="'+this.xeg+'" step="'+graphSe.xmax/Number(graphSe.wdPx)+'" oninput="xeUpdate(this.value)" >,<input id="yepointd" type="number" class="point-input" value="'+this.yeg+'" step="'+graphSe.ymax/Number(graphSe.htPx)+'" oninput="yeUpdate(this.value)" >)</div>'	  			
		 html5 += '</div>'	  			
		 html5 += '</div>'	  			
		 		 
		 document.getElementById("bottomtools").innerHTML = html;		
		 document.getElementById("interactive").innerHTML = html2;		
		 document.getElementById("interactivetools").innerHTML = html3;		
		 document.getElementById("labeldetails").innerHTML = html4;		
		 document.getElementById("drawingtools").innerHTML = html5;		
		
		 document.getElementById('eldropdown').value = this.elementlabel;
		 document.getElementById('plumbtoggle').checked = this.plumbLine;
		 document.getElementById('rltoggle').checked = this.requiredlabel;

		 document.getElementById('tadropdown').value = this.taelement;
		 document.getElementById('reldropdown').value = this.relementlabel;
		 document.getElementById('cldropdown').value = this.correctlabel;
		 
		 this.InteractiveMe( this.interactive );
		 this.PreciseMe( this.precise );
		 this.EvalShift( this.evalshift );
		 
		 this.SetElementPoints( );
		 
		 this.DisplayBookColor();
		 
		 this.HighLight();

		 this.InteractiveReset();

		 this.CheckRLabel();
		 
		 this.CorrectTools();
  		
  		 this.checkBoxes();
  
 		 $('#emptydesigner').addClass("hide");		

		 if(this.labelLine==true) 
		 {
		 	document.getElementById("labeltoggle").checked = true;	
		 } else
		 {	
		 	document.getElementById("labeltoggle").checked = false;	
		 }
		 
		 if(graphSe.mode=="student")
		 {
			 $('#bottomtools').addClass("hide");		
			 $('#interactive').addClass("hide");		
			 $('#interactivetools').addClass("hide");		
			 $('#labeldetails').addClass("hide");		
			 $('#drawingtools').addClass("hide");			 
		 }

     } 
     
     this.addLabel = function()
     {
     	this.customlabels.push(document.getElementById('newlabel').value)
     	
     	var str = document.getElementById('newlabel').value;
		var lwr = str.toLowerCase();
		str = lwr.replace(/\s+/g, '');
     	
     	this.checkBoxHTML();
     	
     	document.getElementById('checkform').innerHTML = this.checkboxhtml;
     	
		this.CorrectLabelDropdown();

		var fstr = document.getElementById("cltext2").style.paddingTop;
		var fstr2 = fstr.split("px");
		fstr = fstr2[0];
		fstr = Number(fstr)+20;
		document.getElementById("cltext2").style.paddingTop = fstr+"px";
		this.clabeloffset = fstr+"px";	
     }	
     
     this.CorrectTools = function()
     {
     	if(graphSe.mode=='correct')
     	{
 			if(this.interactive!=false)$('#labeldetails').removeClass("hide");
 			$('#designertools').addClass("hide");
			$('#designerinputs').addClass("hide");      	
			$('#elabel').removeClass("hide");      	
			$('#elabelmode').removeClass("hide");      	
			$('#intleft').addClass("hide");      	
			$('#intright').addClass("hide");      	
		 	document.getElementById("elementhead").innerHTML = "Evaluation Settings";		
			document.getElementById("interactive").style.background = "#fbfbfb";
			document.getElementById("interactive").style.marginTop = "0px";
 			$('#sectionpadding').addClass("hide");

			if( this.interactive )
			{
		 		document.getElementById("elabelmode").innerHTML = "Interactive";
		 		this.elabelmode = "Interactive";		
				$('#interactivetools').removeClass("hide");      	
			} else {
		 		document.getElementById("elabelmode").innerHTML = "Static";		
		 		this.elabelmode = "Static";				 		
				$('#interactivetools').addClass("hide");      	
			}	
			
			if(this.mode=="correct")
			{
		 		document.getElementById("elabelmode").innerHTML = "Drawing";
		 		this.elabelmode = "Drawing";				
				$('#interactivetools').addClass("hide");   				
				$('#drawingtools').removeClass("hide");   				
 				$('#labeldetails').removeClass("hide");
			}     
			if(document.getElementById('rltoggle').checked)
			{
				$('#requiredlabeltools').removeClass("hide");   				
 				$('#requiredlabelinputs').removeClass("hide");	
 		 		document.getElementById('cldropdown').value = this.correctlabel;				
			} else 
			{
				$('#requiredlabeltools').addClass("hide");   				
 				$('#requiredlabelinputs').addClass("hide");					
			}
			if(this.elabelmode=="Drawing")
			{
				$('#drawingtools').removeClass("hide");   							
			} else
			{
				$('#drawingtools').addClass("hide");   				
			}

     	} else if(graphSe.mode=='student')
     	{
 				$('#interactive').addClass("hide");   				
				$('#bottomtools').addClass("hide");
 				$('#interactivetools').addClass("hide");   				
				$('#requiredlabeltools').addClass("hide");   				
 				$('#requiredlabelinputs').addClass("hide");					   				
    		
     	} else 
     	{
 			$('#labeldetails').addClass("hide");
			$('#designertools').removeClass("hide");
			$('#designerinputs').removeClass("hide");     	
			//$('#elabel').addClass("hide");      	
			$('#elabelmode').addClass("hide");      
 			$('#intleft').removeClass("hide");      	
			$('#intright').removeClass("hide");  
 		 	document.getElementById("elementhead").innerHTML = "Element Settings";		
			document.getElementById("interactive").style.background = "#f6f6f6";
			document.getElementById("interactive").style.marginTop = "0px";
  			$('#sectionpadding').removeClass("hide");
			$('#interactivetools').addClass("hide");      	
				$('#requiredlabeltools').addClass("hide");   				
 				$('#requiredlabelinputs').addClass("hide");	
    	}
     }
     
     this.InteractiveReset = function ()
     {
			if( this.interactive )
			{
				$('#ilabels').removeClass("hide");
				$('#iinputs').removeClass("hide");
			} else {
				$('#ilabels').addClass("hide");
				$('#iinputs').addClass("hide");
			}	     
     }
     
     this.TrackAgainstDropdown = function ()
     {
     		var html = '<option value="None">None</option>'
     		for( i=0; i < graphMe.length; i++ ) 
     		{
     			if( graphMe[i].label != this.label )
     			{
					var graphlabel = graphMe[i].label;
					html += '<option value="'+graphlabel+'">'+graphlabel+'</option>'
				}	
     		}
     		
     		this.taselects = html;
     }

     this.RelativeDropdown = function ()
     {
     		var html = '<option value="None">None</option>'
     		html += '<option value="Accepted Area">Accepted Area</option>'
     		for(i=0; i<graphMe.length; i++) 
     		{
					var graphlabel = graphMe[i].label;
					html += '<option value="'+graphlabel+'">'+graphlabel+'</option>'
     		}
     		
     		this.relselects = html;
     }     

     this.CorrectLabelDropdown = function ()
     {
     		var html = '<option value="None">None</option>'

			if(document.getElementById('demand').checked) {html += '<option value="Demand">Demand</option>'} else {};
			if(document.getElementById('fixedcost').checked) {html += '<option value="Fixed Cost">Fixed Cost</option>'} else {};
			if(document.getElementById('indifference').checked) {html += '<option value="Indifference">Indifference</option>'} else {};
			if(document.getElementById('marginalcost').checked) {html += '<option value="Marginal Cost">Marginal Cost</option>'} else {};
			if(document.getElementById('marginalrevenue').checked) {html += '<option value="Marginal Revenue">Marginal Revenue</option>'} else {};
			if(document.getElementById('ppf').checked) {html += '<option value="PPF">PPF</option>'} else {};
			if(document.getElementById('supply').checked) {html += '<option value="Supply">Supply</option>'} else {};
			if(document.getElementById('totalcost').checked) {html += '<option value="Total Cost">Total Cost</option>'} else {};
			if(document.getElementById('variablecost').checked) {html += '<option value="Variable Cost">Variable Cost</option>'} else {};

			for(var i=0; i<this.customlabels.length; i++)
			{
				var str = this.customlabels[i];
				var lwr = str.toLowerCase();
				str = lwr.replace(/\s+/g, '');
			
				if(document.getElementById(str)) {
					if(document.getElementById(str).checked) {html += '<option value="'+this.customlabels[i]+'">'+this.customlabels[i]+'</option>'} else {}
				}
				//this.checkboxes[i+9] = false;
			}
       		
     		this.clselects = html;

     	    document.getElementById("cldropdown").innerHTML = html;		
		 	document.getElementById('cldropdown').value = this.correctlabel;

     }     
     

     
     this.SetElementPoints = function( )
     {
         if(graphSe.mode=="designer" && document.getElementById('xspoint') != null)
         {
			 document.getElementById('xspoint').value = graphSe.snapIt ? this.sxsg : this.xsg;
			 document.getElementById('yspoint').value = graphSe.snapIt ? this.sysg : this.ysg;
			 document.getElementById('xepoint').value = graphSe.snapIt ? this.sxeg : this.xeg;
			 document.getElementById('yepoint').value = graphSe.snapIt ? this.syeg : this.yeg;

		     this.CalculateSlope( );
		     this.UpdateSlope( );
		 }

         if(graphSe.mode=="correct" && document.getElementById('xspointd') != null)
         {
			 document.getElementById('xspointd').value = graphSe.snapIt ? this.sxsg : this.xsg;
			 document.getElementById('yspointd').value = graphSe.snapIt ? this.sysg : this.ysg;
			 document.getElementById('xepointd').value = graphSe.snapIt ? this.sxeg : this.xeg;
			 document.getElementById('yepointd').value = graphSe.snapIt ? this.syeg : this.yeg;
		 }
     }

     this.SetElementLabel = function(text)
     {
     	 this.elementlabel = text;

		 this.SetColor();     	 
     }
	
     this.SetRelativeElementLabel = function(text)
     {
     	 this.relementlabel = text;
     	 
     	 this.CheckRLabel();
     }
	
	 this.CheckRLabel = function()
	 {
	     if(this.relementlabel=="Accepted Area")
     	 {
   			$('#relativetools2').addClass("hide");     	 	
			$('#relativeinputs2').addClass("hide");      	 
   			$('#drawarea').removeClass("hide");     	 	
    	 } else if (this.relementlabel=="None")
     	 {
  			$('#relativetools2').addClass("hide");     	 	
			$('#relativeinputs2').addClass("hide");     	 
    		$('#drawarea').addClass("hide");     	 	
    	 } else
     	 {
			$('#relativetools2').removeClass("hide");     	 	
			$('#relativeinputs2').removeClass("hide");     	 	
   			$('#drawarea').addClass("hide");     	 	
     	 }
	 }
	 
	 this.SetBookColor = function(text)
	 {
	 	this.bookcolor = text;	 	

		this.SetColor();
	 }

	 this.GetBookColor = function(text)
	 {
	 	return this.bookcolor;	
	 }	 	 

	 this.DisplayBookColor = function()
	 {
	 	if(this.bookcolor=="Yes")
	 	{
			document.getElementById('bcbutton').innerHTML = 'Use Book Color <span class="glyphicon glyphicon-checkedmm"></span>';
	 	} else 
	 	{
	 		document.getElementById('bcbutton').innerHTML = 'Use Book Color <span class="glyphicon glyphicon-uncheckedmm"></span>';
	 	}
	 }

	 this.HighLight = function()
	 {
	 	for(i=0; i<graphMe.length; i++)
	 	{
	 		graphMe[i].iscurrent=false	
	 	}	
	 	
	 	this.iscurrent=true
	 }

     this.LabelLine = function(  )
     {

		pt = graphSe.snapIt ? { x: this.sxeg, y: this.syeg } : { x: this.xeg, y: this.yeg };
		spt = graphSe.snapIt ? { x: this.sxsg, y: this.sysg } : { x: this.xsg, y: this.ysg };
		
		var xoffset = 0;
		var yoffset = 0;

		pt.x = graphSe.ConvertXgToXpx(pt.x)+xoffset;
		pt.y = graphSe.ConvertYgToYpx(pt.y)+yoffset;
		spt.x = graphSe.ConvertXgToXpx(spt.x)+xoffset;
		spt.y = graphSe.ConvertYgToYpx(spt.y)+yoffset;
		
		var d = 20;
		
		var mag = Math.sqrt(Math.pow((pt.x - spt.x),2) + Math.pow((pt.y - spt.y),2))
		var newx = pt.x + d * (pt.x - spt.x) / mag
		var newy = pt.y + d * (pt.y - spt.y) / mag

        var clr = this.iscurrent == true ? this.cc: this.ccus;

		//console.log(clr);
		/*ctx2.fillStyle = clr;
		ctx2.font="14px sans-serif";
		ctx2.fillText(this.label,newx,newy);
		ctx2.font="10px sans-serif";*/

		var templabel;
		if(graphSe.mode=="correct"&&this.dragstart!=undefined)
		{
			templabel = this.labelam;
		} else
		{
			templabel = this.label;
		}
			
		if(graphSe.mode=="designer")
		{
			templabel = this.label;
		}	

		if(graphSe.mode=="student"&&this.studentdrag!=null)
		{
			templabel = this.labelam;
		}				

		var text = new paper.PointText(new paper.Point(newx, newy));
		text.justification = 'center';
		text.fillColor = clr;
		text.content = templabel;
		
	}  
	 
	 this.UpdateLabelText = function()
	 {
		document.getElementById('xlabel'+this.labelvalue).value = this.label;	 	
		document.getElementById('toplabel'+this.labelvalue).innerHTML = this.label;	 	
	 } 
	 
	 this.InteractiveMe = function( tf )
     {
        this.interactive = tf;
        if( tf ) { $("#binteractivero").removeClass("hide"); $("#bstaticro").addClass("hide"); }
        else { $("#binteractivero").addClass("hide"); $("#bstaticro").removeClass("hide"); }
     }

	 this.EvalShift = function( text )
     {
        this.evalshift = text;
        if( this.evalshift=="left" ) { $("#sleftro").removeClass("hide"); $("#srightro").addClass("hide");}
        else if (this.evalshift==null) {$("#sleftro").addClass("hide"); $("#srightro").addClass("hide");}
        else 
        {  
        	$("#sleftro").addClass("hide"); $("#srightro").removeClass("hide"); 
        	//$('#relativetools').removeClass("hide");
			//$('#relativeinputs').removeClass("hide");
        }
        
        if(  text != null ) this.CorrectMe( ["relative",text] );
     }    
    
	 this.PreciseMe = function( tf )
     {
        //this.evalshift = null;
        this.precise = tf;
        if( tf ) 
        { 
        	$("#bprecisero").removeClass("hide"); $("#brelativero").addClass("hide");
        	$('#relativetools').addClass("hide");
			$('#relativeinputs').addClass("hide");   
        	$('#precisetools').removeClass("hide");
			$('#preciseinputs').removeClass("hide");   			  			    
        }
        else if (tf==null) {$("#bprecisero").addClass("hide"); $("#brelativero").addClass("hide");}
        else 
        {  
        	$("#bprecisero").addClass("hide"); $("#brelativero").removeClass("hide"); 
        	$('#relativetools').removeClass("hide");
			$('#relativeinputs').removeClass("hide");
        	$('#precisetools').addClass("hide");
			$('#preciseinputs').addClass("hide");   
		}
		
     }    
	 
	 this.CalculateSlope = function()
	 {
	     var xspx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxsg : this.xsg );
         var yspx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.sysg : this.ysg );
         var xepx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxeg : this.xeg );
         var yepx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syeg : this.yeg );
         
         var dx = xepx-xspx;
	 	 var slope = Math.abs(dx) > .000001 ? -(yepx-yspx)/dx : Number.POSITIVE_INFINITY;
	 	
	 	 //this.m = Math.round(slope * 100) / 100;
	 	 if( slope != undefined ) this.m = slope.toFixed(2);
	 	 else this.m = slope;
	 }

	 this.LineUpdate = function()
	 {
	    var xspx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxsg : this.xsg );
        var yspx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.sysg : this.ysg );
        var xepx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxeg : this.xeg );
        var yepx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syeg : this.yeg );
            
        var dx = this.xeg-this.xsg;
        var dy = this.yeg-this.ysg;
            
		this.distance = Math.sqrt(dx*dx + dy*dy);
			
		var ang = Math.atan(this.m)
		
	 	if(this.xeg > this.xsg)
		{
		    this.xeg = (this.distance)*Math.cos(ang) + this.xsg;
			this.yeg = (this.distance)*Math.sin(ang) + this.ysg
		}	

	 	if(this.xeg < this.xsg)
		{
		    this.xsg = (this.distance)*Math.cos(Math.atan(this.m)) + this.xeg;
			this.ysg = (this.distance)*Math.sin(Math.atan(this.m)) + this.yeg
		}
		
		this.SetElementPoints( );	
		
	 }

	 this.UpdateSlope = function()
	 {
		 document.getElementById('slope').value = Number(this.m);	 			 	
	 }

     this.RequiredLabelMe = function( tf )
     {
         this.requiredlabel = tf;
         
         if(this.requiredlabel)
         {
 			$('#requiredlabelinputs').removeClass("hide");     	 	
			$('#requiredlabeltools').removeClass("hide");     	 	        
         } else {
 			$('#requiredlabelinputs').addClass("hide");     	 	
			$('#requiredlabeltools').addClass("hide");  
		}	           
     }

     this.LabelMeDrop = function( )
     {
		console.log("label me drop");

		/*console.log("label me drop");
        var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxg : this.xg );
        var ypx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syg : this.yg );
         
        var xspx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxsg : this.xsg );
        var yspx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.sysg : this.ysg );
        var xepx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxeg : this.xeg );
        var yepx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syeg : this.yeg );*/

		pt = graphSe.snapIt ? { x: this.sxeg, y: this.syeg } : { x: this.xeg, y: this.yeg };
		spt = graphSe.snapIt ? { x: this.sxsg, y: this.sysg } : { x: this.xsg, y: this.ysg };
		
		var xoffset = 0;
		var yoffset = 0;

		pt.x = graphSe.ConvertXgToXpx(pt.x)+xoffset;
		pt.y = graphSe.ConvertYgToYpx(pt.y)+yoffset;
		spt.x = graphSe.ConvertXgToXpx(spt.x)+xoffset;
		spt.y = graphSe.ConvertYgToYpx(spt.y)+yoffset;
		
		var d = 20;
		
		var mag = Math.sqrt(Math.pow((pt.x - spt.x),2) + Math.pow((pt.y - spt.y),2))
		var newx = pt.x + d * (pt.x - spt.x) / mag
		var newy = pt.y + d * (pt.y - spt.y) / mag        

		var div = document.createElement("div");
		div.id = 'dlabel';
		div.style.position = "absolute";
		div.style.left = newx+37+'px';
		div.style.top = newy+179+'px';
		div.style.zIndex = "10000";
		div.className = 'styled-select';
			
		div.innerHTML = '<select id="elabel" class="select-class" onchange="GetCorrectStudentLabel(this.value)"></span>'+this.clselects+'</select>'
		document.getElementById('graphcontainer').appendChild(div);	

		//$('#elabel').removeClass("hide");
		
	}   

     this.SetCorrectLabel = function(text)
     {
     	 this.correctlabel = text;
     }

    this.SetCorrectStudentLabel = function(text)
     {
     	 this.studentcorrectlabel = text;
     	 
     	 this.CheckIsCorrect("label");	   	 
     }
 
    this.SetCorrectPoints = function( )
     {         
         if(this.precise)
         {
			 this.correctxs = graphSe.snapIt ? this.sxsg : this.xsg;
			 this.correctys = graphSe.snapIt ? this.sysg : this.ysg;
			 this.correctxe = graphSe.snapIt ? this.sxeg : this.xeg;
			 this.correctye = graphSe.snapIt ? this.syeg : this.yeg;
	 
			 this.CalculateOSlope( );
			 this.UpdateOSlope( );
		 
			 document.getElementById('xspointc').value = this.correctxs;
			 document.getElementById('yspointc').value = this.correctys;
			 document.getElementById('xepointc').value = this.correctxe;
			 document.getElementById('yepointc').value = this.correctye;			 
		 } 	 
     }     

	 this.CalculateOSlope = function()
	 {
	     var xspx = this.correctxs;
         var yspx = this.correctys;
         var xepx = this.correctxe;
         var yepx = this.correctye;
         
         var dx = xepx-xspx;
	 	 var slope = Math.abs(dx) > .000001 ? -(yepx-yspx)/dx : Number.POSITIVE_INFINITY;
	 	
	 	 //this.m = Math.round(slope * 100) / 100;
	 	 if( slope != undefined ) this.mo = slope.toFixed(2);
	 	 else this.mo = slope;
	 }

	 this.UpdateOSlope = function()
	 {
		 document.getElementById('slopec').value = Number(this.mo);	 			 	
	 }

     
     this.SetSettings();

     
}

function Curve( clr, szz, showPts )
{
    this.what = 'curve';
    this.color = clr;
    this.width = szz;
    this.pts = [ ];
    this.spts = [ ];
    this.tension = 0.5;
    this.segments = 128;
    this.showPoints = showPts;
    this.ptSpacing = 8;
    this.selectingPts = false;
    this.swipingPts = false;
    this.clickingPts = false;
    this.plumbLine = false;
    
    this.relementlabel="None";
    this.elementlabel="None";
    this.bookcolor="No";
    this.iscurrent=true;
    cpoints++;
    this.label = "C"+cpoints;
    this.labelvalue = cpoints;

	this.studentdrag = null;

    this.studentcorrectlabel = "a";
     
    this.iscorrect = null;
    this.correctgraph;
    this.labelcorrect;
	this.correctlabel = "b";

	this.ang = null;
    
    this.plumbLine = false;
    this.labelLine = false;
    
    this.ghost = null;
    
    this.correct = [ ];
	this.correctTolerance = 4;
	this.correctFeedback = "Curve Correct!";
	this.notCorrectFeedback = "Curve Not Correct!";
	this.feedback = "";
    
    this.dragState = "off";
    this.dragStart = null;
    this.dragDxDy = { dx: 0, dy: 0 };

	this.interactive = graphSe.mode=="correct" ? true : false;
	this.precise = null;
	this.evalshift = null;
	this.labelam = '';
	this.taelement = 'None';
    this.relselects = '';
    this.clselects = '';
     
    this.showControl = false;
    
    this.mode = graphSe.mode;

	this.cc = 'rgba(0, 0, 0, 1)'
	this.ccus = 'rgba(0, 0, 0, .5)'

	 this.checkboxes = [true, true, true, true, true, true, true, true, true];
	 this.customlabels = [];

	 this.clabeloffset = "202px";
	 this.elabelmode = "";

	this.SetColor = function ( )
	{
	 	if(this.elementlabel=="None") {this.cc = 'rgba(0, 0, 0, 1)'; this.ccus = 'rgba(0, 0, 0, .5)';}
	 	else if(this.elementlabel=="PPF" && this.bookcolor=="Yes") {this.cc = 'rgba(170, 95, 166, 1)'; this.ccus = 'rgba(170, 95, 166, .5)';}
	 	else if(this.elementlabel=="Demand" && this.bookcolor=="Yes") {this.cc = 'rgba(0, 131, 173, 1)'; this.ccus = 'rgba(0, 131, 173, .5)';}
	 	else if(this.elementlabel=="Supply" && this.bookcolor=="Yes") {this.cc = 'rgba(219, 92, 28, 1)'; this.ccus = 'rgba(219, 92, 28, .5)';}
	 	else if(this.elementlabel=="Fixed Cost" && this.bookcolor=="Yes") {this.cc = 'rgba(188, 189, 192, 1)'; this.ccus = 'rgba(188, 189, 192, .5)';}
	 	else if(this.elementlabel=="Indifference" && this.bookcolor=="Yes") {this.cc = 'rgba(247, 147, 29, 1)'; this.ccus = 'rgba(247, 147, 29, .5)';}
	 	else if(this.elementlabel=="Marginal Cost" && this.bookcolor=="Yes") {this.cc = 'rgba(247, 147, 29, 1)'; this.ccus = 'rgba(247, 147, 29, .5)';}
	 	else if(this.elementlabel=="Marginal Revenue" && this.bookcolor=="Yes") {this.cc = 'rgba(35, 31, 32, 1)'; this.ccus = 'rgba(35, 31, 32, .5)';}
	 	else if(this.elementlabel=="Total Cost" && this.bookcolor=="Yes") {this.cc = 'rgba(219, 92, 28, 1)'; this.ccus = 'rgba(219, 92, 28, .5)';}
	 	else if(this.elementlabel=="Variable Cost" && this.bookcolor=="Yes") {this.cc = 'rgba(238, 165, 122, 1)'; this.ccus = 'rgba(238, 165, 122, .5)';}
	 	else {this.cc = 'rgba(0, 0, 0, 1)'; this.ccus = 'rgba(0, 0, 0, .5)';}
	}

	this.setStudentColor = function ( )
	{
		if(this.studentcorrectlabel=="None") {this.cc = 'rgba(0, 0, 0, 1)'; this.ccus = 'rgba(0, 0, 0, .5)';}
		else if(this.studentcorrectlabel=="PPF") {this.cc = 'rgba(170, 95, 166, 1)'; this.ccus = 'rgba(170, 95, 166, .5)';}
		else if(this.studentcorrectlabel=="Demand") {this.cc = 'rgba(0, 131, 173, 1)'; this.ccus = 'rgba(0, 131, 173, .5)';}
		else if(this.studentcorrectlabel=="Supply") {this.cc = 'rgba(219, 92, 28, 1)'; this.ccus = 'rgba(219, 92, 28, .5)';}
		else if(this.studentcorrectlabel=="Fixed Cost") {this.cc = 'rgba(188, 189, 192, 1)'; this.ccus = 'rgba(188, 189, 192, .5)';}
		else if(this.studentcorrectlabel=="Indifference") {this.cc = 'rgba(247, 147, 29, 1)'; this.ccus = 'rgba(247, 147, 29, .5)';}
		else if(this.studentcorrectlabel=="Marginal Cost") {this.cc = 'rgba(247, 147, 29, 1)'; this.ccus = 'rgba(247, 147, 29, .5)';}
		else if(this.studentcorrectlabel=="Marginal Revenue") {this.cc = 'rgba(35, 31, 32, 1)'; this.ccus = 'rgba(35, 31, 32, .5)';}
		else if(this.studentcorrectlabel=="Total Cost") {this.cc = 'rgba(219, 92, 28, 1)'; this.ccus = 'rgba(219, 92, 28, .5)';}
		else if(this.studentcorrectlabel=="Variable Cost") {this.cc = 'rgba(238, 165, 122, 1)'; this.ccus = 'rgba(238, 165, 122, .5)';}
		else {this.cc = 'rgba(0, 0, 0, 1)'; this.ccus = 'rgba(0, 0, 0, .5)';}
	}
	     
    this.DrawMe = function( ctx )
    {
        if( graphSe.mode != "correct" && graphSe.mode != "student" && graphSe.mode != this.mode 
             || (this.mode == 'correct' && graphSe.mode == "student") ) return;
             
        if( graphSe.boo && this.ghost && this.mode != "correct" ) this.DrawGhost( );
             
        this.myPath = new paper.Path( );
        this.myPath.strokeColor = clr;
        this.myPath.strokeWidth = this.width;
        clr = this.iscurrent == true ? this.cc: this.ccus;
        
        for( var p = 0, ln = this.pts.length; p < ln; p += 2 )
        {
            var xpt = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.spts[p] : this.pts[p] );
            var ypt = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.spts[p+1] : this.pts[p+1] );
            this.myPath.add( new paper.Point(xpt, ypt) );
        }
        
        if( this.myPath.segments.length >= 2)
        {  
            this.myPath.segments[0].handleIn = [0,0];
            this.myPath.segments[0].handleOut = [0,0];
            
            //this.myPath.segments[1].handleIn = [-30,0]; 
            //this.myPath.segments[1].handleOut = [30,0]; 
	    }
	
	    if( this.myPath.segments.length >= 3)
        {  
	        var dx = this.myPath.segments[2].point.x - this.myPath.segments[0].point.x;
	        var dy = this.myPath.segments[2].point.y - this.myPath.segments[0].point.y;
			
	        var sf = 4;

            this.myPath.segments[1].handleIn = [-dx/sf,-dy/sf]; 
            this.myPath.segments[1].handleOut = [dx/sf,dy/sf];      

            this.myPath.segments[2].handleIn = [0,0];
            this.myPath.segments[2].handleOut = [0,0];
        }
        
        if( this.plumbLine ) this.PlumbLine( );
         
        if( this.iscurrent ) this.ControlPoints( );

        if( this.labelLine ) this.LabelLine( );
        
        //this.myPath.smooth();    
        //this.myPath.simplify(1.0);
    }
    
    this.TrackAlong = function( lbl )
    {
         if( lbl != undefined ) this.trackAlongLabel = lbl;
     
         this.trackElement = graphSe.FindInGraph( this.trackAlongLabel );
         
         if( this.trackElement != null )
         {
             var t = this.trackElement;
             this.trackAng = Math.atan2(t.yeg - t.ysg, t.xeg - t.xsg);
             
             //console.log("TrackAlong: ", this.trackAng*R2D, t.yeg - t.ysg, t.xeg - t.xsg );
         }
     }
     
     this.Track = function( dist )
     {  
         var ang = this.trackAng;
         var dx = Math.cos(ang)*dist;
         var dy = Math.sin(ang)*dist;
         
         //console.log("Track: ", ang*R2D, dx, dy);
         
         return { sx: dx, sy: dy };
     }
    
    this.CorrectToDesigner = function( )
    {
         if( this.ghost )
         {
             var gh = this.ghost;
             for( var i = 0, ln = gh.pts.length; i < ln; i++ )
             {
                 this.pts[i] = gh.pts[i];
                 this.spts[i] = gh.spts[i];
             }
         }
     }
     
     this.DesignerToCorrect = function( )
     {
         if( this.correct.length > 0 )
         {
             var cr = this.correct[0];
             for( var i = 0, ln = cr.pts.length; i < ln; i++ )
             {
                 this.pts[i] = cr.pts[i];
                 this.spts[i] = cr.spts[i];
             }
         } 
     }
    
     this.DrawGhost = function( )
     {
        var gh = this.ghost;
        var ghPath = new paper.Path( );
        ghPath.strokeColor = gh.clr;
        ghPath.strokeWidth = this.width;
        ghPath.dashArray = [ 2, 2];
        clr = this.iscurrent == true ? this.cc: this.ccus;
        
        for( var p = 0, ln = gh.pts.length; p < ln; p += 2 )
        {
            var xpt = graphSe.ConvertXgToXpx( graphSe.snapIt ? gh.spts[p] : gh.pts[p] );
            var ypt = graphSe.ConvertYgToYpx( graphSe.snapIt ? gh.spts[p+1] : gh.pts[p+1] );
                ghPath.add( new paper.Point(xpt, ypt) );
        }
        
        ghPath.segments[0].handleIn = [0,0];
        ghPath.segments[0].handleOut = [0,0];
        
        var dx = ghPath.segments[2].point.x - ghPath.segments[0].point.x;
	    var dy = ghPath.segments[2].point.y - ghPath.segments[0].point.y;
			
	    var sf = 4;

        ghPath.segments[1].handleIn = [-dx/sf,-dy/sf]; 
        ghPath.segments[1].handleOut = [dx/sf,dy/sf];      

        ghPath.segments[2].handleIn = [0,0];
        ghPath.segments[2].handleOut = [0,0];
 
        var spt = graphSe.snapIt ? { x: this.ghost.spts[2], y: this.ghost.spts[3] } : { x: this.ghost.pts[2], y: this.ghost.pts[3] };
        var pt = graphSe.snapIt ? { x: this.ghost.spts[4], y: this.ghost.spts[5] } : { x: this.ghost.pts[4], y: this.ghost.pts[5] };
		
		var xoffset = 0;
		var yoffset = 0;

		pt.x = graphSe.ConvertXgToXpx(pt.x)+xoffset;
		pt.y = graphSe.ConvertYgToYpx(pt.y)+yoffset;
		spt.x = graphSe.ConvertXgToXpx(spt.x)+xoffset;
		spt.y = graphSe.ConvertYgToYpx(spt.y)+yoffset;
		
		var d = 20;
		
		var mag = Math.sqrt(Math.pow((pt.x - spt.x),2) + Math.pow((pt.y - spt.y),2))
		var newx = pt.x + d * (pt.x - spt.x) / mag
		var newy = pt.y + d * (pt.y - spt.y) / mag
		
		if(this.labelLine==true)
		{
			text = new paper.PointText(new paper.Point(newx, newy));
			text.justification = 'center';
			text.fillColor = this.ccus;
			text.content = this.label;
		}	
 
    }
    
    this.AddPoint = function( pt )
    {
        //var ln = this.pts.length;
        //var dx = this.pts[ln-2] - pt.x;
        //var dy = this.pts[ln-1] - pt.y;
        //if( (dx*dx + dy*dy) < 28 ) return;
        
        var ptxg = graphSe.ConvertXpxToXg(pt.x);
        var ptyg = graphSe.ConvertYpxToYg(pt.y)
        this.pts.push( ptxg );
        this.pts.push( ptyg );
        
        this.spts.push( graphSe.SnapX( ptxg) );
        this.spts.push( graphSe.SnapY( ptyg) );
        
        this.SetElementPoints( );
    }
    
    this.MidPoint = function( )
    {
        var mx, my, dst;
        var ax = graphSe.ConvertXgToXpx( this.pts[0] );
        var ay = graphSe.ConvertYgToYpx( this.pts[1] );
        
        var ib = this.pts.length - 2;
        var bx = graphSe.ConvertXgToXpx( this.pts[ib] );
        var by = graphSe.ConvertYgToYpx( this.pts[ib+1] );
        
        var a = new paper.Point( ax, ay );
        var b = new paper.Point( bx, by );
        
        var ab = b.subtract(a);
        
        for( var i = 2, mxdst = 0, ln = this.pts.length-2; i < ln; i +=2 )
        {
            var cx = graphSe.ConvertXgToXpx( this.pts[i] );
            var cy = graphSe.ConvertYgToYpx( this.pts[i+1] );
            var c = new paper.Point( cx, cy );
            var ac = c.subtract(a);
            
            var dst = Math.abs(ac.cross(ab))/ab.length;
            if( dst > mxdst ) { mxdst = dst; mx = cx, my = cy }
        }
        
        this.pts[2] = graphSe.ConvertXpxToXg( mx ); 
        this.pts[3] = graphSe.ConvertYpxToYg( my ); 
        this.pts[4] = this.pts[ib]; 
        this.pts[5] = this.pts[ib+1]; 
        this.pts.splice(6,ib);
        this.SnapMe( );
		this.SetSettings();
    }
    
    this.HitMe = function( mpt )
    {  
        var hitCp = false; 
        var mypt = new paper.Path.Circle(new paper.Point(mpt.x, mpt.y), 2);
        
        this.PathMe( );
        
        var gii = this.path.getIntersections( mypt );
        var giiln = gii.length;
        
        if( !giiln )
        {
             var icp = [ 0, 2, 4 ];
             for( var i = 0, ln = icp.length; i < ln && !hitCp; i++ )
             {
                 var k = icp[i];
                 var pxg = graphSe.snapIt ? this.spts[k] : this.pts[k];
                 var pyg = graphSe.snapIt ? this.spts[k+1] : this.pts[k+1];
                 
                 hitCp = graphSe.HitPt(mpt, pxg, pyg, graphSe.handleRadius); 
             }
         }
        
        return giiln || hitCp;
    }
    
    this.MoveMe = function( type, dx, dy )
    {
        if( type == "start" || type == "all" )  { this.pts[0] -= dx; this.pts[1] -= dy; };
        if( type == "middle" || type == "all" ) { this.pts[2] -= dx; this.pts[3] -= dy; };
        if( type == "end" || type == "all" ) { this.pts[4] -= dx; this.pts[5] -= dy; }
	    this.SnapMe( );
    }
    
    this.ControlMe = function( tf )
    {
        this.showControl = tf; 
    }
     
    this.DragMe = function( mpt, drgSt )
    {
        if( drgSt != undefined ) this.dragState = drgSt;
         
        switch( this.dragState )
        {
            case "off":
	            if( graphSe.boo && this.interactive && !this.ghost ) this.GhostMe( ); 
                
                dragObj = this;
                this.dragstart = mpt;
                this.dragDxDy = { dx: 0, dy: 0 };
                var pts = graphSe.snapIt ? { x: this.spts[0], y: this.spts[1] } : { x: this.pts[0], y: this.pts[1] };
                var ptm = graphSe.snapIt ? { x: this.spts[2], y: this.spts[3] } : { x: this.pts[2], y: this.pts[3] };
                var pte = graphSe.snapIt ? { x: this.spts[4], y: this.spts[5] } : { x: this.pts[4], y: this.pts[5] };
                if( graphSe.HitPt(mpt,pts.x,pts.y,graphSe.handleRadius) ) this.dragState = "dragStart";
                else if( graphSe.HitPt(mpt,ptm.x,ptm.y,graphSe.handleRadius) ) this.dragState = "dragMiddle";
                else if( graphSe.HitPt(mpt,pte.x,pte.y,graphSe.handleRadius) ) this.dragState = "dragEnd";
                else this.dragState = "dragCurve";
                if(graphSe.mode=="correct")Precise(true);
                if(graphSe.mode=="student")this.studentdrag=true;
 
 	     		if(graphSe.mode=="correct") this.SetCorrectPoints();
              break;
                 
            case "dragStart":
                var dsxg = graphSe.ConvertXpxToXg( this.dragstart.x ) - graphSe.ConvertXpxToXg( mpt.x );
	            var dsyg = graphSe.ConvertYpxToYg( this.dragstart.y ) - graphSe.ConvertYpxToYg( mpt.y );
	            this.pts[0] -= dsxg;
	            this.pts[1] -= dsyg;
                //this.pts[0] = graphSe.ConvertXpxToXg( mpt.x );
	            //this.pts[1] = graphSe.ConvertYpxToYg( mpt.y );
	            this.SnapMe( );
	            this.SetElementPoints( );

	     		if(graphSe.mode=="correct") this.SetCorrectPoints();
	            this.dragstart = mpt;
	            this.dragDxDy = { dx: this.dragDxDy.dx += dsxg, dy: this.dragDxDy.dy += dsyg };
	            this.dragPt = "start"
	            break;
	             
	        case "dragMiddle":
	            var dsxg = graphSe.ConvertXpxToXg( this.dragstart.x ) - graphSe.ConvertXpxToXg( mpt.x );
	            var dsyg = graphSe.ConvertYpxToYg( this.dragstart.y ) - graphSe.ConvertYpxToYg( mpt.y );
	            this.pts[2] -= dsxg;
	            this.pts[3] -= dsyg;
	            //this.pts[2] = graphSe.ConvertXpxToXg( mpt.x );
	            //this.pts[3] = graphSe.ConvertYpxToYg( mpt.y );
	            this.SnapMe( );
	            this.SetElementPoints( );

	     		if(graphSe.mode=="correct") this.SetCorrectPoints();
	            this.dragstart = mpt;
	            this.dragDxDy = { dx: this.dragDxDy.dx += dsxg, dy: this.dragDxDy.dy += dsyg };
	            this.dragPt = "middle"
	            break;
	             
	        case "dragEnd":
	            var dsxg = graphSe.ConvertXpxToXg( this.dragstart.x ) - graphSe.ConvertXpxToXg( mpt.x );
	            var dsyg = graphSe.ConvertYpxToYg( this.dragstart.y ) - graphSe.ConvertYpxToYg( mpt.y );
	            this.pts[4] -= dsxg;
	            this.pts[5] -= dsyg;
                //this.pts[4] = graphSe.ConvertXpxToXg( mpt.x );
	            //this.pts[5] = graphSe.ConvertYpxToYg( mpt.y );
	            this.SnapMe( );
	            this.SetElementPoints( );

	     		if(graphSe.mode=="correct") this.SetCorrectPoints();
	            this.dragstart = mpt;
	            this.dragDxDy = { dx: this.dragDxDy.dx += dsxg, dy: this.dragDxDy.dy += dsyg };
	            this.dragPt = "end"
	            break;
	             
	        case "dragCurve":
	            
	            //var dsxg = graphSe.ConvertXpxToXg( this.dragstart.x ) - graphSe.ConvertXpxToXg( mpt.x );
	            //var dsyg = graphSe.ConvertYpxToYg( this.dragstart.y ) - graphSe.ConvertYpxToYg( mpt.y );
	            
	             var dsxg = graphSe.ConvertXpxToXg( mpt.x ) - graphSe.ConvertXpxToXg( this.dragstart.x );
	             var dsyg = graphSe.ConvertYpxToYg( mpt.y ) - graphSe.ConvertYpxToYg( this.dragstart.y ); 
	             
	             if( this.taelement != "None" )
	             {
	                 this.TrackAlong( );
	                 var s = this.Track( dsxg );
	                 dsxg = s.sx;
	                 dsyg = s.sy;
	             }
	             
	            this.pts[0] += dsxg;
	            this.pts[1] += dsyg;
	            this.pts[2] += dsxg;
	            this.pts[3] += dsyg;
	            this.pts[4] += dsxg;
	            this.pts[5] += dsyg;
	            this.SnapMe( );
	             
	            this.SetElementPoints( );

	     		if(graphSe.mode=="correct") this.SetCorrectPoints();
	             
	            this.dragstart = mpt;
	            this.dragDxDy = { dx: this.dragDxDy.dx -= dsxg, dy: this.dragDxDy.dy -= dsyg };
	            break;
	             
	        case "drop":
	            dragObj = null;
	            this.dragState = "off";
	            this.dragStart = null;
	            if( this.dragDxDy.dx != 0 || this.dragDxDy.dy != 0 )
	            {
	                 graphSe.OpsMoveElement( this, this.dragPt, -this.dragDxDy.dx, -this.dragDxDy.dy );
	                 if( graphSe.mode == "correct" ) this.CorrectMe( );
	                 if( graphSe.mode == "student" ) this.CheckIsCorrect( );
	                 if( graphSe.mode == "designer" && this.interactive ) this.GhostMe();
	            }
	            break;
        }
    }
    
    this.ControlPoints = function( )
    {
         var pts = graphSe.snapIt ? { x: this.spts[0], y: this.spts[1] } : { x: this.pts[0], y: this.pts[1] };
         var ptm = graphSe.snapIt ? { x: this.spts[2], y: this.spts[3] } : { x: this.pts[2], y: this.pts[3] };
         var pte = graphSe.snapIt ? { x: this.spts[4], y: this.spts[5] } : { x: this.pts[4], y: this.pts[5] };
         var ps = new paper.Path.Circle(new paper.Point(graphSe.ConvertXgToXpx(pts.x), graphSe.ConvertYgToYpx(pts.y)), graphSe.handleRadius);
         ps.strokeColor = graphSe.handleColor;
         ps.strokeWidth = 1;
         
         if( !mouseIsDown || !drawCurveMode || (this.dragState != "off") )
         {
             var pm = new paper.Path.Circle(new paper.Point(graphSe.ConvertXgToXpx(ptm.x), graphSe.ConvertYgToYpx(ptm.y)), graphSe.handleRadius);
             pm.strokeColor = graphSe.handleColor;
             pm.strokeWidth = 1;
         
             var pe = new paper.Path.Circle(new paper.Point(graphSe.ConvertXgToXpx(pte.x), graphSe.ConvertYgToYpx(pte.y)), graphSe.handleRadius);
             pe.strokeColor = graphSe.handleColor;
             pe.strokeWidth = 1;
         }
    }
    
    this.SnapMe = function( )
    {
        for( var p = 0, ln = this.pts.length; p < ln; p += 2 )
        {
            this.spts[p]   = graphSe.SnapX( this.pts[p] );
            this.spts[p+1] = graphSe.SnapY( this.pts[p+1] );
        }
    }
    
    this.PathMe = function( )
    {
        this.path = this.myPath;
    }
    
    this.CorrectMe = function( type )
     {
         this.correct[0] = { type: type == undefined ? "precise" : type, lbl: this.label, pts: [ ], spts: [ ] };
         for( var i = 0, ln = this.pts.length; i < ln; i++ ) 
         {
             this.correct[0].pts[i] = this.pts[i];
             this.correct[0].spts[i] = this.spts[i];
         }
     }
     
     this.CheckIsCorrect = function( mode )
     {
         var tst = true;
         if( this.correct && mode == undefined )
         {
             var typ = this.correct[0].type;
             var area = (typ != undefined) && (typ.length == 3);
             if( typ == "precise" || typ == undefined || area  )
             {
                 var ca = this.correct[0];
                 switch( ca.lbl[0] )
                 {
                     case 'C':
                         var pca = graphSe.snapIt ? this.correct[0].spts : this.correct[0].pts;
                         for( var i = 0, ssq = 0, tst = true, ln = this.pts.length; i < ln; i += 2 )
                         {
                             var px = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.spts[i] : this.pts[i]   );
                             var py = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.spts[i+1] : this.pts[i+1] );
                             var cx = graphSe.ConvertXgToXpx( pca[i] );
                             var cy = graphSe.ConvertYgToYpx( pca[i+1] );
                             var dpx = px - cx;
                             var dpy = py - cy;
             
                             tst = tst && (Math.sqrt(dpx*dpx + dpy*dpy) < this.correctTolerance) ;
                         }
                         break;
                     
                     case 'A':
                         var aao = graphSe.FindInGraph( ca.lbl );
                         for( var i = 0, ssq = 0, tst = true, ln = this.pts.length; i < ln; i += 2 )
                         {
                             var px = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.spts[i] : this.pts[i] );
                             var py = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.spts[i+1] : this.pts[i+1] );
                         
                             tst = tst && aao.path.contains(new paper.Point(px,py));
                         }
                         break;
                
                     default:
                         tst = false;
                         break; 
                 }
             }
             else if( typ.length == 2 )
             {
                 var pca = graphSe.snapIt ? this.spts : this.pts;
                 var cpx = graphSe.ConvertXgToXpx( pca[0] );
                 var cpxm = graphSe.ConvertXgToXpx( pca[2] );
                 var cpxe = graphSe.ConvertXgToXpx( pca[4] );
                 
                 rele = graphSe.FindInGraph( this.relementlabel );
                 if( rele instanceof Curve )
                 {  
                     if( rele == this ) rele = this.correct[0];
                     
                     var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.spts[0] : rele.pts[0] );
                     var xpm = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.spts[2] : rele.pts[2] );
                     var xpe = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.spts[4] : rele.pts[4] );
                     
                     var xmn = Math.min( xpx, xpm, xpe );
                     var xmx = Math.max( xpx, xpm, xpe );
                     
                     var cmn = Math.min( cpx, cpxm, cpxe );
                     var cmx = Math.max( cpx, cpxm, cpxe );
                 
                     var lfrt = typ[1];
                     if( lfrt == "left" && cmx < xmn ) tst = true;
                     else if( lfrt == "right" && cmn > xmx ) tst = true;
                     else tst = false;
                 }
                 else if( rele instanceof Point )
                 {
                     var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.sxg : rele.xg );
                     
                     var cmn = Math.min( cpx, cpxm, cpxe );
                     var cmx = Math.max( cpx, cpxm, cpxe );
                     
                     var lfrt = typ[1];
                     if( lfrt == "left" && cmx < xpx ) tst = true;
                     else if( lfrt == "right" && cmn > xpx ) tst = true;
                     else tst = false; 
                 }
                 else if( rele instanceof Line )
                 {
                     var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.sxsg : rele.xsg );
                     var xpxe = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.sxeg : rele.xeg );
                     
                     var xmn = Math.min( xpx, xpxe );
                     var xmx = Math.max( xpx, xpxe );
                     
                     var cmn = Math.min( cpx, cpxm, cpxe );
                     var cmx = Math.max( cpx, cpxm, cpxe );
                     
                     var lfrt = typ[1];
                     if( lfrt == "left" && cmx < xmn ) tst = true;
                     else if( lfrt == "right" && cmn > xmx ) tst = true;
                     else tst = false;
                 }
                 else if( rele instanceof Polyline )
                 {
                     for( var i = 0, ln = rele.pts.length-2, xmn = 10000, xmx = 0; i < ln; i += 2 )
                     {
                         var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.spts[i] : rele.pts[i] );
                         if( xpx < xmn ) xmn = xpx;
                         else if( xpx > xmx ) xmx = xpx;
                     }
                     
                     var cmn = Math.min( cpx, cpxm, cpxe );
                     var cmx = Math.max( cpx, cpxm, cpxe );
                     
                     var lfrt = typ[1];
                     if( lfrt == "left" && cmx < xmn ) tst = true;
                     else if( lfrt == "right" && cmn > xmx ) tst = true;
                     else tst = false;
                 }
                 
                 
             }
         }
         else if( mode == "drawing" )
         {
             for( var i = 0, tst = false, ln = graphMe.length; i < ln && !tst; i++ )
             {
                 var gi = graphMe[i];
                 if( gi.mode == "correct" && gi.what == this.what )
                 {
                     for( var i = 0, ssq = 0, tst = true, ln = this.pts.length; i < ln; i += 2 )
                     {
                         var px = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.spts[i] : this.pts[i] );
                         var py = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.spts[i+1] : this.pts[i+1] );
                         var cx = graphSe.ConvertXgToXpx( graphSe.snapIt ? gi.spts[i] : gi.pts[i] );
                         var cy = graphSe.ConvertYgToYpx( graphSe.snapIt ? gi.spts[i+1] : gi.pts[i+1] );
                         var dpx = px - cx;
                         var dpy = py - cy;
             
                         tst = tst && (Math.sqrt(dpx*dpx + dpy*dpy) < this.correctTolerance);
                     }
                 }
             }
         }
 
         this.feedback = tst ? this.correctgraph=true : this.correctgraph=false;

         
         if(this.requiredlabel)
         {
         	if(this.correctlabel==this.studentcorrectlabel) 
         	{
         		this.labelcorrect=true;
         	} else {
         		this.labelcorrect=false;
         	}		
         	
         } else 
         {
         	this.labelcorrect=true;
         }
         
         if(this.correctgraph==true && this.labelcorrect==true)
         {
         	this.iscorrect="<span style='color:green;'>Correct</span>";
         }	else {
         	this.iscorrect="<span style='color:red'>Not Correct</span>";
         }	
         
         //SayFeedback( this.feedback );
     }
    
     this.GhostMe = function( )
     {
         this.ghost = { clr: "lightgray", wd: this.width, pts: [ ], spts: [ ]};
         for( var i = 0, ln = this.pts.length; i < ln; i++ ) 
         {
             this.ghost.pts[i] = this.pts[i];
             this.ghost.spts[i] = this.spts[i];
         }
     }
    
    this.PlumbMe = function( tf )
    {
         this.plumbLine = tf;
    }
    
    this.PlumbLine = function( )
    {
         this.PathMe( );
         var ln = graphMe.length;
         for( var j = 0; j < ln; j++ ) 
         {
              var gj = graphMe[j];
              if( gj == this ) continue;
              
              gj.PathMe();
              var gii = this.path.getIntersections( gj.path );
              var giiln = gii.length;
              if( (gj instanceof Point) && giiln > 0 )
              {
                   var clr = 'grey';
                   DrawLine( clr, this.width, gj.x, gj.y, 0, gj.y, [4, 4] ); 
                   DrawLine( clr, this.width, gj.x, gj.y, gj.x, can.height-3, [4, 4] ); 
              }
              else
              {
                   for (var k = 0; k < giiln; k++)
                   {
                        var clr = 'grey';
                        var giik = gii[k];
                        DrawLine( clr, 1, giik.point.x, giik.point.y, 0, giik.point.y, [4, 4] );
                        DrawLine( clr, 1, giik.point.x, giik.point.y, giik.point.x, can.height-3, [4, 4] );

  						var text = new paper.PointText(new paper.Point(15, giik.point.y-10));
						text.justification = 'center';
						text.fillColor = "grey";
						text.fontSize = 10
						text.content = Math.round(graphSe.ConvertYpxToYg(giik.point.y)*10)/10;

  						var text = new paper.PointText(new paper.Point(giik.point.x+14, 375));
						text.justification = 'center';
						text.fillColor = "grey";
						text.fontSize = 10
						text.content = Math.round(graphSe.ConvertXpxToXg(giik.point.x)*10)/10

/*
			ctx2.fillStyle = "grey";
			ctx2.fillText(Math.round(graphSe.ConvertYpxToYg(giik.point.y)*10)/10,55,giik.point.y+10);
                  
		        ctx2.fillStyle = "grey";
			ctx2.fillText(Math.round(graphSe.ConvertXpxToXg(giik.point.x)*10)/10,giik.point.x+54,395);	*/	                   		  

                    }
              }
         }
     }

	 this.checkBoxes = function()
	 {
	 	if(document.getElementById('demand').checked) {this.checkboxes[0]=true} else {this.checkboxes[0]=false};
	 	if(document.getElementById('fixedcost').checked) {this.checkboxes[1]=true} else {this.checkboxes[1]=false};
	 	if(document.getElementById('indifference').checked) {this.checkboxes[2]=true} else {this.checkboxes[2]=false};
	 	if(document.getElementById('marginalcost').checked) {this.checkboxes[3]=true} else {this.checkboxes[3]=false};
	 	if(document.getElementById('marginalrevenue').checked) {this.checkboxes[4]=true} else {this.checkboxes[4]=false};
	 	if(document.getElementById('ppf').checked) {this.checkboxes[5]=true} else {this.checkboxes[5]=false};
	 	if(document.getElementById('supply').checked) {this.checkboxes[6]=true} else {this.checkboxes[6]=false};
	 	if(document.getElementById('totalcost').checked) {this.checkboxes[7]=true} else {this.checkboxes[7]=false};
	 	if(document.getElementById('variablecost').checked) {this.checkboxes[8]=true} else {this.checkboxes[8]=false};

		for(var i=0; i<this.customlabels.length; i++)
		{
		 	var str = this.customlabels[i];
		 	var lwr = str.toLowerCase();
		 	str = lwr.replace(/\s+/g, '');

			if(document.getElementById(str).checked) {this.checkboxes[8+i+1]=true} else {this.checkboxes[8+i+1]=false};	
				 	
		 	//html += '<input type="checkbox" id="'+str+'" checked> '+this.customlabels[i]+'<br>'
		 	//this.checkboxes[i+9] = false;
		}


     	this.CorrectLabelDropdown(); 

     	//this.SetSettings();

	 }
	 
	 this.checkBoxHTML = function()
	 {
	 	var html = '';
	 	
	 	if(this.checkboxes[0])
	 	{
	 		html += '<input type="checkbox" id="demand" checked> Demand<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="demand"> Demand<br>'	 	
	 	}
	 	
	 	if(this.checkboxes[1])
	 	{
	 		html += '<input type="checkbox" id="fixedcost" checked> Fixed Cost<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="fixedcost"> Fixed Cost<br>'	 	
	 	}	 	
	 	
	 	if(this.checkboxes[2])
	 	{
	 		html += '<input type="checkbox" id="indifference" checked> Indifference<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="indifference"> Indifference<br>'	 	
	 	}
	 	
	 	if(this.checkboxes[3])
	 	{
	 		html += '<input type="checkbox" id="marginalcost" checked> Marginal Cost<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="marginalcost"> Marginal Cost<br>'	 	
	 	}
	 	
	 	if(this.checkboxes[4])
	 	{
	 		html += '<input type="checkbox" id="marginalrevenue" checked> Marginal Revenue<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="marginalrevenue"> Marginal Revenue<br>'	 	
	 	}
	 		 	
	 	if(this.checkboxes[5])
	 	{
	 		html += '<input type="checkbox" id="ppf" checked> PPF<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="ppf"> PPF<br>'	 	
	 	}

	 	if(this.checkboxes[6])
	 	{
	 		html += '<input type="checkbox" id="supply" checked> Supply<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="supply"> Supply<br>'	 	
	 	}	 		 

	 	if(this.checkboxes[7])
	 	{
	 		html += '<input type="checkbox" id="totalcost" checked> Total Cost<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="totalcost"> Total Cost<br>'	 	
	 	}		 	

	 	if(this.checkboxes[8])
	 	{
	 		html += '<input type="checkbox" id="variablecost" checked> Variable Cost<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="variablecost"> Variable Cost<br>'	 	
	 	}			 	

		for(var i=0; i<this.customlabels.length; i++)
		{
		 	var str = this.customlabels[i];
		 	var lwr = str.toLowerCase();
		 	str = lwr.replace(/\s+/g, '');
		 	
		 	html += '<input type="checkbox" id="'+str+'" checked> '+this.customlabels[i]+'<br>'
		 	//this.checkboxes[i+9] = false;
		}

	 	this.checkboxhtml = html;
	 	
	 	//document.getElementById('checkform').innerHTML = this.checkboxhtml;
	 }

     this.addLabel = function()
     {
     	this.customlabels.push(document.getElementById('newlabel').value)
     	
     	var str = document.getElementById('newlabel').value;
		var lwr = str.toLowerCase();
		str = lwr.replace(/\s+/g, '');
     	
     	this.checkBoxHTML();
     	
     	document.getElementById('checkform').innerHTML = this.checkboxhtml;
     	
		this.CorrectLabelDropdown();

		var fstr = document.getElementById("cltext2").style.paddingTop;
		var fstr2 = fstr.split("px");
		fstr = fstr2[0];
		fstr = Number(fstr)+20;
		document.getElementById("cltext2").style.paddingTop = fstr+"px";
		this.clabeloffset = fstr+"px";	
     }	

     this.CorrectLabelDropdown = function ()
     {
     		var html = '<option value="None">None</option>'

			if(document.getElementById('demand').checked) {html += '<option value="Demand">Demand</option>'} else {};
			if(document.getElementById('fixedcost').checked) {html += '<option value="Fixed Cost">Fixed Cost</option>'} else {};
			if(document.getElementById('indifference').checked) {html += '<option value="Indifference">Indifference</option>'} else {};
			if(document.getElementById('marginalcost').checked) {html += '<option value="Marginal Cost">Marginal Cost</option>'} else {};
			if(document.getElementById('marginalrevenue').checked) {html += '<option value="Marginal Revenue">Marginal Revenue</option>'} else {};
			if(document.getElementById('ppf').checked) {html += '<option value="PPF">PPF</option>'} else {};
			if(document.getElementById('supply').checked) {html += '<option value="Supply">Supply</option>'} else {};
			if(document.getElementById('totalcost').checked) {html += '<option value="Total Cost">Total Cost</option>'} else {};
			if(document.getElementById('variablecost').checked) {html += '<option value="Variable Cost">Variable Cost</option>'} else {};

			for(var i=0; i<this.customlabels.length; i++)
			{
				var str = this.customlabels[i];
				var lwr = str.toLowerCase();
				str = lwr.replace(/\s+/g, '');
			
				if(document.getElementById(str)) {
					if(document.getElementById(str).checked) {html += '<option value="'+this.customlabels[i]+'">'+this.customlabels[i]+'</option>'} else {}
				}
				//this.checkboxes[i+9] = false;
			}
       		
     		this.clselects = html;

     	    document.getElementById("cldropdown").innerHTML = html;		
		 	document.getElementById('cldropdown').value = this.correctlabel;

     }     

     this.SetSettings = function( )
     {
     	 //this.CalculateSlope();
     	 //this.LineUpdate();
 
     	 this.TrackAgainstDropdown();   
     	 this.RelativeDropdown();   
     	 this.checkBoxHTML();
     	      	 
     	 $('#bottomtools').removeClass("hide");
     	 
     	 var html = '<div class="sectionhead"><span id="elementhead">Element Settings </span><button class="glyphicon glyphicon-left" aria-hidden="true" style="margin-left: 30px; background: none; border: none;" onclick="leftArrow();"></button><span id="toplabel'+this.labelvalue+'" class="elementid">'+this.label+'</span><button class="glyphicon glyphicon-right" aria-hidden="true" onclick="rightArrow();" style="background: none; border: none;"></span></div>'
     	 html += '<div class="hrm"></div>'
		 html += '<div class="row" style="margin-left: 20px;">'
		 html += '<div class="col-sm-6">'
     	 html += '<div id="designertools">'
		 html += '<div class="tool">Element Type</div>'
		 html += '<div class="tool"></div>'
		 html += '<div class="tool">Label</div>'
		 html += '<div class="tool">Show Label</div>'
		 html += '<div class="tool">Origin Point</div>'
		 html += '<div class="tool">Mid Point</div>'
		 html += '<div class="tool">End Point</div>'
		 html += '<div class="tool">Show Plumbs</div>'
		 html += '</div>'
		 html += '</div>'
		 html += '<div class="col-sm-6" style="padding-top: 8px;">'
     	 html += '<div id="designerinputs">'
		 html += '<div class="styled-select"><select id="eldropdown" class="select-class" onchange="GetElement(this.value)"></span><option value="None">None</option><option value="Consumer Surplus">Demand</option><option value="Fixed Cost">Fixed Cost</option><option value="Indifference">Indifference</option><option value="Marginal Cost">Marginal Cost</option><option value="Marginal Revenue">Marginal Revenue</option><option value="PPF">PPF</option><option value="Supply">Supply</option><option value="Total Cost">Total Cost</option><option value="Variable Cost">Variable Cost</option></select></div>'
		 html += '<button id="bcbutton" aria-hidden="true" onclick="bookColor();">Use Book Color <span class="glyphicon glyphicon-uncheckedmm"></span></button>'
		 html += '<div><input id="xlabel'+this.labelvalue+'" type="text" class="small-label" placeholder="'+this.label+'" onkeyup="labelUpdate(this.value)" maxlength="5"></div>'	  			
		 html += '<div><label class="switch tool"><input id="labeltoggle" type="checkbox" onclick="update();"><div class="slider"><span class="ontext">ON</span><span class="offtext">OFF</span></div></label></div>'
		 html += '<div>(<input id="cxspoint" type="number" class="point-input" value="" step="'+graphSe.xmax/Number(graphSe.wdPx)+'"  oninput="cxsUpdate(this.value)">,<input id="cyspoint" type="number" class="point-input" value="" step="'+graphSe.ymax/Number(385)+'" oninput="cysUpdate(this.value)" >)</div>'	  			
		 html += '<div>(<input id="cxmpoint" type="number" class="point-input" value="" step="'+graphSe.xmax/Number(graphSe.wdPx)+'"  oninput="cxmUpdate(this.value)">,<input id="cympoint" type="number" class="point-input" value="" step="'+graphSe.ymax/Number(385)+'" oninput="cymUpdate(this.value)" >)</div>'	  			
		 html += '<div>(<input id="cxepoint" type="number" class="point-input" value="" step="'+graphSe.xmax/Number(graphSe.wdPx)+'"  oninput="cxeUpdate(this.value)">,<input id="cyepoint" type="number" class="point-input" value="" step="'+graphSe.ymax/Number(385)+'" oninput="cyeUpdate(this.value)" >)</div>'	  			
		 html += '<div><label class="switch tool"><input id="plumbtoggle" type="checkbox" onclick="update();"><div class="slider"><span class="ontext">ON</span><span class="offtext">OFF</span></div></label></div>'
		 html += '</div>'	  			
		 html += '</div>'	  			
	     html += '</div>'		

     	 $('#interactive').removeClass("hide");

     	 var html2 = '<div id="sectionpadding" class="sectionhead"></div>'
		 html2 += '<div class="row" style="margin-left: 20px;">'
		 html2 += '<div id="intleft" class="col-sm-6">'
		 html2 += '<button class="fake-radio" id="binteractive" onclick="Interactive(true);"> <div class="radio-off"><div id="binteractivero" class="radio-on hide"></div></div>Interactive</button><br>'
		 html2 += '<div id="ilabels" class="hide"><div class="tool">Label after move</div>'
		 html2 += '<div class="tool">Track against</div>'		 
		 html2 += '</div>'
		 html2 += '</div>'		 
		 html2 += '<div id="intright" class="col-sm-6">'
		 html2 += '<button class="fake-radio" id="bstatic" onclick="Interactive(false);"> <div class="radio-off"><div id="bstaticro" class="radio-on"></div></div>Static<br></button>'
		 html2 += '<div id="iinputs" class="hide"><div><input id="labelam" type="text" value="'+this.labelam+'" oninput="labelAMUpdate(this.value)" style="margin-top: 10px; width: 75px"></div>'	  			
		 html2 += '<div class="styled-select"><select id="tadropdown" class="select-class" onchange="TAElement(this.value)" value="'+this.taelement+'" style="margin-top:10px">'+this.taselects+'</select></div>'
		 html2 += '</div>'	
	     html2 += '</div>'	
		 html2 += '<div id="elabel" class="row hide">'
		 html2 += '<div class="col-sm-6">'
		 html2 += '<div class="tool"><strong>Evaluated on</strong></div>'		 
		 html2 += '</div>'	
		 html2 += '<div class="col-sm-6">'
		 html2 += '<div id="elabelmode" class="" style="margin-top: 11px;">Interaction</div>'		 		   			
		 html2 += '</div>'	
		 html2 += '</div>'	

		 var html3 = '<div class="row" style="margin-left: 20px;">'
		 html3 += '<div class="col-sm-6">'
		 html3 += '<button class="fake-radio" id="bprecise" onclick="Precise(true);"> <div class="radio-off"><div id="bprecisero" class="radio-on hide"></div></div>Precise</button><br>'
		 html3 += '<div id="precisetools" class="hide">'
		 html3 += '<div class="tool">Origin Point</div>'
		 html3 += '<div class="tool">Mid Point</div>'
		 html3 += '<div class="tool">End Point</div>'
		 html3 += '</div>'
		 html3 += '<div id="relativetools" class="hide">'
		 html3 += '<div class="tool">Relative to:</div>'
		 html3 += '<div id="relativetools2" class="hide">'
		 html3 += '<div class="tool">Shift from origin</div>'
		 html3 += '</div>'
		 html3 += '<div id="drawarea" class="hide" style="width: 200px; margin-top: 10px; margin-left: 10px; position:relative; top: 10px;"><button type="button" class="btn btn-econ-sw5" onclick="DoAcceptedArea(gmloc-1)"><span class="glyphicon glyphicon-pentagon" aria-hidden="true"></span><img id="areashade" src="./images/areashade.png"></img></button><span style="padding-left: 5px;">Draw Accepted Area</span></div>'	
		 html3 += '</div>'	
		 html3 += '</div>'	
		 html3 += '<div class="col-sm-6">'
		 html3 += '<button class="fake-radio" id="brelative" onclick="Precise(false);"> <div class="radio-off"><div id="brelativero" class="radio-on"></div></div>Relative<br></button>'
		 html3 += '<div id="preciseinputs" class="hide" style="position:relative; top: 10px">'
		 html3 += '<div>(<input id="cxspointc" type="number" class="point-input" value="" step="'+graphSe.xmax/Number(graphSe.wdPx)+'"  oninput="cxsUpdate(this.value)">,<input id="cyspointc" type="number" class="point-input" value="" step="'+graphSe.ymax/Number(385)+'" oninput="cysUpdate(this.value)" >)</div>'	  			
		 html3 += '<div>(<input id="cxmpointc" type="number" class="point-input" value="" step="'+graphSe.xmax/Number(graphSe.wdPx)+'"  oninput="cxmUpdate(this.value)">,<input id="cympointc" type="number" class="point-input" value="" step="'+graphSe.ymax/Number(385)+'" oninput="cymUpdate(this.value)" >)</div>'	  			
		 html3 += '<div>(<input id="cxepointc" type="number" class="point-input" value="" step="'+graphSe.xmax/Number(graphSe.wdPx)+'"  oninput="cxeUpdate(this.value)">,<input id="cyepointc" type="number" class="point-input" value="" step="'+graphSe.ymax/Number(385)+'" oninput="cyeUpdate(this.value)" >)</div>'	  			
		 html3 += '</div>'	
		 html3 += '<div id="relativeinputs" class="hide">'
		 html3 += '<div class="styled-select" style="margin-top:9px"><select id="reldropdown" class="select-class" onchange="GetRelativeElement(this.value)"></span>'+this.relselects+'</select></div>'
		 html3 += '<div id="relativeinputs2" class="hide">'
		 html3 += '<button class="fake-radio" id="sleft" onclick="ShiftLeft();" style="margin-top:13px;"> <div class="radio-off"><div id="sleftro" class="radio-on hide"></div></div>Left</button><br>'
		 html3 += '<button class="fake-radio" id="sright" onclick="ShiftRight();" style="margin-top:0px;"> <div class="radio-off"><div id="srightro" class="radio-on hide"></div></div>Right</button><br>'
		 html3 += '</div>'	
		 html3 += '</div>'	
		 html3 += '</div>'	
		 html3 += '</div>'	
		 
		 var html4 = '<div class="row" style="margin-left: 20px;">'
		 html4 += '<div class="col-sm-6">'
		 html4 += '<div class="tool" style="margin-top: 0px;">Required label</div>'
		 html4 += '<div id="requiredlabeltools" class="hide">'
		 html4 += '<div class="tool">Label Choices</div>'
		 html4 += '<div id="cltext2" class="tool" style="padding-top: '+this.clabeloffset+'">Correct Label</div>'
		 html4 += '</div>'	
		 html4 += '</div>'	
		 html4 += '<div class="col-sm-6">'
		 html4 += '<div id="rtoggleshell" style="margin-top:10px;"><label class="switch tool"><input id="rltoggle" type="checkbox" onclick="update();"><div class="slider"><span class="ontext">ON</span><span class="offtext">OFF</span></div></label></div>'
		 html4 += '<div id="requiredlabelinputs" class="hide">'
		 html4 += '<form id="checkform" onclick="checkBoxes();">'+this.checkboxhtml+'</form>'
		 html4 += '<div><input id="newlabel" type="text" class="" placeholder="Custom label" onkeyup="" style="width: 100px; margin-top: 10px;"><button class="btn-nothing" onclick="addLabel()"> <span class="glyphicon glyphicon-cplus"></span></button></div>'
		 html4 += '<div class="styled-select" style="margin-top: 10px"><select id="cldropdown" class="select-class" onchange="GetCorrectLabel(this.value)"></span>'+this.clselects+'</select></div>'
		 html4 += '</div>'	
		 html4 += '</div>'	
		 html4 += '</div>'		

		 var html5 = '<div class="row" style="margin-left: 20px;">'
		 html5 += '<div class="col-sm-6">'
		 html5 += '<div class="tool">Element Type</div>'
		 html5 += '<div class="tool">Origin Point</div>'
		 html5 += '<div class="tool">Mid Point</div>'
		 html5 += '<div class="tool">End Point</div>'
		 html5 += '</div>'
		 html5 += '<div class="col-sm-6" style="padding-top: 8px;">'
		 html5 += '<div class="styled-select"><select id="eldropdown" class="select-class" onchange="GetElement(this.value)"></span><option value="None">None</option><option value="Demand">Demand</option><option value="Fixed Cost">Fixed Cost</option><option value="Indifference">Indifference</option><option value="Marginal Cost">Marginal Cost</option><option value="Marginal Revenue">Marginal Revenue</option><option value="PPF">PPF</option><option value="Supply">Supply</option><option value="Total Cost">Total Cost</option><option value="Variable Cost">Variable Cost</option></select></div>'
		 html5 += '<div style="margin-top: 10px">(<input id="cxspointd" type="number" class="point-input" value="" step="'+graphSe.xmax/Number(graphSe.wdPx)+'"  oninput="cxsUpdate(this.value)">,<input id="cyspointd" type="number" class="point-input" value="" step="'+graphSe.ymax/Number(385)+'" oninput="cysUpdate(this.value)" >)</div>'	  			
		 html5 += '<div>(<input id="cxmpointd" type="number" class="point-input" value="" step="'+graphSe.xmax/Number(graphSe.wdPx)+'"  oninput="cxmUpdate(this.value)">,<input id="cympointd" type="number" class="point-input" value="" step="'+graphSe.ymax/Number(385)+'" oninput="cymUpdate(this.value)" >)</div>'	  			
		 html5 += '<div>(<input id="cxepointd" type="number" class="point-input" value="" step="'+graphSe.xmax/Number(graphSe.wdPx)+'"  oninput="cxeUpdate(this.value)">,<input id="cyepointd" type="number" class="point-input" value="" step="'+graphSe.ymax/Number(385)+'" oninput="cyeUpdate(this.value)" >)</div>'	  			
		 html5 += '</div>'	  			
		 html5 += '</div>'	  			

		 		 
		 document.getElementById("bottomtools").innerHTML = html;		
		 document.getElementById("interactive").innerHTML = html2;		
		 document.getElementById("interactivetools").innerHTML = html3;		
		 document.getElementById("labeldetails").innerHTML = html4;		
		 document.getElementById("drawingtools").innerHTML = html5;		
		
		 document.getElementById('eldropdown').value = this.elementlabel;
		 document.getElementById('plumbtoggle').checked = this.plumbLine;
		 document.getElementById('cldropdown').value = this.correctlabel;

		 document.getElementById('tadropdown').value = this.taelement;
		 document.getElementById('reldropdown').value = this.relementlabel;
		 document.getElementById('rltoggle').checked = this.requiredlabel;
		 
		 this.checkBoxes();
		 
		 this.InteractiveMe( this.interactive );
		 this.PreciseMe( this.precise );
		 this.EvalShift( this.evalshift );
		 
		 this.SetElementPoints( );
		 
		 this.DisplayBookColor();
		 
		 this.HighLight();

		 this.InteractiveReset();

		 this.CheckRLabel();
		 
		 this.CorrectTools();
  
  		 if(graphSe.mode=="correct") this.SetCorrectPoints( );
  
 		 $('#emptydesigner').addClass("hide");		

		 if(this.labelLine==true) 
		 {
		 	document.getElementById("labeltoggle").checked = true;	
		 } else
		 {	
		 	document.getElementById("labeltoggle").checked = false;	
		 }
	


     }
     
     this.SetElementPoints = function( )
     {
         document.getElementById('cxspoint').value = graphSe.snapIt ? this.spts[0] : this.pts[0];
		 document.getElementById('cyspoint').value = graphSe.snapIt ? this.spts[1] : this.pts[1];

         document.getElementById('cxspointd').value = graphSe.snapIt ? this.spts[0] : this.pts[0];
		 document.getElementById('cyspointd').value = graphSe.snapIt ? this.spts[1] : this.pts[1];

         if( this.pts.length >= 2)
         {  
			 document.getElementById('cxmpoint').value = graphSe.snapIt ? this.spts[2] : this.pts[2];
			 document.getElementById('cympoint').value = graphSe.snapIt ? this.spts[3] : this.pts[3];

			 document.getElementById('cxmpointd').value = graphSe.snapIt ? this.spts[2] : this.pts[2];
			 document.getElementById('cympointd').value = graphSe.snapIt ? this.spts[3] : this.pts[3];			 
		 }

         if( this.pts.length >= 3)
         {  
			 document.getElementById('cxepoint').value = graphSe.snapIt ? this.spts[4] : this.pts[4];
			 document.getElementById('cyepoint').value = graphSe.snapIt ? this.spts[5] : this.pts[5];

			 document.getElementById('cxepointd').value = graphSe.snapIt ? this.spts[4] : this.pts[4];
			 document.getElementById('cyepointd').value = graphSe.snapIt ? this.spts[5] : this.pts[5];

		 }
     }
     
     this.SetElementLabel = function(text)
     {
     	 this.elementlabel = text;

		 this.SetColor();     	 
     }
	
     this.SetRelativeElementLabel = function(text)
     {
     	 this.relementlabel = text;
     	 
     	 this.CheckRLabel();
     }
	
	 this.CheckRLabel = function()
	 {
	     if(this.relementlabel=="Accepted Area")
     	 {
   			$('#relativetools2').addClass("hide");     	 	
			$('#relativeinputs2').addClass("hide");      	 
   			$('#drawarea').removeClass("hide");     	 	
    	 } else if (this.relementlabel=="None")
     	 {
  			$('#relativetools2').addClass("hide");     	 	
			$('#relativeinputs2').addClass("hide");     	 
    		$('#drawarea').addClass("hide");     	 	
    	 } else
     	 {
			$('#relativetools2').removeClass("hide");     	 	
			$('#relativeinputs2').removeClass("hide");     	 	
   			$('#drawarea').addClass("hide");     	 	
     	 }
	 }
	 
	 this.SetBookColor = function(text)
	 {
	 	this.bookcolor = text;	 	

		this.SetColor();
	 }
	 
     this.LabelMe = function( tf )
     {
         this.labelLine = tf;
     }     
     

     this.LabelLine = function(  )
     {
        
        var spt = graphSe.snapIt ? { x: this.spts[2], y: this.spts[3] } : { x: this.pts[2], y: this.pts[3] };
        var pt = graphSe.snapIt ? { x: this.spts[4], y: this.spts[5] } : { x: this.pts[4], y: this.pts[5] };
		
		var xoffset = 0;
		var yoffset = 0;

		pt.x = graphSe.ConvertXgToXpx(pt.x)+xoffset;
		pt.y = graphSe.ConvertYgToYpx(pt.y)+yoffset;
		spt.x = graphSe.ConvertXgToXpx(spt.x)+xoffset;
		spt.y = graphSe.ConvertYgToYpx(spt.y)+yoffset;
		
		var d = 20;
		
		var mag = Math.sqrt(Math.pow((pt.x - spt.x),2) + Math.pow((pt.y - spt.y),2))
		var newx = pt.x + d * (pt.x - spt.x) / mag
		var newy = pt.y + d * (pt.y - spt.y) / mag

        var clr = this.iscurrent == true ? this.cc: this.ccus;

		//console.log(clr);
		/*ctx2.fillStyle = clr;
		ctx2.font="14px sans-serif";
		ctx2.fillText(this.label,newx,newy);
		ctx2.font="10px sans-serif";*/

		var templabel;
		if(graphSe.mode=="correct"&&this.dragstart!=undefined)
		{
			templabel = this.labelam;
		} else
		{
			templabel = this.label;
		}
			
		if(graphSe.mode=="designer")
		{
			templabel = this.label;
		}	

		if(graphSe.mode=="student"&&this.studentdrag!=null)
		{
			templabel = this.labelam;
		}				

		var text = new paper.PointText(new paper.Point(newx, newy));
		text.justification = 'center';
		text.fillColor = clr;
		text.content = templabel;
/*

		
		var text = new paper.PointText(new paper.Point(newx, newy));
		text.justification = 'center';
		text.fillColor = clr;
		text.content = this.label;*/
		
	}  
	 

	 this.GetBookColor = function(text)
	 {
	 	return this.bookcolor;	
	 }	 	 

	 this.DisplayBookColor = function()
	 {
	 	if(this.bookcolor=="Yes")
	 	{
			document.getElementById('bcbutton').innerHTML = 'Use Book Color <span class="glyphicon glyphicon-checkedmm"></span>';
	 	} else 
	 	{
	 		document.getElementById('bcbutton').innerHTML = 'Use Book Color <span class="glyphicon glyphicon-uncheckedmm"></span>';
	 	}
	 }

	 this.HighLight = function()
	 {
	 	for(i=0; i<graphMe.length; i++)
	 	{
	 		graphMe[i].iscurrent=false	
	 	}	
	 	
	 	this.iscurrent=true
	 }
	 
	 this.UpdateLabelText = function()
	 {
		document.getElementById('xlabel'+this.labelvalue).value = this.label;	 	
		document.getElementById('toplabel'+this.labelvalue).innerHTML = this.label;	 	
	 }

	 this.InteractiveMe = function( tf )
     {
        this.interactive = tf;
        if( tf ) { $("#binteractivero").removeClass("hide"); $("#bstaticro").addClass("hide"); }
        else { $("#binteractivero").addClass("hide"); $("#bstaticro").removeClass("hide"); }
     }

     
     this.CorrectTools = function()
     {
     	if(graphSe.mode=='correct')
     	{
 			if(this.interactive!=false)$('#labeldetails').removeClass("hide");
 			$('#designertools').addClass("hide");
			$('#designerinputs').addClass("hide");      	
			$('#elabel').removeClass("hide");      	
			$('#elabelmode').removeClass("hide");      	
			$('#intleft').addClass("hide");      	
			$('#intright').addClass("hide");      	
		 	document.getElementById("elementhead").innerHTML = "Evaluation Settings";		
			document.getElementById("interactive").style.background = "#fbfbfb";
			document.getElementById("interactive").style.marginTop = "0px";
 			$('#sectionpadding').addClass("hide");

			if(this.interactive==true)
			{
		 		document.getElementById("elabelmode").innerHTML = "Interactive";
		 		this.elabelmode = "Interactive";		
				$('#interactivetools').removeClass("hide");      	
			} else {
		 		document.getElementById("elabelmode").innerHTML = "Static";		
		 		this.elabelmode = "Static";				 		
				$('#interactivetools').addClass("hide");      	
			}	
			
			if(this.mode=="correct")
			{
		 		document.getElementById("elabelmode").innerHTML = "Drawing";
		 		this.elabelmode = "Drawing";				
				$('#interactivetools').addClass("hide");   				
				$('#drawingtools').removeClass("hide");   				
 				$('#labeldetails').removeClass("hide");
			}     
			if(document.getElementById('rltoggle').checked)
			{
				$('#requiredlabeltools').removeClass("hide");   				
 				$('#requiredlabelinputs').removeClass("hide");	
 		 		document.getElementById('cldropdown').value = this.correctlabel;				
			} else 
			{
				$('#requiredlabeltools').addClass("hide");   				
 				$('#requiredlabelinputs').addClass("hide");					
			}
			if(this.elabelmode=="Drawing")
			{
				$('#drawingtools').removeClass("hide");   							
			} else
			{
				$('#drawingtools').addClass("hide");   				
			}

     	} else if(graphSe.mode=='student')
     	{
 				$('#interactive').addClass("hide");   				
				$('#bottomtools').addClass("hide");
 				$('#interactivetools').addClass("hide");   				
				$('#requiredlabeltools').addClass("hide");   				
 				$('#requiredlabelinputs').addClass("hide");					   				
    		
     	} else 
     	{
 			$('#labeldetails').addClass("hide");
			$('#designertools').removeClass("hide");
			$('#designerinputs').removeClass("hide");     	
			//$('#elabel').addClass("hide");      	
			$('#elabelmode').addClass("hide");      
 			$('#intleft').removeClass("hide");      	
			$('#intright').removeClass("hide");  
 		 	document.getElementById("elementhead").innerHTML = "Element Settings";		
			document.getElementById("interactive").style.background = "#f6f6f6";
			document.getElementById("interactive").style.marginTop = "0px";
  			$('#sectionpadding').removeClass("hide");
			$('#interactivetools').addClass("hide");      	
				$('#requiredlabeltools').addClass("hide");   				
 				$('#requiredlabelinputs').addClass("hide");	
    	}
     }
     
     this.InteractiveReset = function ()
     {
			if(this.interactive==true)
			{
				$('#ilabels').removeClass("hide");
				$('#iinputs').removeClass("hide");
			} else {
				$('#ilabels').addClass("hide");
				$('#iinputs').addClass("hide");
			}	     
     }
     
     this.TrackAgainstDropdown = function ()
     {
     		var html = '<option value="None">None</option>'
     		for(i=0; i<graphMe.length; i++) 
     		{
     			if(graphMe[i].label!=this.label)
     			{
					var graphlabel = graphMe[i].label;
					html += '<option value="'+graphlabel+'">'+graphlabel+'</option>'
				}	
     		}
     		
     		this.taselects = html;
     }

     this.RelativeDropdown = function ()
     {
     		var html = '<option value="None">None</option>'
     		html += '<option value="Accepted Area">Accepted Area</option>'
     		for(i=0; i<graphMe.length; i++) 
     		{
					var graphlabel = graphMe[i].label;
					html += '<option value="'+graphlabel+'">'+graphlabel+'</option>'
     		}
     		
     		this.relselects = html;
     }     

	 this.EvalShift = function( text )
     {
        this.evalshift = text;
        if( this.evalshift=="left" ) { $("#sleftro").removeClass("hide"); $("#srightro").addClass("hide");}
        else if (this.evalshift==null) {$("#sleftro").addClass("hide"); $("#srightro").addClass("hide");}
        else 
        {  
        	$("#sleftro").addClass("hide"); $("#srightro").removeClass("hide"); 
        	//$('#relativetools').removeClass("hide");
			//$('#relativeinputs').removeClass("hide");
        }
        
        if(  text != null ) this.CorrectMe( ["relative",text] );
     }    

	 this.PreciseMe = function( tf )
     {
        this.precise = tf;
        if( tf ) 
        { 
        	$("#bprecisero").removeClass("hide"); $("#brelativero").addClass("hide");
        	$('#relativetools').addClass("hide");
			$('#relativeinputs').addClass("hide");   
        	$('#precisetools').removeClass("hide");
			$('#preciseinputs').removeClass("hide");   			  			    
        }
        else if (tf==null) {$("#bprecisero").addClass("hide"); $("#brelativero").addClass("hide");}
        else 
        {  
        	$("#bprecisero").addClass("hide"); $("#brelativero").removeClass("hide"); 
        	$('#relativetools').removeClass("hide");
			$('#relativeinputs').removeClass("hide");
        	$('#relativetools2').addClass("hide");
			$('#relativeinputs2').addClass("hide");			
        	$('#precisetools').addClass("hide");
			$('#preciseinputs').addClass("hide");   
		}
     }    
     

     this.RequiredLabelMe = function( tf )
     {
         this.requiredlabel = tf;
         
         if(this.requiredlabel)
         {
 			$('#requiredlabelinputs').removeClass("hide");     	 	
			$('#requiredlabeltools').removeClass("hide");     	 	        
         } else {
 			$('#requiredlabelinputs').addClass("hide");     	 	
			$('#requiredlabeltools').addClass("hide");  
		}	           
     }

     this.LabelMeDrop = function( )
     {
		//console.log("label me drop");

		/*console.log("label me drop");
        var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxg : this.xg );
        var ypx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syg : this.yg );
         
        var xspx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxsg : this.xsg );
        var yspx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.sysg : this.ysg );
        var xepx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxeg : this.xeg );
        var yepx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syeg : this.yeg );*/

        var spt = graphSe.snapIt ? { x: this.spts[2], y: this.spts[3] } : { x: this.pts[2], y: this.pts[3] };
        var pt = graphSe.snapIt ? { x: this.spts[4], y: this.spts[5] } : { x: this.pts[4], y: this.pts[5] };
		
		var xoffset = 0;
		var yoffset = 0;

		pt.x = graphSe.ConvertXgToXpx(pt.x)+xoffset;
		pt.y = graphSe.ConvertYgToYpx(pt.y)+yoffset;
		spt.x = graphSe.ConvertXgToXpx(spt.x)+xoffset;
		spt.y = graphSe.ConvertYgToYpx(spt.y)+yoffset;
		
		var d = 20;
		
		var mag = Math.sqrt(Math.pow((pt.x - spt.x),2) + Math.pow((pt.y - spt.y),2))
		var newx = pt.x + d * (pt.x - spt.x) / mag
		var newy = pt.y + d * (pt.y - spt.y) / mag   

		var div = document.createElement("div");
		div.id = 'dlabel';
		div.style.position = "absolute";
		div.style.left = newx+37+'px';
		div.style.top = newy+179+'px';
		div.style.zIndex = "10000";
		div.className = 'styled-select';
			
		div.innerHTML = '<select id="elabel" class="select-class" onchange="GetCorrectStudentLabel(this.value)"></span>'+this.clselects+'</select>'
		document.getElementById('graphcontainer').appendChild(div);	

		//$('#elabel').removeClass("hide");
		
	}   

     this.SetCorrectLabel = function(text)
     {
     	 this.correctlabel = text;
     }

    this.SetCorrectStudentLabel = function(text)
     {
     	 this.studentcorrectlabel = text;
     	 
     	 this.CheckIsCorrect("label");	   	 
     }
 
    this.SetCorrectPoints = function( )
     {         
         if(this.precise)
         {

			 this.correctcsx = graphSe.snapIt ? this.spts[0] : this.pts[0];
			 this.correctcys = graphSe.snapIt ? this.spts[1] : this.pts[1];


			 if( this.pts.length >= 2)
			 {  
				 this.correctcxm = graphSe.snapIt ? this.spts[2] : this.pts[2];
				 this.correctcym = graphSe.snapIt ? this.spts[3] : this.pts[3];
			 }

			 if( this.pts.length >= 3)
			 {  
				 this.correctcxe = graphSe.snapIt ? this.spts[4] : this.pts[4];
				 this.correctcye = graphSe.snapIt ? this.spts[5] : this.pts[5];
			 }

		 } 	 
		 
		 document.getElementById('cxspointc').value = this.correctcsx;
		 document.getElementById('cyspointc').value = this.correctcys;
		 document.getElementById('cxmpointc').value = this.correctcxm;
		 document.getElementById('cympointc').value = this.correctcym;
		 document.getElementById('cxepointc').value = this.correctcxe;
		 document.getElementById('cyepointc').value = this.correctcye;
		 
     }     


	this.SetSettings();


}

function Polyline( clr, fit, szz, aa )
{
     this.what = "poly";
     this.myGmloc = graphMe.length;
     this.color = clr;
     this.width = szz;
     this.fillit = fit;
     this.pts = [ ];
     this.spts = [ ];
     this.doFill = false;
     this.myPath;
     this.showControl = false;
     this.inside = false;
     this.dragState = "off";
     this.dragPt = -1;
     this.dragDxDy = { dx: 0, dy: 0 };
     this.plumbLine = false;
     this.labelLine = false;
 	 
 	 this.studentdrag = null;

     this.studentcorrectlabel = "a";
     
     this.iscorrect = null;
     this.correctgraph;
     this.labelcorrect;
	 this.correctlabel = "b";

     
     this.ghost = null;
     
     this.correct = [ ];
	 this.correctTolerance = 4;
	 this.correctFeedback = "Area Correct!";
	 this.notCorrectFeedback = "Area Not Correct!";
	 this.feedback = "";

	 this.interactive = graphSe.mode=="correct" ? true : false;;
	 this.precise = null;
	 this.evalshift = null;
	 this.labelam = '';
	 this.taelement = 'None';
     this.relselects = '';
     
     this.mode = graphSe.mode;

     this.ahtml = '';
     this.phtml = '';  
	
     this.closed = false;
     this.closedo = false;
	 
	 this.relementlabel="None";
     this.elementlabel="None";
     this.bookcolor="No";
     this.iscurrent=true;

     apoints++;
     this.label = "A"+apoints;
     this.labelvalue = apoints;

	 this.cc = 'rgba(0, 0, 0, 1)';
	 this.ccus = 'rgba(0, 0, 0, .5)';

	 this.areapoints = 1;
	 this.areapointso = 1;

	 this.cc = 'rgba(0, 0, 0, 1)';
	 this.ccus = 'rgba(0, 0, 0, .5)';
	 
	 this.acceptedArea = aa != undefined ? aa : false;

	 this.checkboxes = [true, true, true, true, true];
	 this.customlabels = [];

	 this.clabeloffset = "102px";
	 this.elabelmode = "";

	 this.SetColor = function ( )
	 {
	 	if(this.elementlabel=="None") {this.cc = 'rgba(0, 0, 0, 1)'; this.ccus = 'rgba(0, 0, 0, .5)';}
	 	else if(this.elementlabel=="PPF" && this.bookcolor=="Yes") {this.cc = 'rgba(170, 95, 166, 1)'; this.ccus = 'rgba(170, 95, 166, .5)';}
	 	else if(this.elementlabel=="Demand" && this.bookcolor=="Yes") {this.cc = 'rgba(0, 131, 173, 1)'; this.ccus = 'rgba(0, 131, 173, .5)';}
	 	else if(this.elementlabel=="Supply" && this.bookcolor=="Yes") {this.cc = 'rgba(219, 92, 28, 1)'; this.ccus = 'rgba(219, 92, 28, .5)';}
	 	else if(this.elementlabel=="Fixed Cost" && this.bookcolor=="Yes") {this.cc = 'rgba(188, 189, 192, 1)'; this.ccus = 'rgba(188, 189, 192, .5)';}
	 	else if(this.elementlabel=="Indifference" && this.bookcolor=="Yes") {this.cc = 'rgba(247, 147, 29, 1)'; this.ccus = 'rgba(247, 147, 29, .5)';}
	 	else if(this.elementlabel=="Marginal Cost" && this.bookcolor=="Yes") {this.cc = 'rgba(247, 147, 29, 1)'; this.ccus = 'rgba(247, 147, 29, .5)';}
	 	else if(this.elementlabel=="Marginal Revenue" && this.bookcolor=="Yes") {this.cc = 'rgba(35, 31, 32, 1)'; this.ccus = 'rgba(35, 31, 32, .5)';}
	 	else if(this.elementlabel=="Total Cost" && this.bookcolor=="Yes") {this.cc = 'rgba(219, 92, 28, 1)'; this.ccus = 'rgba(219, 92, 28, .5)';}
	 	else if(this.elementlabel=="Variable Cost" && this.bookcolor=="Yes") {this.cc = 'rgba(238, 165, 122, 1)'; this.ccus = 'rgba(238, 165, 122, .5)';}
	 	else if(this.elementlabel=="Consumer Surplus" && this.bookcolor=="Yes") {this.cc = 'rgba(184, 228, 245, 1)'; this.ccus = 'rgba(184, 228, 245, .5)';}
	 	else if(this.elementlabel=="Producer Surplus" && this.bookcolor=="Yes") {this.cc = 'rgba(249, 176, 160, 1)'; this.ccus = 'rgba(249, 176, 160, .5)';}
	 	else if(this.elementlabel=="Deadweight Loss" && this.bookcolor=="Yes") {this.cc = 'rgba(254, 216, 119, 1)'; this.ccus = 'rgba(254, 216, 119, .5)';}
	 	else if(this.elementlabel=="Loss" && this.bookcolor=="Yes") {this.cc = 'rgba(249, 176, 160, 1)'; this.ccus = 'rgba(249, 176, 160, .5)';}
	 	else if(this.elementlabel=="Revenue/Profit" && this.bookcolor=="Yes") {this.cc = 'rgba(219, 223, 167, 1)'; this.ccus = 'rgba(219, 223, 167, .5)';}
	 	else {this.cc = 'rgba(0, 0, 0, 1)'; this.ccus = 'rgba(0, 0, 0, .5)';}
	 }
 
 	this.setStudentColor = function ( )
	{
		if(this.studentcorrectlabel=="None") {this.cc = 'rgba(0, 0, 0, 1)'; this.ccus = 'rgba(0, 0, 0, .5)';}
		else if(this.studentcorrectlabel=="PPF") {this.cc = 'rgba(170, 95, 166, 1)'; this.ccus = 'rgba(170, 95, 166, .5)';}
		else if(this.studentcorrectlabel=="Demand") {this.cc = 'rgba(0, 131, 173, 1)'; this.ccus = 'rgba(0, 131, 173, .5)';}
		else if(this.studentcorrectlabel=="Supply") {this.cc = 'rgba(219, 92, 28, 1)'; this.ccus = 'rgba(219, 92, 28, .5)';}
		else if(this.studentcorrectlabel=="Fixed Cost") {this.cc = 'rgba(188, 189, 192, 1)'; this.ccus = 'rgba(188, 189, 192, .5)';}
		else if(this.studentcorrectlabel=="Indifference") {this.cc = 'rgba(247, 147, 29, 1)'; this.ccus = 'rgba(247, 147, 29, .5)';}
		else if(this.studentcorrectlabel=="Marginal Cost") {this.cc = 'rgba(247, 147, 29, 1)'; this.ccus = 'rgba(247, 147, 29, .5)';}
		else if(this.studentcorrectlabel=="Marginal Revenue") {this.cc = 'rgba(35, 31, 32, 1)'; this.ccus = 'rgba(35, 31, 32, .5)';}
		else if(this.studentcorrectlabel=="Total Cost") {this.cc = 'rgba(219, 92, 28, 1)'; this.ccus = 'rgba(219, 92, 28, .5)';}
		else if(this.studentcorrectlabel=="Variable Cost") {this.cc = 'rgba(238, 165, 122, 1)'; this.ccus = 'rgba(238, 165, 122, .5)';}
	 	else if(this.studentcorrectlabel=="Consumer Surplus") {this.cc = 'rgba(184, 228, 245, 1)'; this.ccus = 'rgba(184, 228, 245, .5)';}
	 	else if(this.studentcorrectlabel=="Producer Surplus") {this.cc = 'rgba(249, 176, 160, 1)'; this.ccus = 'rgba(249, 176, 160, .5)';}
	 	else if(this.studentcorrectlabel=="Deadweight Loss") {this.cc = 'rgba(254, 216, 119, 1)'; this.ccus = 'rgba(254, 216, 119, .5)';}
	 	else if(this.studentcorrectlabel=="Loss") {this.cc = 'rgba(249, 176, 160, 1)'; this.ccus = 'rgba(249, 176, 160, .5)';}
	 	else if(this.studentcorrectlabel=="Revenue/Profit") {this.cc = 'rgba(219, 223, 167, 1)'; this.ccus = 'rgba(219, 223, 167, .5)';}
		else {this.cc = 'rgba(0, 0, 0, 1)'; this.ccus = 'rgba(0, 0, 0, .5)';}
	}
	     
     
     this.DrawMe = function( ctx )
     {
          if( graphSe.mode != "correct" && graphSe.mode != "student" && graphSe.mode != this.mode 
             || (this.mode == 'correct' && graphSe.mode == "student") ) return;
             
          var clr = this.iscurrent == true ? this.cc: this.ccus;
          
          if( graphSe.boo && this.ghost && this.mode != "correct"  ) this.DrawGhost( );
          
          this.PathMe( );
        
          this.path.strokeColor = clr;
          this.path.strokeWidth = 2;
        
          if( this.doFill ) { this.path.fillColor = clr; this.path.closed = true; }
        
          if( this.iscurrent ) this.ControlPoints( );
    
          if( this.plumbLine ) this.PlumbLine( );

          if( this.labelLine ) this.LabelLine( );
     }
     
     this.DrawGhost = function( )
     {
        var gh = this.ghost;
        var ghPath = new paper.Path( );
        ghPath.strokeColor = gh.clr;
        ghPath.strokeWidth = this.width;
        ghPath.dashArray = [ 2, 2];
        
        for( var p = 0, ln = gh.pts.length; p < ln; p += 2 )
        {
            var xpt = graphSe.ConvertXgToXpx( graphSe.snapIt ? gh.spts[p] : gh.pts[p] );
            var ypt = graphSe.ConvertYgToYpx( graphSe.snapIt ? gh.spts[p+1] : gh.pts[p+1] );
                ghPath.add( new paper.Point(xpt, ypt) );
        }

		pt = graphSe.snapIt ? { x: this.ghost.spts[0], y: this.ghost.spts[1] } : { x: this.ghost.pts[0], y: this.ghost.pts[1] };
		
		var xoffset = -10;
		var yoffset = -10;

		pt.x = graphSe.ConvertXgToXpx(pt.x)+xoffset;
		pt.y = graphSe.ConvertYgToYpx(pt.y)+yoffset;


		if(this.labelLine==true)
		{
			text = new paper.PointText(new paper.Point(pt.x, pt.y));
			text.justification = 'center';
			text.fillColor = this.ccus;
			text.content = this.label;
		}	
        
    }
    
    this.TrackAlong = function( lbl )
    {
         if( lbl != undefined ) this.trackAlongLabel = lbl;
     
         this.trackElement = graphSe.FindInGraph( this.trackAlongLabel );
         
         if( this.trackElement != null )
         {
             var t = this.trackElement;
             this.trackAng = Math.atan2(t.yeg - t.ysg, t.xeg - t.xsg);
         }
     }
     
     this.Track = function( dist )
     {  
         var ang = this.trackAng;
         var dx = Math.cos(ang)*dist;
         var dy = Math.sin(ang)*dist;
         
         return { sx: dx, sy: dy };
     }
    
    this.CorrectToDesigner = function( )
    {
         if( this.ghost )
         {
             var gh = this.ghost;
             for( var i = 0, ln = gh.pts.length; i < ln; i++ )
             {
                 this.pts[i] = gh.pts[i];
                 this.spts[i] = gh.spts[i];
             }
         }
     }
     
     this.DesignerToCorrect = function( )
     {
         if( this.correct.length > 0 )
         {
             var cr = this.correct[0];
             for( var i = 0, ln = cr.pts.length; i < ln; i++ )
             {
                 this.pts[i] = cr.pts[i];
                 this.spts[i] = cr.spts[i];
             }
         } 
     }
     
     this.AddPoint = function( pt )
     {
          pt.x += 4; pt.y += 4;
          
          var ptxg = graphSe.ConvertXpxToXg(pt.x);
          var ptyg = graphSe.ConvertYpxToYg(pt.y)
          this.pts.push( ptxg );
          this.pts.push( ptyg );
        
          this.spts.push( graphSe.SnapX( ptxg) );
          this.spts.push( graphSe.SnapY( ptyg) );
          
          var n = this.pts.length;
          
          this.PathMe( );
        
          if( n > 4 )
          {
              var p0 = graphSe.ConvertXgToXpx(graphSe.snapIt ? this.spts[0] : this.pts[0]);
              var p1 = graphSe.ConvertYgToYpx(graphSe.snapIt ? this.spts[1] : this.pts[1]);
              var dx = p0 - pt.x;
              var dy = p1 - pt.y;
              if( (dx*dx + dy*dy) < 32 ) 
              { 
                  this.pts[n-2] = this.pts[0];
                  this.pts[n-1] = this.pts[1];
                  this.spts[n-2] = this.spts[0];
                  this.spts[n-1] = this.spts[1];
                  this.closed = true; 
                  this.doFill = true; 
                  //if( !this.ghost ) this.GhostMe( );
                  thePoly = null;
                  
                  if( graphSe.mode == "correct" ) 
                  {
                      this.CorrectMe( ["relative","area",drawAcceptedArea.label] );
                      this.acceptedArea = true;
                  }
                  
                  if( graphSe.mode == "student" ) this.CheckIsCorrect( "drawing" );
              }
          }
          
	  this.SetElementPoints( );

     }
     
     this.DragMe = function( mpt, drgSt )
     {
        if( drgSt != undefined ) this.dragState = drgSt;
         
        switch( this.dragState )
        {
            case "off":
 	            if( graphSe.boo && this.interactive && !this.ghost ) this.GhostMe( );

                dragObj = this;
                this.dragstart = mpt;
                this.dragDxDy = { dx: 0, dy: 0 };
                for( var i = 0, ln = this.pts.length - 2; i < ln && this.dragState == "off"; i += 2 )
                {
                    var pt = graphSe.snapIt ? { x: this.spts[i], y: this.spts[i+1] } : { x: this.pts[i], y: this.pts[i+1] };
                    if( graphSe.HitPt(mpt,pt.x,pt.y,graphSe.handleRadius) ) { this.dragState = "dragPoint"; this.dragPt = i; }
                }
                    
                if( this.dragState == "off" ) this.dragState = "dragPoly";
                if(graphSe.mode=="correct")Precise(true);
                if(graphSe.mode=="student")this.studentdrag=true;
                break;
                 
            case "dragPoint":
                var i = this.dragPt
                
                var dsxg = graphSe.ConvertXpxToXg( this.dragstart.x ) - graphSe.ConvertXpxToXg( mpt.x );
	            var dsyg = graphSe.ConvertYpxToYg( this.dragstart.y ) - graphSe.ConvertYpxToYg( mpt.y );
                this.pts[i] -= dsxg;
                this.pts[i+1] -= dsyg;
                //this.pts[i] = graphSe.ConvertXpxToXg( mpt.x );
	            //this.pts[i+1] = graphSe.ConvertYpxToYg( mpt.y );
	            this.SnapMe( );
	            if( i = 0 ) 
	            { 
	                var n = this.pts.length;
	                this.pts[n-2] = this.pts[0];
                    this.pts[n-1] = this.pts[1];
                    this.spts[n-2] = this.spts[0];
                    this.spts[n-1] = this.spts[1];
                }
	            this.SetElementPoints( );

	     		//if(graphSe.mode=="correct") this.SetCorrectPoints();
	            
	            this.dragstart = mpt;
	            this.dragDxDy = { dx: this.dragDxDy.dx += dsxg, dy: this.dragDxDy.dy += dsyg }
	            break;
	             
	        case "dragPoly":
	            
	             //var dsxg = graphSe.ConvertXpxToXg( this.dragstart.x ) - graphSe.ConvertXpxToXg( mpt.x );
	             //var dsyg = graphSe.ConvertYpxToYg( this.dragstart.y ) - graphSe.ConvertYpxToYg( mpt.y );
	            
	             var dsxg = graphSe.ConvertXpxToXg( mpt.x ) - graphSe.ConvertXpxToXg( this.dragstart.x );
	             var dsyg = graphSe.ConvertYpxToYg( mpt.y ) - graphSe.ConvertYpxToYg( this.dragstart.y ); 
	             
	             if( this.taelement != "None" )
	             {
	                 this.TrackAlong( );
	                 var s = this.Track( dsxg );
	                 dsxg = s.sx;
	                 dsyg = s.sy;
	             }
	            
	            for( var i = 0, ln = this.pts.length; i < ln; i += 2 )
                { 
                    this.pts[i] += dsxg; 
                    this.pts[i+1] += dsyg;
                }
                this.SnapMe( );
	             
	            this.SetElementPoints( );

	     		if(graphSe.mode=="correct") 
	     		{
	     			this.SetCorrectPoints();
	     			this.SetSettings();
	     		}	
	             
	            this.dragstart = mpt;
	            this.dragDxDy = { dx: this.dragDxDy.dx -= dsxg, dy: this.dragDxDy.dy -= dsyg };
	            this.dragPt = -1;
	            break;
	             
	        case "drop":
	            dragObj = null;
	            this.dragState = "off";
	            this.dragPt = -1;
	            if( this.dragDxDy.dx != 0 || this.dragDxDy.dy != 0 )
	            {
	                graphSe.OpsMoveElement( this, this.dragPt, -this.dragDxDy.dx, -this.dragDxDy.dy );
	                if( graphSe.mode == "correct" ) this.CorrectMe( );
	                if( graphSe.mode == "student" ) this.CheckIsCorrect( );
	                if( graphSe.mode == "designer" && this.interactive ) this.GhostMe();
	            }
	            break;
        }
     }
     this.IsDone = function( ) 
     {
         return this.doFill;
     }
     
     this.HitMe = function( mpt )
     {  
         var hitCp = false;
         var myline = new paper.Path.Line( new paper.Point(0,0),new paper.Point(mpt.x, mpt.y), 2);
        
         var gii = this.path.getIntersections( myline );
         var giiln = gii.length;
        
         if( !(giiln%2) )
         {
             for( var i = 0, ln = this.pts.length; i < ln && !hitCp; i++ )
             {
                 var px = graphSe.snapIt ? this.spts[i] : this.pts[i];
                 var py = graphSe.snapIt ? this.spts[i+1] : this.pts[i+1];
                 
                 hitCp = graphSe.HitPt(mpt, px, py, graphSe.handleRadius); 
             }
         }
         
         return giiln%2 || hitCp;
     }
     
     this.MoveMe = function( ipt, dx, dy )
     {
         if( ipt > -1 )
         {
             this.pts[ipt] -= dx;
             this.pts[ipt+1] -= dy;
         }
         else
         {
             for( var i = 0, ln = this.spts.length; i < ln; i +=2 )
             {
                 this.pts[i] -= dx;
                 this.pts[i+1] -= dy;
             }
         }
         this.SnapMe( );
     }
     
     this.ControlMe = function( tf )
     {
         this.showControl = tf; 
     }
     
     this.ControlPoints = function( )
     {
     
         for( var i = 0, ln = this.doFill ? this.pts.length - 2 : this.pts.length; i < ln; i += 2 )
         {
             var px = graphSe.ConvertXgToXpx(graphSe.snapIt ? this.spts[i] : this.pts[i]);
             var py = graphSe.ConvertYgToYpx(graphSe.snapIt ? this.spts[i+1] : this.pts[i+1]);
             
             var ps = new paper.Path.Circle(new paper.Point(px, py), graphSe.handleRadius);
             ps.strokeColor = graphSe.handleColor;
             ps.strokeWidth = 1;
         }
     }
    
     this.PathMe = function( )
     {
        this.path = new paper.Path( );
        
        for( var p = 0, ln = this.doFill ? this.pts.length - 2 : this.pts.length ; p < ln; p += 2 )
        {
             var xpt = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.spts[p] : this.pts[p] );
             var ypt = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.spts[p+1] : this.pts[p+1] );
             this.path.add( new paper.Point(xpt, ypt) );
        }
        
        if( this.closed ) this.path.closed = true;
        
        
     }
     
     this.SnapMe = function( )
     {
         for( var i = 0, ln = this.spts.length; i < ln; i +=2 )
         {
             this.spts[i] = graphSe.SnapX( this.pts[i] );
             this.spts[i+1] = graphSe.SnapY( this.pts[i+1] );
         }
     }
     
     this.CorrectMe = function( type )
     {
         var lbl = this.label;
         var ca = this.correct;
         
         if( type != undefined )
         {
             if( type[0] == "relative"  && type[1] == "area" )
             {
                 var ele = graphSe.FindInGraph(type[2]);
                 var ca = ele.correct;
                 if( ele.label[0] == 'A' ) 
                 {  
                     var aa = this.label.split("");
                     aa[0] = "=";
                     lbl = aa.join("");
                 }
                 else lbl = this.label;
             }

         }
         
         ca[0] = { type: type == undefined ? "precise" : type, lbl: lbl, pts: [ ], spts: [ ] };
         for( var i = 0, ln = this.pts.length; i < ln; i++ ) 
         {
             ca[0].pts[i] = this.pts[i];
             ca[0].spts[i] = this.spts[i];
         }
     }
     
     this.CheckIsCorrect = function( mode )
     {
         var tst = true;
         if( this.correct && this.correct[0] != undefined && mode == undefined )
         {
             var typ = this.correct[0].type;
             var area = (typ != undefined) && (typ.length == 3);
             if( typ == "precise" || typ == undefined || area  )
             {
                 var ca = this.correct[0];
                 switch( ca.lbl[0] )
                 {
                     case 'A':
                         var pca = graphSe.snapIt ? this.correct[0].spts : this.correct[0].pts;
                         for( var i = 0, ssq = 0, tst = true, ln = this.pts.length; i < ln; i += 2 )
                         {
                             var px = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.spts[i] : this.pts[i] );
                             var py = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.spts[i+1] : this.pts[i+1] );
                             var cx = graphSe.ConvertXgToXpx( pca[i] );
                             var cy = graphSe.ConvertYgToYpx( pca[i+1] );
                             var dpx = px - cx;
                             var dpy = py - cy;
             
                             tst = tst && (Math.sqrt(dpx*dpx + dpy*dpy) < this.correctTolerance) ;
                         }
                         break;
                     
                     case '=':
                         var aa = ca.lbl.split("");
                         aa[0] = "A";
                         var lbl = aa.join("");
                         var aao = graphSe.FindInGraph( lbl );
                         for( var i = 0, ssq = 0, tst = true, ln = this.pts.length; i < ln; i += 2 )
                         {
                             var px = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.spts[i] : this.pts[i] );
                             var py = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.spts[i+1] : this.pts[i+1] );
                         
                             tst = tst && aao.path.contains(new paper.Point(px,py));
                         }
                         break;
                
                     default:
                         tst = false;
                         break; 
                 }
             }
             else if( typ.length == 2 )
             {
                 var pca = graphSe.snapIt ? this.spts : this.pts;
                 for( var i = 0, ln = pca.length-2, cmn = 10000, cmx = 0; i < ln; i += 2 )
                 {
                     var xpx = graphSe.ConvertXgToXpx( pca[i] );
                     if( xpx < cmn ) cmn = xpx;
                     else if( xpx > cmx ) cmx = xpx;
                 }
                 
                 rele = graphSe.FindInGraph( this.relementlabel );
                 
                 if( rele instanceof Polyline )
                 {  
                     if( rele == this ) rele = this.correct[0];
                     
                     for( var i = 0, ln = rele.pts.length-2, xmn = 10000, xmx = 0; i < ln; i += 2 )
                     {
                         var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.spts[i] : rele.pts[i] );
                         if( xpx < xmn ) xmn = xpx;
                         else if( xpx > xmx ) xmx = xpx;
                     }
                
                     var lfrt = typ[1];
                     if( lfrt == "left" && cmx < xmn ) tst = true;
                     else if( lfrt == "right" && cmn > xmx ) tst = true;
                     else tst = false;
                 }
                 if( rele instanceof Point )
                 {  
                     var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.sxg : rele.xg );
                
                     var lfrt = typ[1];
                     if( lfrt == "left" && cmx < xpx ) tst = true;
                     else if( lfrt == "right" && cmn > xpx ) tst = true;
                     else tst = false;
                 }
                 if( rele instanceof Line )
                 {  
                     var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.sxsg : rele.xsg );
                     var xpxe = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.sxeg : rele.xeg );
                     
                     var xmn = Math.min( xpx, xpxe );
                     var xmx = Math.max( xpx, xpxe );
                
                     var lfrt = typ[1];
                     if( lfrt == "left" && cmx < xmn ) tst = true;
                     else if( lfrt == "right" && cmn > xmx ) tst = true;
                     else tst = false;
                 }
                 if( rele instanceof Curve )
                 {  
                     var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.spts[0] : rele.pts[0] );
                     var xpm = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.spts[2] : rele.pts[2] );
                     var xpe = graphSe.ConvertXgToXpx( graphSe.snapIt ? rele.spts[4] : rele.pts[4] );
                     
                     var xmn = Math.min( xpx, xpm, xpe );
                     var xmx = Math.max( xpx, xpm, xpe );
                
                     var lfrt = typ[1];
                     if( lfrt == "left" && cmx < xmn ) tst = true;
                     else if( lfrt == "right" && cmn > xmx ) tst = true;
                     else tst = false;
                 }
             }
         }
         else if( mode == "drawing" )
         {
             for( var i = 0, tst = false, ln = graphMe.length ; i < ln && !tst; i++ )
             {
                 var gi = graphMe[i];
                 if( gi.mode == "correct" && gi.what == this.what )
                 {
                     for( var i = 0, ssq = 0, tst = true, ln = this.pts.length; i < ln; i += 2 )
                     {
                         var px = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.spts[i] : this.pts[i] );
                         var py = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.spts[i+1] : this.pts[i+1] );
                         var cx = graphSe.ConvertXgToXpx( graphSe.snapIt ? gi.spts[i] : gi.pts[i] );
                         var cy = graphSe.ConvertYgToYpx( graphSe.snapIt ? gi.spts[i+1] : gi.pts[i+1] );
                         var dpx = px - cx;
                         var dpy = py - cy;
             
                         tst = tst && (Math.sqrt(dpx*dpx + dpy*dpy) < this.correctTolerance);
                     }
                 }
             }
         }
 
         this.feedback = tst ? this.correctgraph=true : this.correctgraph=false;

         
         if(this.requiredlabel)
         {
         	if(this.correctlabel==this.studentcorrectlabel) 
         	{
         		this.labelcorrect=true;
         	} else {
         		this.labelcorrect=false;
         	}		
         	
         } else 
         {
         	this.labelcorrect=true;
         }
         
         if(this.correctgraph==true && this.labelcorrect==true)
         {
         	this.iscorrect="<span style='color:green;'>Correct</span>";
         }	else {
         	this.iscorrect="<span style='color:red'>Not Correct</span>";
         }	
         
         //SayFeedback( this.feedback );
     }
    
     
     this.GhostMe = function( )
     {
         this.ghost = { clr: "lightgray", wd: this.width, pts: [ ], spts: [ ]};
         for( var i = 0, ln = this.pts.length; i < ln; i++ ) 
         {
             this.ghost.pts[i] = this.pts[i];
             this.ghost.spts[i] = this.spts[i];
         }
     }
     
     this.PlumbMe = function( tf )
     {
         this.plumbLine = tf;
     }
    
    this.PlumbLine = function( )
    {
         this.PathMe( );
         var ln = graphMe.length;
         for( var j = 0; j < ln; j++ ) 
         {
              var gj = graphMe[j];
              if( gj == this ) continue;
              
              gj.PathMe();
              var gii = this.path.getIntersections( gj.path );
              var giiln = gii.length;
              if( (gj instanceof Point) && giiln > 0 )
              {
                   var px = graphSe.ConvertXgToXpx( graphSe.snapIt ? gj.sxg : gj.xg );
                   var py = graphSe.ConvertYgToYpx( graphSe.snapIt ? gj.syg : gj.yg );
                   
                   var clr = 'lightblue';
                   DrawLine( clr, this.width, px, py, 0, py, [4, 4] ); 
                   DrawLine( clr, this.width, px, py, px, can.height-3, [4, 4] );
                   
                   ctx2.fillStyle = "grey";
			       ctx2.fillText(Math.round(graphSe.ConvertYpxToYg(py)*10)/10,55,py+10);
                  
		           ctx2.fillStyle = "grey";
			       ctx2.fillText(Math.round(graphSe.ConvertXpxToXg(px)*10)/10,px+54,395);
              }
              else
              {
                   for (var k = 0; k < giiln; k++)
                   {
                        var clr = 'grey';
                        var giik = gii[k];
                        DrawLine( clr, this.width, giik.point.x, giik.point.y, 0, giik.point.y, [4, 4] );
                        DrawLine( clr, this.width, giik.point.x, giik.point.y, giik.point.x, can.height-3, [4, 4] );

  						var text = new paper.PointText(new paper.Point(15, giik.point.y-10));
						text.justification = 'center';
						text.fillColor = "grey";
						text.fontSize = 10
						text.content = Math.round(graphSe.ConvertYpxToYg(giik.point.y)*10)/10;

  						var text = new paper.PointText(new paper.Point(giik.point.x+14, 375));
						text.justification = 'center';
						text.fillColor = "grey";
						text.fontSize = 10
						text.content = Math.round(graphSe.ConvertXpxToXg(giik.point.x)*10)/10


			            /*ctx2.fillStyle = "grey";
			            ctx2.fillText(Math.round(graphSe.ConvertYpxToYg(giik.point.y)*10)/10,55,giik.point.y+10);
                  
		                ctx2.fillStyle = "grey";
			            ctx2.fillText(Math.round(graphSe.ConvertXpxToXg(giik.point.x)*10)/10,giik.point.x+54,395);	*/	                   		  
                   }
              }
         }
     }
 
     this.LabelMe = function( tf )
     {
         this.labelLine = tf;
     }     

     this.LabelLine = function(  )
     {
		pt = graphSe.snapIt ? { x: this.spts[0], y: this.spts[1] } : { x: this.pts[0], y: this.pts[1] };
		
		var xoffset = -10;
		var yoffset = -10;

		pt.x = graphSe.ConvertXgToXpx(pt.x)+xoffset;
		pt.y = graphSe.ConvertYgToYpx(pt.y)+yoffset;
		
        var clr = this.iscurrent == true ? this.cc: this.ccus;

		//console.log(clr);
		/*ctx.fillStyle = 'red';
		ctx.font="14px sans-serif";
		ctx.fillText(this.label,pt.x,pt.y);
		ctx.font="10px sans-serif";*/

		var templabel;
		if(graphSe.mode=="correct"&&this.dragstart!=undefined)
		{
			templabel = this.labelam;
		} else
		{
			templabel = this.label;
		}
			
		if(graphSe.mode=="designer")
		{
			templabel = this.label;
		}	

		if(graphSe.mode=="student"&&this.studentdrag!=null)
		{
			templabel = this.labelam;
		}				

		
		var text = new paper.PointText(new paper.Point(pt.x, pt.y));
		text.justification = 'center';
		text.fillColor = clr;
		text.content = templabel;
		
	}  

	 this.checkBoxes = function()
	 {
	 	if(document.getElementById('consumersurplus').checked) {this.checkboxes[0]=true} else {this.checkboxes[0]=false};
	 	if(document.getElementById('deadweightloss').checked) {this.checkboxes[1]=true} else {this.checkboxes[1]=false};
	 	if(document.getElementById('loss').checked) {this.checkboxes[2]=true} else {this.checkboxes[2]=false};
	 	if(document.getElementById('producersurplus').checked) {this.checkboxes[3]=true} else {this.checkboxes[3]=false};
	 	if(document.getElementById('revenueprofit').checked) {this.checkboxes[4]=true} else {this.checkboxes[4]=false};

		for(var i=0; i<this.customlabels.length; i++)
		{
		 	var str = this.customlabels[i];
		 	var lwr = str.toLowerCase();
		 	str = lwr.replace(/\s+/g, '');

			if(document.getElementById(str).checked) {this.checkboxes[4+i+1]=true} else {this.checkboxes[8+i+1]=false};	
				 	
		 	//html += '<input type="checkbox" id="'+str+'" checked> '+this.customlabels[i]+'<br>'
		 	//this.checkboxes[i+9] = false;
		}


     	this.CorrectLabelDropdown(); 

     	//this.SetSettings();

	 }
	 
	 this.checkBoxHTML = function()
	 {
	 	var html = '';
	 	
	 	if(this.checkboxes[0])
	 	{
	 		html += '<input type="checkbox" id="consumersurplus" checked> Consumer Surplus<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="consumersurplus"> Consumer Surplus<br>'	 	
	 	}
	 	
	 	if(this.checkboxes[1])
	 	{
	 		html += '<input type="checkbox" id="deadweightloss" checked> Deadweight Loss<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="deadweightloss"> Deadweight Loss<br>'	 	
	 	}	 	
	 	
	 	if(this.checkboxes[2])
	 	{
	 		html += '<input type="checkbox" id="loss" checked> Loss<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="loss"> Loss<br>'	 	
	 	}
	 	
	 	if(this.checkboxes[3])
	 	{
	 		html += '<input type="checkbox" id="producersurplus" checked> Producer Surplus<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="producersurplus"> Producer Surplus<br>'	 	
	 	}
	 	
	 	if(this.checkboxes[4])
	 	{
	 		html += '<input type="checkbox" id="revenueprofit" checked> Revenue/Profit<br>'
	 	} else
	 	{
	 		html += '<input type="checkbox" id="revenueprofit"> Revenue/Profit<br>'	 	
	 	}
	 		 	

		for(var i=0; i<this.customlabels.length; i++)
		{
		 	var str = this.customlabels[i];
		 	var lwr = str.toLowerCase();
		 	str = lwr.replace(/\s+/g, '');
		 	
		 	html += '<input type="checkbox" id="'+str+'" checked> '+this.customlabels[i]+'<br>'
		 	//this.checkboxes[i+9] = false;
		}

	 	this.checkboxhtml = html;
	 	
	 	//document.getElementById('checkform').innerHTML = this.checkboxhtml;
	 }

     this.addLabel = function()
     {
     	this.customlabels.push(document.getElementById('newlabel').value)
     	
     	var str = document.getElementById('newlabel').value;
		var lwr = str.toLowerCase();
		str = lwr.replace(/\s+/g, '');
     	
     	this.checkBoxHTML();
     	
     	document.getElementById('checkform').innerHTML = this.checkboxhtml;
     	
		this.CorrectLabelDropdown();

		var fstr = document.getElementById("cltext2").style.paddingTop;
		var fstr2 = fstr.split("px");
		fstr = fstr2[0];
		fstr = Number(fstr)+20;
		document.getElementById("cltext2").style.paddingTop = fstr+"px";
		this.clabeloffset = fstr+"px";	
     }	

     this.CorrectLabelDropdown = function ()
     {
     		var html = '<option value="None">None</option>'

			if(document.getElementById('consumersurplus').checked) {html += '<option value="Consumer Surplus">Consumer Surplus</option>'} else {};
			if(document.getElementById('deadweightloss').checked) {html += '<option value="Deadweight Loss">Deadweight Loss</option>'} else {};
			if(document.getElementById('loss').checked) {html += '<option value="Loss">Loss</option>'} else {};
			if(document.getElementById('producersurplus').checked) {html += '<option value="Producer Surplus">Producer Surplus</option>'} else {};
			if(document.getElementById('revenueprofit').checked) {html += '<option value="Revenue/Profit">Revenue/Profit</option>'} else {};

			for(var i=0; i<this.customlabels.length; i++)
			{
				var str = this.customlabels[i];
				var lwr = str.toLowerCase();
				str = lwr.replace(/\s+/g, '');
			
				if(document.getElementById(str)) {
					if(document.getElementById(str).checked) {html += '<option value="'+this.customlabels[i]+'">'+this.customlabels[i]+'</option>'} else {}
				}
				//this.checkboxes[i+9] = false;
			}
       		
     		this.clselects = html;

     	    document.getElementById("cldropdown").innerHTML = html;		
		 	document.getElementById('cldropdown').value = this.correctlabel;

     }     
     
     this.SetSettings = function( )
     {
     	 //this.CalculateSlope();
     	 //this.LineUpdate();

		 if(this.acceptedArea) return;

     	 this.TrackAgainstDropdown();   
     	 this.RelativeDropdown();    
      	 this.checkBoxHTML();
    	      	 
     	 $('#bottomtools').removeClass("hide");
     	 
     	 var html = '<div class="sectionhead"><span id="elementhead">Element Settings </span><button class="glyphicon glyphicon-left" aria-hidden="true" style="margin-left: 30px; background: none; border: none;" onclick="leftArrow();"></button><span id="toplabel'+this.labelvalue+'" class="elementid">'+this.label+'</span><button class="glyphicon glyphicon-right" aria-hidden="true" onclick="rightArrow();" style="background: none; border: none;"></span></div>'
     	 html += '<div class="hrm"></div>'
		 html += '<div class="row" style="margin-left: 20px;">'
		 html += '<div class="col-sm-6">'
     	 html += '<div id="designertools">'
		 html += '<div class="tool">Element Type</div>'
		 html += '<div class="tool"></div>'
		 html += '<div class="tool">Label</div>'
		 html += '<div class="tool">Show Label</div>'
		 html += '<div class="tool">Point 1</div>'
		 html += '<div id="alabels"></div>'
		 html += '<div class="tool">Show Plumbs</div>'
		 html += '</div>'
		 html += '</div>'
		 html += '<div class="col-sm-6" style="padding-top: 8px;">'
     	 html += '<div id="designerinputs">'
		 html += '<div class="styled-select"><select id="eldropdown" class="select-class" onchange="GetElement(this.value)"></span><option value="None">None</option><option value="Consumer Surplus">Consumer Surplus</option><option value="Deadweight Loss">Deadweight Loss</option><option value="Loss">Loss</option><option value="Producer Surplus">Producer Surplus</option><option value="Revenue/Profit">Revenue/Profit</option></select></div>'
		 html += '<button id="bcbutton" aria-hidden="true" onclick="bookColor();">Use Book Color <span class="glyphicon glyphicon-uncheckedmm"></span></button>'
		 html += '<div><input id="xlabel'+this.labelvalue+'" type="text" class="small-label" placeholder="'+this.label+'" onkeyup="labelUpdate(this.value)" maxlength="5"></div>'	  			
		 html += '<div><label class="switch tool"><input id="labeltoggle" type="checkbox" onclick="update();"><div class="slider"><span class="ontext">ON</span><span class="offtext">OFF</span></div></label></div>'
		 html += '<div>(<input id="cxpoint0" type="number" class="point-input point-input-area" value="" step="'+graphSe.xmax/Number(graphSe.wdPx)+'"  oninput="apUpdateNoFix(this.value, 0)">,<input id="cypoint0" type="number" class="point-input point-input-area" value="" step="'+graphSe.ymax/Number(385)+'" oninput="apUpdateNoFix(this.value, 1)" >)</div>'	  			
		 html += '<div id="apoints"></div>'
		 html += '<div><label class="switch tool"><input id="plumbtoggle" type="checkbox" onclick="update();"><div class="slider"><span class="ontext">ON</span><span class="offtext">OFF</span></div></label></div>'
		 html += '</div>'	  			
		 html += '</div>'	  			
	     html += '</div>'		

     	 $('#interactive').removeClass("hide");

     	 var html2 = '<div id="sectionpadding" class="sectionhead"></div>'
		 html2 += '<div class="row" style="margin-left: 20px;">'
		 html2 += '<div id="intleft" class="col-sm-6">'
		 html2 += '<button class="fake-radio" id="binteractive" onclick="Interactive(true);"> <div class="radio-off"><div id="binteractivero" class="radio-on hide"></div></div>Interactive</button><br>'
		 html2 += '<div id="ilabels" class="hide"><div class="tool">Label after move</div>'
		 html2 += '<div class="tool">Track against</div>'		 
		 html2 += '</div>'
		 html2 += '</div>'		 
		 html2 += '<div id="intright" class="col-sm-6">'
		 html2 += '<button class="fake-radio" id="bstatic" onclick="Interactive(false);"> <div class="radio-off"><div id="bstaticro" class="radio-on"></div></div>Static<br></button>'
		 html2 += '<div id="iinputs" class="hide"><div><input id="labelam" type="text" value="'+this.labelam+'" oninput="labelAMUpdate(this.value)" style="margin-top: 10px; width: 75px"></div>'	  			
		 html2 += '<div class="styled-select"><select id="tadropdown" class="select-class" onchange="TAElement(this.value)" value="'+this.taelement+'" style="margin-top:10px">'+this.taselects+'</select></div>'
		 html2 += '</div>'	
	     html2 += '</div>'	
		 html2 += '<div id="elabel" class="row hide">'
		 html2 += '<div class="col-sm-6">'
		 html2 += '<div class="tool"><strong>Evaluated on</strong></div>'		 
		 html2 += '</div>'	
		 html2 += '<div class="col-sm-6">'
		 html2 += '<div id="elabelmode" class="" style="margin-top: 11px;">Interaction</div>'		 		   			
		 html2 += '</div>'	
		 html2 += '</div>'	

		 var html3 = '<div class="row" style="margin-left: 20px;">'
		 html3 += '<div class="col-sm-6">'
		 html3 += '<button class="fake-radio" id="bprecise" onclick="Precise(true);"> <div class="radio-off"><div id="bprecisero" class="radio-on hide"></div></div>Precise</button><br>'
		 html3 += '<div id="precisetools" class="hide">'
		 html3 += '<div class="tool">Point 1</div>'
		 html3 += '<div id="alabelsc"></div>'
		 html3 += '</div>'
		 html3 += '<div id="relativetools" class="hide">'
		 html3 += '<div class="tool">Relative to:</div>'
		 html3 += '<div id="relativetools2" class="hide">'
		 html3 += '<div class="tool">Shift from origin</div>'
		 html3 += '</div>'
		 html3 += '<div id="drawarea" class="hide" style="width: 200px; margin-top: 10px; margin-left: 10px; position:relative; top: 10px;"><button type="button" class="btn btn-econ-sw5" onclick="DoAcceptedArea(gmloc-1)"><span class="glyphicon glyphicon-pentagon" aria-hidden="true"></span><img id="areashade" src="./images/areashade.png"></img></button><span style="padding-left: 5px;">Draw Accepted Area</span></div>'	
		 html3 += '</div>'	
		 html3 += '</div>'	
		 html3 += '<div class="col-sm-6">'
		 html3 += '<button class="fake-radio" id="brelative" onclick="Precise(false);"> <div class="radio-off"><div id="brelativero" class="radio-on"></div></div>Relative<br></button>'
		 html3 += '<div id="preciseinputs" class="hide" style="position:relative; top: 10px">'
		 html3 += '<div>(<input id="cxpoint0c" type="number" class="point-input point-input-area" value="" step="'+graphSe.xmax/Number(graphSe.wdPx)+'"  oninput="apUpdateNoFix(this.value, 0)">,<input id="cypoint0c" type="number" class="point-input point-input-area" value="" step="'+graphSe.ymax/Number(385)+'" oninput="apUpdateNoFix(this.value, 1)" >)</div>'	  			
		 html3 += '<div id="apointsc"></div>'
		 html3 += '</div>'	
		 html3 += '<div id="relativeinputs" class="hide">'
		 html3 += '<div class="styled-select" style="margin-top:9px"><select id="reldropdown" class="select-class" onchange="GetRelativeElement(this.value)"></span>'+this.relselects+'</select></div>'
		 html3 += '<div id="relativeinputs2" class="hide">'
		 html3 += '<button class="fake-radio" id="sleft" onclick="ShiftLeft();" style="margin-top:13px;"> <div class="radio-off"><div id="sleftro" class="radio-on hide"></div></div>Left</button><br>'
		 html3 += '<button class="fake-radio" id="sright" onclick="ShiftRight();" style="margin-top:0px;"> <div class="radio-off"><div id="srightro" class="radio-on hide"></div></div>Right</button><br>'
		 html3 += '</div>'	
		 html3 += '</div>'	
		 html3 += '</div>'	
		 html3 += '</div>'	
		 
		 var html4 = '<div class="row" style="margin-left: 20px;">'
		 html4 += '<div class="col-sm-6">'
		 html4 += '<div class="tool" style="margin-top: 0px;">Required label</div>'
		 html4 += '<div id="requiredlabeltools" class="hide">'
		 html4 += '<div class="tool">Label Choices</div>'
		 html4 += '<div id="cltext2" class="tool" style="padding-top: '+this.clabeloffset+'">Correct Label</div>'
		 html4 += '</div>'	
		 html4 += '</div>'	
		 html4 += '<div class="col-sm-6">'
		 html4 += '<div id="rtoggleshell" style="margin-top:10px;"><label class="switch tool"><input id="rltoggle" type="checkbox" onclick="update();"><div class="slider"><span class="ontext">ON</span><span class="offtext">OFF</span></div></label></div>'
		 html4 += '<div id="requiredlabelinputs" class="hide">'
		 html4 += '<form id="checkform" onclick="checkBoxes();">'+this.checkboxhtml+'</form>'
		 html4 += '<div><input id="newlabel" type="text" class="" placeholder="Custom label" onkeyup="" style="width: 100px; margin-top: 10px;"><button class="btn-nothing" onclick="addLabel()"> <span class="glyphicon glyphicon-cplus"></span></button></div>'
		 html4 += '<div class="styled-select" style="margin-top: 10px"><select id="cldropdown" class="select-class" onchange="GetCorrectLabel(this.value)"></span>'+this.clselects+'</select></div>'
		 html4 += '</div>'	
		 html4 += '</div>'	
		 html4 += '</div>'		

		 var html5 = '<div class="row" style="margin-left: 20px;">'
		 html5 += '<div class="col-sm-6">'
		 html5 += '<div class="tool">Element Type</div>'
		 html5 += '<div class="tool">Slope</div>'
		 html5 += '<div class="tool">Origin Point</div>'
		 html5 += '<div class="tool">End Point</div>'
		 html5 += '</div>'
		 html5 += '<div class="col-sm-6" style="padding-top: 8px;">'
		 html5 += '<div class="styled-select"><select id="eldropdown" class="select-class" onchange="GetElement(this.value)"></span><option value="None">None</option><option value="Demand">Demand</option><option value="Fixed Cost">Fixed Cost</option><option value="Indifference">Indifference</option><option value="Marginal Cost">Marginal Cost</option><option value="Marginal Revenue">Marginal Revenue</option><option value="PPF">PPF</option><option value="Supply">Supply</option><option value="Total Cost">Total Cost</option><option value="Variable Cost">Variable Cost</option></select></div>'
		 html5 += '<div style="margin-top:12px;"><input id="slope" type="number" step="0.01" class="slope-input" placeholder="'+this.m+'" value="'+this.m+'" oninput="slopeUpdate(this.value)"></div>'	  			
		 html5 += '<div>(<input id="xspoint" type="number" class="point-input" value="'+this.xsg+'" step="'+graphSe.xmax/Number(graphSe.wdPx)+'" oninput="xsUpdate(this.value)">,<input id="yspoint" type="number" class="point-input" value="'+this.ysg+'" step="'+graphSe.ymax/Number(graphSe.htPx)+'" oninput="ysUpdate(this.value)" >)</div>'	  			
		 html5 += '<div>(<input id="xepoint" type="number" class="point-input" value="'+this.xeg+'" step="'+graphSe.xmax/Number(graphSe.wdPx)+'" oninput="xeUpdate(this.value)" >,<input id="yepoint" type="number" class="point-input" value="'+this.yeg+'" step="'+graphSe.ymax/Number(graphSe.htPx)+'" oninput="yeUpdate(this.value)" >)</div>'	  			
		 html5 += '</div>'	  			
		 html5 += '</div>'	  			
		 		 
		 document.getElementById("bottomtools").innerHTML = html;		
		 document.getElementById("interactive").innerHTML = html2;		
		 document.getElementById("interactivetools").innerHTML = html3;		
		 document.getElementById("labeldetails").innerHTML = html4;		
		 document.getElementById("drawingtools").innerHTML = html5;		
		
		 document.getElementById('eldropdown').value = this.elementlabel;
		 document.getElementById('plumbtoggle').checked = this.plumbLine;
		 document.getElementById('cldropdown').value = this.correctlabel;

		 document.getElementById('tadropdown').value = this.taelement;
		 document.getElementById('reldropdown').value = this.relementlabel;
		 document.getElementById('rltoggle').checked = this.requiredlabel;
		 
		 this.checkBoxes();
		 		 
		 this.InteractiveMe( this.interactive );
		 this.PreciseMe( this.precise );
		 this.EvalShift( this.evalshift );
		 		 
		 this.DisplayBookColor();
		 
		 this.highlight();

		 this.InteractiveReset();

		 this.CheckRLabel();
		 
		 this.CorrectTools();
  
 		 $('#emptydesigner').addClass("hide");		

	     if(graphSe.mode=="correct") this.SetCorrectPoints();

		 if(this.labelLine==true) 
		 {
		 	document.getElementById("labeltoggle").checked = true;	
		 } else
		 {	
		 	document.getElementById("labeltoggle").checked = false;	
		 }

		 document.getElementById('alabels').innerHTML = this.ahtml;
		 document.getElementById('apoints').innerHTML = this.phtml;

		 this.SetElementPoints();
     }

    this.SetElementPoints = function( )
    {
 		 if(this.acceptedArea) return;

 
         document.getElementById('cxpoint0').value = graphSe.snapIt ? this.spts[0] : this.pts[0];
		 document.getElementById('cypoint0').value = graphSe.snapIt ? this.spts[1] : this.pts[1];
		
         if(this.pts.length >= 3 && this.closed == false)
         {  
			 var div = document.createElement("div");
			 div.id = 'dlabel'+this.pts.length/2;
			 this.ahtml += '<div id="alabel'+(this.areapoints+1)+'" class="tool">Point '+this.pts.length/2+'</div>'
			 document.getElementById('alabels').innerHTML = this.ahtml;
			 	 
			 var div = document.createElement("div");
			 div.id = 'dpoints2';
			 this.phtml += '<div id="ptlabel'+(this.areapoints+1)+'">(<input id="cxpoint'+this.pts.length/2+'" type="number" class="point-input point-input-area" value="" step="'+graphSe.xmax/Number(graphSe.wdPx)+'"  oninput="apUpdate(this.value, '+((this.areapoints*2)-2)+')">,<input id="cypoint'+this.pts.length/2+'" type="number" class="point-input point-input-area" value="" step="'+graphSe.ymax/Number(385)+'" oninput="apUpdate(this.value, '+((this.areapoints*2)-1)+')" >)</div>'
			 document.getElementById('apoints').innerHTML = this.phtml;

			 this.areapoints++;
 		 }

		 for(i=2; i<=this.areapoints; i++)
		 {
		 	 document.getElementById('cxpoint'+i+'').value = graphSe.snapIt ? this.spts[(i*2)-2] : this.pts[(i*2)-2];
			 document.getElementById('cypoint'+i+'').value = graphSe.snapIt ? this.spts[(i*2)-1] : this.pts[(i*2)-1];
		 }

     }

     
     this.SetElementLabel = function(text)
     {
     	 this.elementlabel = text;
     
     	 this.SetColor();     	 

     }

     this.SetRelativeElementLabel = function(text)
     {
     	 this.relementlabel = text;
     	 
     	 this.CheckRLabel();
     }
	
	 this.CheckRLabel = function()
	 {
	     if(this.relementlabel=="Accepted Area")
     	 {
   			$('#relativetools2').addClass("hide");     	 	
			$('#relativeinputs2').addClass("hide");      	 
   			$('#drawarea').removeClass("hide");     	 	
    	 } else if (this.relementlabel=="None")
     	 {
  			$('#relativetools2').addClass("hide");     	 	
			$('#relativeinputs2').addClass("hide");     	 
    		$('#drawarea').addClass("hide");     	 	
    	 } else
     	 {
			$('#relativetools2').removeClass("hide");     	 	
			$('#relativeinputs2').removeClass("hide");     	 	
   			$('#drawarea').addClass("hide");     	 	
     	 }
	 }
	 
	 this.SetBookColor = function(text)
	 {
	 	this.bookcolor = text;	 	

		this.SetColor();
	 }
	
	 this.GetBookColor = function(text)
	 {
	 	return this.bookcolor;	
	 }	 	 

	 this.DisplayBookColor = function()
	 {
	 	if(this.bookcolor=="Yes")
	 	{
			document.getElementById('bcbutton').innerHTML = 'Use Book Color <span class="glyphicon glyphicon-checkedmm"></span>';
	 	} else 
	 	{
	 		document.getElementById('bcbutton').innerHTML = 'Use Book Color <span class="glyphicon glyphicon-uncheckedmm"></span>';
	 	}
	 }

	 this.highlight = function()
	 {
	 	for(i=0; i<graphMe.length; i++)
	 	{
	 		graphMe[i].iscurrent=false	
	 	}	
	 	
	 	this.iscurrent=true
	 }
	 
	 this.UpdateLabelText = function()
	 {
		document.getElementById('xlabel'+this.labelvalue).value = this.label;	 	
		document.getElementById('toplabel'+this.labelvalue).innerHTML = this.label;	 	
	 }

	 this.InteractiveMe = function( tf )
     {
        this.interactive = tf;
        if( tf ) { $("#binteractivero").removeClass("hide"); $("#bstaticro").addClass("hide"); }
        else { $("#binteractivero").addClass("hide"); $("#bstaticro").removeClass("hide"); }
     }

     
     this.CorrectTools = function()
     {
     	if(graphSe.mode=='correct')
     	{
 			if(this.interactive!=false)$('#labeldetails').removeClass("hide");
 			$('#designertools').addClass("hide");
			$('#designerinputs').addClass("hide");      	
			$('#elabel').removeClass("hide");      	
			$('#elabelmode').removeClass("hide");      	
			$('#intleft').addClass("hide");      	
			$('#intright').addClass("hide");      	
		 	document.getElementById("elementhead").innerHTML = "Evaluation Settings";		
			document.getElementById("interactive").style.background = "#fbfbfb";
			document.getElementById("interactive").style.marginTop = "0px";
 			$('#sectionpadding').addClass("hide");

			if( this.interactive )
			{
		 		document.getElementById("elabelmode").innerHTML = "Interactive";
		 		this.elabelmode = "Interactive";		
				$('#interactivetools').removeClass("hide");      	
			} else {
		 		document.getElementById("elabelmode").innerHTML = "Static";		
		 		this.elabelmode = "Static";				 		
				$('#interactivetools').addClass("hide");      	
			}	
			
			if(this.mode=="correct")
			{
		 		document.getElementById("elabelmode").innerHTML = "Drawing";
		 		this.elabelmode = "Drawing";				
				$('#interactivetools').addClass("hide");   				
				$('#drawingtools').removeClass("hide");   				
 				$('#labeldetails').removeClass("hide");
			}     
			if(document.getElementById('rltoggle').checked)
			{
				$('#requiredlabeltools').removeClass("hide");   				
 				$('#requiredlabelinputs').removeClass("hide");	
 		 		document.getElementById('cldropdown').value = this.correctlabel;				
			} else 
			{
				$('#requiredlabeltools').addClass("hide");   				
 				$('#requiredlabelinputs').addClass("hide");					
			}
			if(this.elabelmode=="Drawing")
			{
				$('#drawingtools').removeClass("hide");   							
			} else
			{
				$('#drawingtools').addClass("hide");   				
			}

     	} else if(graphSe.mode=='student')
     	{
 				$('#interactive').addClass("hide");   				
				$('#bottomtools').addClass("hide");
 				$('#interactivetools').addClass("hide");   				
				$('#requiredlabeltools').addClass("hide");   				
 				$('#requiredlabelinputs').addClass("hide");					   				
    		
     	} else 
     	{
 			$('#labeldetails').addClass("hide");
			$('#designertools').removeClass("hide");
			$('#designerinputs').removeClass("hide");     	
			//$('#elabel').addClass("hide");      	
			$('#elabelmode').addClass("hide");      
 			$('#intleft').removeClass("hide");      	
			$('#intright').removeClass("hide");  
 		 	document.getElementById("elementhead").innerHTML = "Element Settings";		
			document.getElementById("interactive").style.background = "#f6f6f6";
			document.getElementById("interactive").style.marginTop = "0px";
  			$('#sectionpadding').removeClass("hide");
			$('#interactivetools').addClass("hide");      	
				$('#requiredlabeltools').addClass("hide");   				
 				$('#requiredlabelinputs').addClass("hide");	
    	}
     }
     
     this.InteractiveReset = function ()
     {
			if(this.interactive==true)
			{
				$('#ilabels').removeClass("hide");
				$('#iinputs').removeClass("hide");
			} else {
				$('#ilabels').addClass("hide");
				$('#iinputs').addClass("hide");
			}	     
     }
     
     this.TrackAgainstDropdown = function ()
     {
     		var html = '<option value="None">None</option>'
     		for(i=0; i<graphMe.length; i++) 
     		{
     			if(graphMe[i].label!=this.label)
     			{
					var graphlabel = graphMe[i].label;
					html += '<option value="'+graphlabel+'">'+graphlabel+'</option>'
				}	
     		}
     		
     		this.taselects = html;
     }

     this.RelativeDropdown = function ()
     {
     		var html = '<option value="None">None</option>'
     		html += '<option value="Accepted Area">Accepted Area</option>'
     		for(i=0; i<graphMe.length; i++) 
     		{
					var graphlabel = graphMe[i].label;
					html += '<option value="'+graphlabel+'">'+graphlabel+'</option>'
     		}
     		
     		this.relselects = html;
     }     

	 this.EvalShift = function( text )
     {
        this.evalshift = text;
        if( this.evalshift=="left" ) { $("#sleftro").removeClass("hide"); $("#srightro").addClass("hide");}
        else if (this.evalshift==null) {$("#sleftro").addClass("hide"); $("#srightro").addClass("hide");}
        else 
        {  
        	$("#sleftro").addClass("hide"); $("#srightro").removeClass("hide"); 
        	//$('#relativetools').removeClass("hide");
			//$('#relativeinputs').removeClass("hide");
        }
        
        if(  text != null ) this.CorrectMe( ["relative",text] );
     }    

	 this.PreciseMe = function( tf )
     {
        this.precise = tf;
        if( tf ) 
        { 
        	$("#bprecisero").removeClass("hide"); $("#brelativero").addClass("hide");
        	$('#relativetools').addClass("hide");
			$('#relativeinputs').addClass("hide");   
        	$('#precisetools').removeClass("hide");
			$('#preciseinputs').removeClass("hide");   			  			    
        }
        else if (tf==null) {$("#bprecisero").addClass("hide"); $("#brelativero").addClass("hide");}
        else 
        {  
        	$("#bprecisero").addClass("hide"); $("#brelativero").removeClass("hide"); 
        	$('#relativetools').removeClass("hide");
			$('#relativeinputs').removeClass("hide");
        	$('#relativetools2').addClass("hide");
			$('#relativeinputs2').addClass("hide");			
        	$('#precisetools').addClass("hide");
			$('#preciseinputs').addClass("hide");   
		}
     }    

     this.RequiredLabelMe = function( tf )
     {
         this.requiredlabel = tf;
         
         if(this.requiredlabel)
         {
 			$('#requiredlabelinputs').removeClass("hide");     	 	
			$('#requiredlabeltools').removeClass("hide");     	 	        
         } else {
 			$('#requiredlabelinputs').addClass("hide");     	 	
			$('#requiredlabeltools').addClass("hide");  
		}	           
     }

     this.LabelMeDrop = function( )
     {
		console.log("label me drop");

		/*console.log("label me drop");
        var xpx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxg : this.xg );
        var ypx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syg : this.yg );
         
        var xspx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxsg : this.xsg );
        var yspx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.sysg : this.ysg );
        var xepx = graphSe.ConvertXgToXpx( graphSe.snapIt ? this.sxeg : this.xeg );
        var yepx = graphSe.ConvertYgToYpx( graphSe.snapIt ? this.syeg : this.yeg );*/

        var spt = graphSe.snapIt ? { x: this.spts[2], y: this.spts[3] } : { x: this.pts[2], y: this.pts[3] };
        var pt = graphSe.snapIt ? { x: this.spts[4], y: this.spts[5] } : { x: this.pts[4], y: this.pts[5] };
		
		var xoffset = 0;
		var yoffset = 0;

		pt.x = graphSe.ConvertXgToXpx(pt.x)+xoffset;
		pt.y = graphSe.ConvertYgToYpx(pt.y)+yoffset;
		spt.x = graphSe.ConvertXgToXpx(spt.x)+xoffset;
		spt.y = graphSe.ConvertYgToYpx(spt.y)+yoffset;
		
		var d = 20;
		
		var mag = Math.sqrt(Math.pow((pt.x - spt.x),2) + Math.pow((pt.y - spt.y),2))
		var newx = pt.x + d * (pt.x - spt.x) / mag
		var newy = pt.y + d * (pt.y - spt.y) / mag   

		var div = document.createElement("div");
		div.id = 'dlabel';
		div.style.position = "absolute";
		div.style.left = newx+37+'px';
		div.style.top = newy+179+'px';
		div.style.zIndex = "10000";
		div.className = 'styled-select';
			
		div.innerHTML = '<select id="elabel" class="select-class" onchange="GetCorrectStudentLabel(this.value)"></span>'+this.clselects+'</select>'
		document.getElementById('graphcontainer').appendChild(div);	

		//$('#elabel').removeClass("hide");
		
	}   

     this.SetCorrectLabel = function(text)
     {
     	 this.correctlabel = text;
     }

    this.SetCorrectStudentLabel = function(text)
     {
     	 this.studentcorrectlabel = text;
     	 
     	 this.CheckIsCorrect("label");	   	 
     }
 
    this.SetCorrectPoints = function( )
     {         
         if(this.precise)
         {

			 document.getElementById('cxpoint0c').value = graphSe.snapIt ? this.spts[0] : this.pts[0];
			 document.getElementById('cypoint0c').value = graphSe.snapIt ? this.spts[1] : this.pts[1];

			 document.getElementById('alabelsc').innerHTML = this.ahtml;
			 document.getElementById('apointsc').innerHTML = this.phtml;
	
			 /*if(this.pts.length >= 3 && this.closed == false)
			 {  
				 var div = document.createElement("div");
				 div.id = 'dlabel'+this.pts.length/2;
				 this.ahtml += '<div id="alabel'+(this.areapointso+1)+'" class="tool">Point '+this.pts.length/2+'</div>'
				 document.getElementById('alabelsc').innerHTML = this.ahtml;
				 
				 var div = document.createElement("div");
				 div.id = 'dpoints2';
				 this.phtml += '<div id="ptlabel'+(this.areapointso+1)+'">(<input id="cxpoint'+this.pts.length/2+'" type="number" class="point-input point-input-area" value="" step="'+graphSe.xmax/Number(graphSe.wdPx)+'"  oninput="apUpdate(this.value, '+((this.areapointso*2)-2)+')">,<input id="cypoint'+this.pts.length/2+'" type="number" class="point-input point-input-area" value="" step="'+graphSe.ymax/Number(385)+'" oninput="apUpdate(this.value, '+((this.areapointso*2)-1)+')" >)</div>'
				 document.getElementById('apointsc').innerHTML = this.phtml;

				 this.areapointso++;
			 }*/

			 for(i=2; i<=this.areapoints; i++)
			 {
				 document.getElementById('cxpoint'+i+'').value = graphSe.snapIt ? this.spts[(i*2)-2] : this.pts[(i*2)-2];
				 document.getElementById('cypoint'+i+'').value = graphSe.snapIt ? this.spts[(i*2)-1] : this.pts[(i*2)-1];
			 }


		 } 	 
		 
		 /*document.getElementById('cxspointc').value = this.correctcsx;
		 document.getElementById('cyspointc').value = this.correctcys;
		 document.getElementById('cxmpointc').value = this.correctcxm;
		 document.getElementById('cympointc').value = this.correctcym;
		 document.getElementById('cxepointc').value = this.correctcxe;
		 document.getElementById('cyepointc').value = this.correctcye;*/
		 //this.SetSettings();
     }     



	this.SetSettings();
     
}


function DoPointer( e )
{
    doPointerMode = true;
	doLabelMode = false;
    
    drawPointMode = false;
    drawLineMode = false;
    drawCurveMode = false;
    drawFillPolylineMode = false;
    theCurve = null;
    
    cancursor = "pointer";
    can.style.cursor = "pointer";
    
    oldPt = null;
    animLine = null;
    
	$('#pointerBtn').addClass("btn-econ-sw5-on");	
	$('#drawpointBtn').removeClass("btn-econ-sw5-on");	
	$('#drawlineBtn').removeClass("btn-econ-sw5-on");	
	$('#drawcurveBtn').removeClass("btn-econ-sw5-on");	
	$('#drawfillpolylineBtn').removeClass("btn-econ-sw5-on");	
 
}

function DoLabel( e )
{
	doLabelMode = true;
    doPointerMode = false;
    
    drawPointMode = false;
    drawLineMode = false;
    drawCurveMode = false;
    drawFillPolylineMode = false;
    theCurve = null;
    
    cancursor = "url(./cursorlabel.png),auto";
    can.style.cursor = cancursor;
    
    oldPt = null;
    animLine = null;

	$('#label').addClass("btn-econ-sw5-on");	
	$('#pointerBtn').removeClass("btn-econ-sw5-on");	
	$('#drawpointBtn').removeClass("btn-econ-sw5-on");	
	$('#drawlineBtn').removeClass("btn-econ-sw5-on");	
	$('#drawcurveBtn').removeClass("btn-econ-sw5-on");	
	$('#drawfillpolylineBtn').removeClass("btn-econ-sw5-on");
}


function DoDrawPoint( e )
{
    drawPointMode = true;
    doPointerMode = false;
    drawLineMode = false;
    drawCurveMode = false;
    theCurve = null;
    drawFillPolylineMode = false;
	doLabelMode = false;
    
    cancursor = "url(./cursorpoint.png),auto";
    can.style.cursor = cancursor;
    
    oldPt = null;
    animLine = null;

	$('#label').removeClass("btn-econ-sw5-on");	
	$('#pointerBtn').removeClass("btn-econ-sw5-on");	
	$('#drawpointBtn').addClass("btn-econ-sw5-on");	
	$('#drawlineBtn').removeClass("btn-econ-sw5-on");	
	$('#drawcurveBtn').removeClass("btn-econ-sw5-on");	
	$('#drawfillpolylineBtn').removeClass("btn-econ-sw5-on");	
}


function DoDrawLine( e )
{
    drawLineMode = true;
    drawPointMode = false;
    doPointerMode = false;
    drawCurveMode = false;
    theCurve = null;
    drawFillPolylineMode = false;
	doLabelMode = false;
    
    cancursor = "url(./cursorline.png),auto";
    can.style.cursor = cancursor;
    
    oldPt = null;
    animLine = null;
    anchorPt = null;
    animMe = [ ];

	$('#label').removeClass("btn-econ-sw5-on");	
	$('#pointerBtn').removeClass("btn-econ-sw5-on");	
	$('#drawpointBtn').removeClass("btn-econ-sw5-on");	
	$('#drawlineBtn').addClass("btn-econ-sw5-on");	
	$('#drawcurveBtn').removeClass("btn-econ-sw5-on");	
	$('#drawfillpolylineBtn').removeClass("btn-econ-sw5-on");
}


function DoDrawCurve( e )
{
    drawCurveMode = true;
    drawPointMode = false;
    doPointerMode = false;
    drawLineMode = false;
    drawFillPolylineMode = false;
 	doLabelMode = false;
   
    cancursor = "url(./cursorcurve2.png),auto";
    can.style.cursor = cancursor;
    
    oldPt = null;

	$('#label').removeClass("btn-econ-sw5-on");	
	$('#pointerBtn').removeClass("btn-econ-sw5-on");	
	$('#drawpointBtn').removeClass("btn-econ-sw5-on");	
	$('#drawlineBtn').removeClass("btn-econ-sw5-on");	
	$('#drawcurveBtn').addClass("btn-econ-sw5-on");	
	$('#drawfillpolylineBtn').removeClass("btn-econ-sw5-on");
}


function DoDrawFillPolyline( e )
{
    drawFillPolylineMode = true;
    drawCurveMode = false;
    theCurve = null;
    drawPointMode = false;
    doPointerMode = false;
    drawLineMode = false;
 	doLabelMode = false;
   
    drawAcceptedArea = null;
    
    cancursor = "url(./cursorfillpolyline.png),auto";
    can.style.cursor = cancursor;
    
    oldPt = null;

	$('#label').removeClass("btn-econ-sw5-on");	
	$('#pointerBtn').removeClass("btn-econ-sw5-on");	
	$('#drawpointBtn').removeClass("btn-econ-sw5-on");	
	$('#drawlineBtn').removeClass("btn-econ-sw5-on");	
	$('#drawcurveBtn').removeClass("btn-econ-sw5-on");	
	$('#drawfillpolylineBtn').addClass("btn-econ-sw5-on");
}

function DoAcceptedArea( gloc )
{
    drawFillPolylineMode = true;
    drawCurveMode = false;
    theCurve = null;
    drawPointMode = false;
    doPointerMode = false;
    drawLineMode = false;
 	doLabelMode = false;
   
    cancursor = "url(./cursorfillpolyline.png),auto";
    can.style.cursor = cancursor;
    
    drawAcceptedArea = graphMe[gloc];
    graphMe[gloc].evalshift = null;
}


var undoTmr;

function MouseDown(e) 
{
    var ho;
    mouseIsDown = true;
    
    var pt = MouseXY(e);
    
    if( doPointerMode )
    {
        ho = null;
        
        if( (ho = IsAHit(pt,Line)) )
        {
            if( graphSe.mode == "designer" || graphMe[ho.loc].interactive )
                graphMe[ho.loc].DragMe( pt );
        }    
        else if( (ho = IsAHit(pt,Point)) ) 
        {
            if( graphSe.mode == "designer" || graphMe[ho.loc].interactive )
                graphMe[ho.loc].DragMe( pt );
        }
        else if( (ho = IsAHit(pt,Curve)) )
        {
            if( graphSe.mode == "designer" || graphMe[ho.loc].interactive )
                graphMe[ho.loc].DragMe( pt );
        }
        else if( (ho = IsAHit(pt,Polyline)) )
        {
            if( graphSe.mode == "designer" || graphMe[ho.loc].interactive )
                graphMe[ho.loc].DragMe( pt );
        }      
        
        if( ho ) 
        { 
             gmloc = ho.loc + 1; 
             ho.gi.SetSettings( );
             ho.gi.ControlMe( true ); 
        } 
        
    }  else if( doLabelMode )
    {
        if( (ho = IsAHit(pt,Line)) )
        {
            console.log("Hit Line: ", ho.loc, graphMe[ho.loc].xe,graphMe[ho.loc].ye);
            graphMe[ho.loc].LabelMeDrop(  );
        }
            
        else if( (ho = IsAHit(pt,Point)) ) 
        {
            console.log("Hit Point", ho.loc);
            graphMe[ho.loc].LabelMeDrop(  );
        }
        else if( (ho = IsAHit(pt,Curve)) )
        {
            console.log("Hit Curve", ho.loc);
            graphMe[ho.loc].LabelMeDrop(  );
        }   
       else if( (ho = IsAHit(pt,Polyline)) )
        {
            graphMe[ho.loc].LabelMeDrop(  );
        }      
         
        if( ho ) 
        { 
             gmloc = ho.loc + 1; 
             ho.gi.SetSettings( ); 
             console.log("Mouse Down:", gmloc);
        }

    }
    else if( drawLineMode )
    {
        var hit = IsAHit( pt, Point )
        if( hit != null ) pt = hit;
        
        anchorPt = { type: "point", x: pt.x, y: pt.y };
    }
    else if( drawCurveMode )
    {
        if( theCurve == null ) { theCurve = new Curve( "black", 2 ); graphSe.AddElement( graphMe, theCurve ); }
        
        var hit = IsAHit( pt, Point );
        if( hit == null ) 
        {
            //if( theCurve.selectingPts ) theCurve = new Curve( "black", 2 );
            theCurve.clickingPts = true;
            theCurve.swipingPts = true;
            theCurve.AddPoint( pt );
        }
        else 
        {
            theCurve.selectingPts = true;
            theCurve.AddPoint( {x: hit.x, y: hit.y} );
        }
            
        //graphSe.AddElement( animMe, theCurve );
        //graphSe.AddElement( graphMe, theCurve );
    }
}

function TouchDown() 
{
    mouseIsDown = true;
    TouchXY();
}

function MouseUp( e ) 
{
    pt4NewLine = true;
    mouseIsDown = false;
    if( animLine != null )
    { 
        if( graphSe.mode == "student" ) animLine.CheckIsCorrect( "drawing" );

        //graphSe.AddElement( graphMe, animLine )
        animLine = null;
        anchorPt = null;
        animMe = [ ];
        pt4NewLine = false;
        
    }
    
    var btn, evt = e ? e:event;
    if (evt.srcElement)  btn = evt.srcElement.id;
    else if (evt.target) btn = evt.target.id;
    
    if( theCurve != null && theCurve.pts.length == 6 )
    {
        //graphSe.AddElement( graphMe, theCurve ); 
        if( !theCurve.ghost ) theCurve.GhostMe( );
        if( graphSe.mode == "student" ) theCurve.CheckIsCorrect( "drawing" );    
        theCurve = null;
        animMe = [ ];
    }
    else if( theCurve != null && theCurve.pts.length > 6 ) 
    {
        theCurve.MidPoint( );
        if( graphSe.mode == "student" ) theCurve.CheckIsCorrect( "drawing" );
        theCurve = null;
        animMe = [ ];
    }
    
    var pt = MouseXY(e);
    
    if( btn != "CanvasAnimate" ) return;
    
    if( drawPointMode )
    {
        newPt = new Point( "black", pt.x, pt.y, 4 );
        if( graphSe.mode == "correct" ) newPt.CorrectMe( );
        if( graphSe.mode == "student" ) newPt.CheckIsCorrect( "drawing" );
        graphSe.AddElement( graphMe, newPt );
    }
    else if( drawLineMode && pt4NewLine )
    {
        var hit = IsAHit( pt, Point )
        if( hit != null ) pt = hit;
    
        if( newLine == null )
        {
            newLine = new Line( "black", pt.x, pt.y );
            graphSe.AddElement( graphMe, newLine );
        }
        else
        {
            newLine.AddEndPt( pt.x, pt.y, true );
            newLine = null;
        }
    
    }
    else if( drawFillPolylineMode )
    {
        if( thePoly == null )
        {
           
            if( thePoly == null ) 
                thePoly = new Polyline( "gray", 1, 1, drawAcceptedArea != null );
        
            thePoly.AddPoint( pt );
            
            //graphSe.AddElement( animMe, thePoly );
            graphSe.AddElement( graphMe, thePoly );
            
        }
        else if( !thePoly.IsDone( ) )
        {
            thePoly.AddPoint( pt );
            
            //graphSe.AddElement( animMe, thePoly );
            //graphSe.AddElement( graphMe, thePoly );
        }
        else 
        {
            thePoly.AddPoint( pt );
            
            //graphSe.AddElement( animMe, thePoly );
            //graphSe.AddElement( graphMe, thePoly );
        }
    }
    
    if( dragObj != null  )
    {
        if( graphSe.mode == "designer" || dragObj.interactive ) dragObj.DragMe( pt, "drop" );
    }
    
}

var hoverObj = null;
var animLine = null;
function MouseMove(e) 
{
    var pt = MouseXY(e);
    
    /*
    if( doPointerMode )
    {
        if( (ho = IsAHit(pt,Line)) || (ho = IsAHit(pt,Curve)) || (ho = IsAHit(pt,Polyline)) ) 
            { hoverObj = graphMe[ho.loc]; hoverObj.ControlMe( true ); }   
        else if( hoverObj != null ) { hoverObj.ControlMe( false ); hoverObj = null; }
        
        if( hoverObj == null ) graphSe.NoHover( );
        else graphSe.OneHover( );
        
        //if( IsAHit(pt,Line) || IsAHit(pt,Point) || IsAHit(pt,Curve) ) can.style.cursor = cancursor;
        //else can.style.cursor = cancursor;
    }
    */
    
    if( mouseIsDown )
    {
        if( drawLineMode )
        {
            var hit = IsAHit( pt, Point );
            if( hit != null ) pt = hit;
            
            if( animLine == null && anchorPt)
            {
                animLine = new Line( "black", anchorPt.x, anchorPt.y, pt.x, pt.y, 2 );
                //graphSe.AddElement( animMe, animLine );
                graphSe.AddElement( graphMe, animLine );

                animLine.SetSettings();
            }
            else if( animLine )
            {
                animLine.AddEndPt( pt.x, pt.y, false );
                animLine.SetSettings();
            }
        }
        else if( drawCurveMode && theCurve )
        {
            theCurve.AddPoint( pt );
        }
        
        if( dragObj != null ) 
        {
            if( graphSe.mode == "designer" || dragObj.interactive ) dragObj.DragMe( pt );
            //dragObj.DragMe( pt );
        }
    }
}

function IsAHit( aPt, type )
{
    var aHit = false, iloc = -1;
    var i, gi;
    for( i = graphMe.length-1; i >= 0 && !aHit; i-- )
    {
        gi = graphMe[i];
        if( type == undefined || gi instanceof type && !gi.acceptedArea && !(graphSe.mode=="student" && gi.mode=="correct"))
            { aHit = gi.HitMe( aPt ); iloc = i }
    }
        
    return aHit ? { loc: iloc, gi: gi, x: gi.x, y: gi.y } : null;
}

 
function TouchUp() 
{
    mouseIsDown = false;
    // no touch to track, so just show state
    ShowPos();
}
 
function MouseXY(e) 
{
    if (!e) var e = event;
    
    canX = e.pageX - can.offsetLeft;
    canY = e.pageY - can.offsetTop;
    
    ShowPos();
    
    //console.log(can.offsetLeft, can.offsetTop);
 
	/*ctx2.fillStyle = "black";
	ctx2.font="14px sans-serif";
	ctx2.fillText("("+canX+", "+canY+")",canX,canY);
	ctx2.font="10px sans-serif"; */
    
    return { x: canX, y: canY }
}
 
function TouchXY(e) 
{
    if (!e) var e = event;
    e.preventDefault();
    canX = e.targetTouches[0].pageX - can.offsetLeft;
    canY = e.targetTouches[0].pageY - can.offsetTop;
    ShowPos();
}

function ShowPos() 
{
    var xg = graphSe.ConvertXpxToXg(canX).toFixed(1);
    var yg = graphSe.ConvertYpxToYg(canY).toFixed(1);
    
    if(graphSe.showpos)
    {
    // large, centered, bright green text
    ctx.font = "9pt sans-serif";
    ctx.textAlign = "center";
    //ctx.textBaseline = "middle";
    ctx.fillStyle = "grey";
    //var str = canX + ", " + canY;
    var str = "("+xg + ", " + yg+")";
    //if (mouseIsDown) str += " down";
    //if (!mouseIsDown) str += " up";
    ctx.clearRect(0, 0, can.width, can.height);
    // draw text at center, max length to fit on canvas
    ctx.fillText(str, canX+30, canY+35);
    // plot cursor
    //ctx.fillStyle = "white";
    //ctx.fillRect(canX -5, canY -5, 10, 10);
 
    }
}

var gridt = 1;

function DrawGrid( )
{
    var xs, ys, xe, ye;
    var clr, wd;
    var cht = 386, cwd = 386;
    paper.projects[0].activate();
    ctx2.clearRect(0, 0, can2.width, can2.height);

    for( var g = 0, xsp = 24; g < 17; g++ )
    {  
         if( gridt == 1)
         {
			 if( g == 0 ) {  }
			 else { clr = "#e5e5e5"; wd = 1 }
		 
			 xs = g*xsp; ys = 0; xe = xs; ye = ys + cht;
			 DrawLine( clr, wd, xs, ys, xe, ye );
		 
			 xs = 0; ys = cht-g*xsp-2; xe = cwd; ye = ys;
			 DrawLine( clr, wd, xs, ys, xe, ye );

		 }	 
		
		 if (valuet == 1)
		 {
			 xs = 0; ys = cht-g*xsp-2; xe = cwd; ye = ys;
			 ctx2.textAlign = "right"; 
			 ctx2.fillStyle = "#a8a8a8";
			 ctx2.fillText(graphSe.convertY(g),xs+35,ys+22);
			 //ctx2.fillText(ys+22,xs+35,ys+22);
		 	 if(g==16) 
		 	 {
		 	 	//document.getElementById('ymax').value = convertY(g);
		 	 	//graphSe.ymax = convertY(g);
		 	 }	

			 xs = g*xsp+2; ys = 0; xe = xs; ye = ys + cht;
			 ctx2.textAlign = "center"; 
			 //ctx2.fillText(xe+40,xe+40,ye+28);
   		         ctx2.fillStyle = "#a8a8a8";
			 ctx2.fillText(graphSe.convertX(g),xe+40,ye+28);
		 	 if(g==16) 
		 	 {
		 	 	//document.getElementById('xmax').value = convertX(g);
		 	 	//graphSe.xmax = convertX(g);
		 	 	//console.log("max done");
			 }
		 }	 

    }

	 if( gridt == 1)
	 {    
		//DrawLine( "#ECECEC", 1, 2, 1, cwd-2, 1 );
		//DrawLine( "#ECECEC", 1, cwd-1, cht, cwd-1, 0 );
		//DrawLine( "#5A5A5A", 3, cwd-1, cht, cwd-1, 0 );
	 }	
		
		DrawLine( "#515151", 4, 0, cht, 0, 0 );
		DrawLine( "#515151", 2, 0, cht, cwd, cht );	 

}



function DrawLines( cxx, pts )
{
        
	    cxx.moveTo(pts[0]*wwr, pts[1]*whr);    
	    for(var i = 2, l = pts.length - 1; i < l; i += 2)
	        cxx.lineTo(pts[i]*wwr, pts[i+1]*whr);
	
	    cxx.strokeStyle = this.crvColor;
	    cxx.fillStyle = this.fillClr;
	    cxx.lineWidth = this.crvWidth;
	    //cxx.stroke( );
	    cxx.moveTo(pts[0],pts[0]);
	    cxx.fill( );
}

function DrawLine( colr, w, xs, ys, xe, ye, dash )
{  
    var path = new paper.Path();
	path.strokeColor = colr;
	path.strokeWidth = w;
	if( dash != undefined ) path.dashArray = dash;
	
	var start = new paper.Point(xs, ys);
	path.moveTo(start);
	var end = new paper.Point(xe, ye);
	path.lineTo(end);
}



function AnimateGraph( )
{
    paper.projects[1].activate();
    paper.project.activeLayer.removeChildren();
    
    for( var i = 0, ln = animMe.length; i < ln; i++ )
    {
        animMe[i].DrawMe( );
    }
    
    DrawGraph( );
}

function DrawGraph( )
{
    var can = document.getElementById("CanvasGraph");
    var ctx = can.getContext("2d");
    
    paper.projects[0].activate();
    paper.project.activeLayer.removeChildren();

    DrawGrid( );
    
    for( var i = 0, ln = graphMe.length; i < ln; i++ )
    {
        graphMe[i].DrawMe( ctx );
    }
    
}



window.onload = Start;